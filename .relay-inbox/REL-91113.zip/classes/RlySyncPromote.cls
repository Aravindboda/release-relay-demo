/**
 * @description Sync status: back promote or push just the picked components (pipeline mode sync with options.paths,
 * pipeline files v23). A back promote brings the files from a higher branch to the one below it; a push deploys the org's
 * own branch's files to the org. Each is a back promote release (Release_Type__c Back_Promote) with the picked components
 * as its items and their files in Sync_Paths__c, read and moved on like any sync (RlyBackPromoteRun). An org the pipeline
 * can't sign in to (a developer org) gets the files on its branch only (branchOnly). Admins only, like back promote.
 */
public with sharing class RlySyncPromote {

    private static final Set<String> OPEN_SYNC = new Set<String>{ 'Submitted', 'Ready for approval', 'Deploying' };

    /** @description What the page picked. */
    public class Pick {
        /** @description The higher org (a back promote), or the org itself (a push). */
        public Id higherOrgId;
        /** @description The lower org (a back promote); blank for a push. */
        public Id lowerOrgId;
        /** @description The picked components, Type:Name. */
        public List<String> keys;
        /** @description Their files (repo paths). */
        public List<String> paths;
    }

    /**
     * @description Queues a back promote of the picked components from a higher org's branch to the one below it.
     * @param pick the pick
     * @param orgs the route orgs
     * @return the back promote release
     */
    public static Id backPromote(Pick pick, List<RLY_Org__c> orgs) {
        RlyBackPromote.requireAdmin();
        RlySyncPicks.check(pick);
        RLY_Org__c higher = RlySyncRoute.find(orgs, pick.higherOrgId);
        RLY_Org__c lower = RlySyncRoute.find(orgs, pick.lowerOrgId);
        if (!isPair(orgs, higher, lower)) {
            throw new RlyReleaseException(lower.Name + ' isn\'t the org below ' + higher.Name + ' on the route.');
        }
        return queue(higher, lower, pick);
    }

    /**
     * @description Queues a push of the picked components from an org's own branch to the org.
     * @param pick the pick (higherOrgId = the org)
     * @param orgs the route orgs
     * @return the release
     */
    public static Id push(Pick pick, List<RLY_Org__c> orgs) {
        RlyBackPromote.requireAdmin();
        RlySyncPicks.check(pick);
        RLY_Org__c org = RlySyncRoute.find(orgs, pick.higherOrgId);
        if (!RlySyncRoute.hasSignIn(org)) {
            throw new RlyReleaseException(org.Name + ' is a developer org: the pipeline can\'t deploy to it. Raise from it, '
                + 'or deploy the files from its branch with your own tools.');
        }
        return queue(org, org, pick);
    }

    /**
     * @description Queues a back promote of everything the higher branch has (as back promote does today).
     * @param higherOrgId the higher org
     * @param lowerOrgId the org below it
     * @param orgs the route orgs
     * @return the back promote release
     */
    public static Id backPromoteAll(Id higherOrgId, Id lowerOrgId, List<RLY_Org__c> orgs) {
        RlyBackPromote.requireAdmin();
        RLY_Org__c higher = RlySyncRoute.find(orgs, higherOrgId);
        RLY_Org__c lower = RlySyncRoute.find(orgs, lowerOrgId);
        if (!isPair(orgs, higher, lower)) {
            throw new RlyReleaseException(lower.Name + ' isn\'t the org below ' + higher.Name + ' on the route.');
        }
        return queue(higher, lower, null);
    }

    // The release, its items (the picked components; none for everything) and the target org's manual steps.
    private static Id queue(RLY_Org__c higher, RLY_Org__c lower, Pick pick) {
        String title = titleOf(higher, lower, pick);
        if (hasOpenSync(lower.Id)) {
            throw new RlyReleaseException('A back promote to ' + lower.Name + ' is already waiting or running.');
        }
        Boolean branchOnly = !RlySyncRoute.hasSignIn(lower);
        RLY_Release__c rel = new RLY_Release__c(Release_Type__c = RlyPromotion.TYPE_BACK_PROMOTE, Mode__c = 'Existing branch',
            Request_Type__c = 'Changes', Title__c = title.left(200),
            Description__c = (branchOnly ? 'Files brought to the ' + lower.Branch__c.trim() + ' branch only (no deploy to a developer org).'
                : 'Just the picked components, metadata only.'),
            Status__c = lower.Back_Promote_Approval__c == true ? 'Ready for approval' : RlyPromotion.QUEUED,
            Source_Org__c = higher.Id, Target_Org__c = lower.Id, Org_Label__c = higher.Name.left(40),
            Source_Branch__c = higher.Branch__c.trim(), Target_Branch__c = lower.Branch__c.trim(),
            Source_Environment__c = higher.Git_Environment__c, Target_Environment__c = branchOnly ? null : lower.Git_Environment__c,
            Component_Count__c = pick == null ? 0 : pick.keys.size(), Deletion_Count__c = 0, Scan_Status__c = 'Not configured',
            Validation_Status__c = 'Not configured', Approval_Status__c = 'Pending', Deploy_Status__c = 'Pending',
            Last_Synced__c = System.now(), Sync_Paths__c = RlySyncPicks.serialized(pick, lower));
        List<RLY_Release_Item__c> items = new List<RLY_Release_Item__c>();
        for (String k : pick == null ? new List<String>() : pick.keys) {
            items.add(new RLY_Release_Item__c(Metadata_Type__c = k.substringBefore(':'), Component_Name__c = k.substringAfter(':').left(255)));
        }
        RlyReleaseStore.insertRelease(rel, items);
        RlyBackPromoteSteps.forSyncs(new List<RLY_Release__c>{ rel }, new List<RLY_Org__c>{ lower });
        return rel.Id;
    }

    private static Boolean isPair(List<RLY_Org__c> orgs, RLY_Org__c higher, RLY_Org__c lower) {
        for (RlySyncRoute.Pair p : RlySyncRoute.pairs(orgs)) {
            if (p.higher.Id == higher.Id && p.lower.Id == lower.Id) {
                return true;
            }
        }
        return false;
    }

    private static Boolean hasOpenSync(Id orgId) {
        for (RLY_Release__c r : RlyPromoteStore.latestSyncs()) {
            if (r.Target_Org__c == orgId && OPEN_SYNC.contains(r.Status__c)) {
                return true;
            }
        }
        return false;
    }

    // Back promote A to B (everything), Back promote N components from A to B, or Push N components from the branch to A.
    private static String titleOf(RLY_Org__c higher, RLY_Org__c lower, Pick pick) {
        if (pick == null) {
            return 'Back promote ' + higher.Name + ' to ' + lower.Name;
        }
        if (higher.Id == lower.Id) {
            return 'Push ' + plural(pick.keys.size()) + ' from the ' + higher.Branch__c.trim() + ' branch to ' + higher.Name;
        }
        return 'Back promote ' + plural(pick.keys.size()) + ' from ' + higher.Name + ' to ' + lower.Name;
    }

    private static String plural(Integer n) {
        return n + (n == 1 ? ' component' : ' components');
    }
}
