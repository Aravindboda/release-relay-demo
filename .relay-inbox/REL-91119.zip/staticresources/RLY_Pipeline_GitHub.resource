# Release Relay pipeline files: version 37
# Version 37 (hub build 63): no workflow change; GitLab merges wait for the merge request to show the approved head (D49).
# Version 36 (hub build 62): no workflow change; results saves back off (D48), keytool's own error is shown.
# Version 35 (hub build 60): no workflow change; the D38 check reads the target's copies in Metadata API format.
# Version 34 (hub build 60): no workflow change; the script keeps items from other releases on a hub raise and reports target-org drift on validation.
# Version 33 (hub build 59): no workflow change; the script re-includes a release's profile files that .forceignore hides, for that run.
# Version 32 (hub build 58): no workflow change; the script writes profile access rows on a hub raise and deploys only a profile's changed entries.
# Version 31 (hub build 57): no workflow change; the script is lint-clean (no unused variables, no await inside loops).
# Version 30 (hub build 57): no workflow change; the script skips an Org vs branch part the org sent back empty.
# Version 29 (hub build 55): no workflow change; the script (scripts/release-relay.js) moves with it, since the lowest
# version among a hub's files counts. In the script, package-aware releases (options.packages from the hub): a raise or
# add from an org without a managed package puts the branch's references to it back into the files it writes; a check,
# deploy or back promote to an org without it strips them in the temporary deploy copy and leaves the package's own
# components out. Results: packages.kept / leftOut / componentsLeftOut. Git keeps the full files.
# Version 28 (hub build 52): no workflow change; the script (scripts/release-relay.js) moves with it, since the lowest
# version among a hub's files counts. In the script: a new hub raise starts from where the target and the developer
# org's branch meet, so unselected files on that branch stay out of the pull request (the raise job replaces the
# hub's release branch with --force-with-lease, so the job's token must be allowed to force-push release branches);
# a failed raise or add takes the hub's upload files (.relay-inbox/<REQUEST_ID>*) off the release branch; validate
# fails and merge refuses while the release branch adds any .relay-inbox/ file.
# Version 27 (hub build 48, security): signed runs and results, and the release branch treated as untrusted.
# - Signed runs: the hub signs every run it starts (options.iat and options.sig, HMAC-SHA256 with the run-signing key
#   from the hub's Pipeline tab). Every job that signs in to an org or pushes checks the signature first, against the
#   secret RELAY_RUN_KEY, and stops before any sign-in, push or result when it's missing, wrong or older than 15 minutes
#   (counted from the run's creation, read with this run's token: actions: read). Without RELAY_RUN_KEY a job warns and
#   goes on (until the key is added); repository variable RELAY_SIGNING=required makes that a failure. The schedules
#   (nightly archive, hourly Slack) aren't signed; archive and Slack runs started by hand are.
#   Where the key lives: an ENVIRONMENT secret RELAY_RUN_KEY in every environment the pipeline uses (each org's, the
#   hub's, and "relay-signing", used by the jobs without an org: scan-save, sync-branch, compare, routediff, migrate,
#   and raise or merge when no source environment is sent), each environment allowed to deploy from main only, and main
#   protected (pull request review, no direct pushes). A repository secret works too, but anyone who can push a branch
#   can read a repository secret from their own workflow.
# - Signed results: with the key, every result file on release-relay-results is {"payload":"<json>","sig":"<hmac>"}
#   (wrapper version 2); the hub rejects a result without a good signature once it has a key.
# - Approved head: validate.json records headSha; mode merge refuses unless the pull request's head is options.expectHead
#   (gh pr merge --match-head-commit). The deploy fails ("changed after validation") when the merged head or files
#   aren't the validated ones (options.fullDeploy, sent by the hub after a fresh check, deploys in full instead). A quick
#   deploy asks the org first (sf project deploy report): a succeeded check-only deployment with this release's
#   components, from the approved check (attempt); otherwise a full deploy with tests.
# - Untrusted branch: permissions are {} at the top and granted per job; the scan job is read-only, has no secrets and
#   no persisted token, uses the pipeline's Code Analyzer config (--config-file; .relay/code-analyzer.yml on the
#   pipeline commit, else a built-in one) and ignores the branch's code-analyzer.yml and ESLint files; its result is
#   signed and saved by the new scan-save job. Every sf command runs with an allowlisted environment (no secrets) and
#   without the branch's sfdx-project.json "replacements". selfUpdate with a target other than release-relay-hub fails
#   (repository variable RELAY_SELF_UPDATE_BRANCHES lists more allowed branches, for example a hub test org's).
# - Pinned: actions by commit (checkout v4.2.2, setup-node v4.4.0, cache v4.3.0, setup-java v4.7.1,
#   create-github-app-token v1.12.0, upload-artifact v4.6.2, download-artifact v4.3.0), @salesforce/cli@2.135.7 and
#   @salesforce/plugin-code-analyzer@5.13.0 (cache keys carry the versions).
# (Version 26 notes follow.)
# Version 26: mode "migrate" (the hub's Move repository wizard, request ids MIG-<13 digits>). The migrate job runs in
# this (the SOURCE) repository: no environment and no org. It mirror-clones this repository and pushes every branch and
# tag to the new, empty repository at options.targetUrl (https, never with credentials) with the repository secret
# RELAY_MIGRATE_TOKEN (a token that can push to the new repository; delete it after the move). Repository variable
# RELAY_MIGRATE_USER overrides the push user name (default from options.targetProvider). A target with any branch or
# tag is refused (options.force overrides; the hub never sets it). Progress and the result: results/<id>/migrate.json
# on release-relay-results. Open pull requests, run history and comments don't move. Every other mode is unchanged.
# options.method: lift (every branch, tag and commit; the default), fresh (each branch in options.branches seeded with
# its latest files, one commit, no history) or verify (nothing pushed: a copy made by the provider's importer compared
# ref by ref). options.dryRun reads both sides and reports (what would move, size, access, empty or matching) first.
# (Version 25 notes follow.)
# Version 25: clearer run names and a run summary. A run's name keeps "Release Relay <request id> (<mode>)" (the hub
# finds its run by it; hubs from build 44 also accept the added parts) and adds " · <title>" when the title input is set
# and " · by <name>" when the options JSON has "by" (who raised the release). Scheduled runs keep their names. Each step's
# result also goes to the run's summary page (GITHUB_STEP_SUMMARY): request, step and status, source → target, raised
# and approved by, components, deletions, tests, scan findings, deploy id, message and an "Open in Release Relay" link
# (options.hubUrl). The summary never shows secrets or values from the values file. Needs a hub from build 44.
# (Version 24 notes follow.)
# Version 24: Slack reminders and the daily digest. A second schedule (every hour at :17, "17 * * * *") runs the
# slack-due job only: it signs in to the hub like the archive job and calls POST /services/apexrest/rly/slack-due once
# per pass until the hub says done (at most 10 calls). The hub decides what is due per org (reminders, digests); an
# org with them off is never read. Repository variable RELAY_SLACK_DUE=off skips the job; mode "slack" runs it by hand.
# The hourly runs aren't posted to the Pipeline Monitor. The nightly archive (0 8 * * *) is unchanged.
# Also version 24: data sets (the hub's Sync status tab, Data; request ids DAT-<13 digits>). Mode "data": the data-export job
# signs in to the source org (inputs.environment; skipped when the hub already sent a developer org's records to
# release-relay-results under data-inbox/<id>/) and saves its records there; the data-load job signs in to the target
# (inputs.target_environment), matches records by each object's match key, masks and swaps per-org values, and either
# dry-runs (options.dryRun: counts only, nothing changes) or loads parents first, then children. results/<id>/data.json
# for the hub. The Pipeline Monitor shows "Data".
# Version 23: the hub's Sync status tab (request ids SYN-<13 digits>). Mode "drift" (Org vs branch): the drift job runs
# in the org's own environment (inputs.environment), signs in like validate and deploy, reads the whole org (managed
# packages left out) and compares it with its branch (target); results/<id>/drift.json for the hub. Mode "routediff"
# (Down the route): Git only, no environment: what each higher branch in options.route has that the next one down
# doesn't; results/<id>/route.json. Mode "compare" with options.full: a developer org read whole by the hub, same
# drift.json. Mode "sync" with options.paths: back promote only the picked files (a file the lower branch changed too
# is a conflict, never overwritten); with branch = target, Push to the org: just the picked components are deployed
# from the branch. Mode "sync" with options.branchOnly and no target environment (a developer org): the sync-branch job
# (no environment) only updates the lower branch. The Pipeline Monitor shows "Org vs branch" and "Down the route".
# Version 22: mode "compare" (the hub's Compare before raising, for big releases). The hub commits the developer org's
# copy as Metadata API zips to release-relay-results (compare-inbox/<id>/<n>.zip) and starts the run with request_id
# CMP-<13 digits>, target = the branch to compare with, components/deletions and options.batches. The compare job signs
# in to no org and uses no environment: it converts the zips on top of the target branch and writes
# results/<id>/compare.json and results/<id>/f/<n>.json for the hub to read. Every other job skips; the Pipeline Monitor
# shows the run as "Compare". Also in version 22: the hub can send a big release in parts
# (.relay-inbox/<REL>-part-<k>.zip on the release branch); the script unpacks them all.
# Version 21: the archive call sends its JSON body inline (--body "$body"). "sf api request rest --body" sent the file's
# path as the body, so the hub never saw the body.
# Version 20: Pipeline Monitor. Two small jobs tell the hub about every run, signed in with the hub environment's login
# (vars.RELAY_HUB_ENVIRONMENT, default prod) like the archive job, through "sf api request rest": monitor-start posts
# "In progress" when the run starts, monitor-end (always, after every other job) posts how it ended (Succeeded, Failed
# or Cancelled), when, how long, the jobs' outcomes and the first failure (read with this run's token: actions, checks).
# The hub shows them on its Pipeline Monitor tab and keeps them for its Retention days. They never fail the run: a
# failed call is a warning. Set the repository variable RELAY_MONITOR to off to skip both (for example when the hub
# environment needs a reviewer). The nightly archive's log also says how many old monitor runs the hub removed.
# Version 19: the archive job calls the hub with "sf api request rest" (newer Salesforce CLIs hide the access token in
# "sf org display", so the old curl call was sent without a sign-in and got INVALID_AUTH_HEADER).
# Version 18: the nightly archive can also be started by hand: Actions → Release Relay → Run workflow → mode "archive"
# (the other fields can stay blank); same job as the 2:00 AM schedule.
# Version 17: a release whose Apex is only deletions and inactive triggers (status Inactive in the trigger's -meta.xml)
# and that names no tests runs the local tests (RunLocalTests) in production, as Salesforce requires, and no tests
# (NoTestRun) in sandboxes; "production" comes from the hub (options.production: the target is the hub org). The tests
# and coverage gates leave inactive triggers out (no 0% failure for them).
# Version 16: a file that is new on one side only no longer counts as a conflict when git pairs it with a file the
# other side deleted (identical -meta.xml files looked like a rename); the release branch's file is kept.
# Version 15: a nightly schedule (on.schedule, 08:00 UTC = 2:00 AM Central in winter) runs the archive job: it signs in
# to the hub and calls POST /services/apexrest/rly/archive once per pass (at most 25) until the hub says done. The hub
# removes finished releases older than its Retention days only when "Archive every night" is on; every other job skips
# on the schedule. Hub environment: vars.RELAY_HUB_ENVIRONMENT (default prod).
# Version 14: a promotion can take each changed file as it is in the previous stage (options.stageBranch) and stops on
# a hotfix the stage doesn't have (raise.json "clash"); changes can be added to an open release (mode hub with
# options.append and options.appendZip; raise.json "appended").
# Version 13: per-org values (.relay/values.json: {{relay:NAME}} placeholders filled per target org at deploy time,
# turned back into placeholders when org metadata is written to a branch), quality gates (.relay/gates.json: scan
# priority, Apex coverage, tests required for Apex), rollback snapshots before every deploy (release-relay-snapshots
# branch) and mode=rollback, and a cached Salesforce CLI.
# Release Relay's own metadata (its components by exact name, plus .relay/exclude) is never validated, deployed or deleted;
# options {"selfUpdate":true} (the hub updating itself, from the release-relay-hub branch) ignores the list.
# Release Relay: started from Salesforce (workflow_dispatch), and every night by the schedule (archive job only).
#   archive      (schedule only) ask the hub to archive finished releases older than its Retention days, one
#                pass per call, logging each pass; the hub skips when "Archive every night" is off.
#   mode=org     retrieve the selected components from the source org, apply deletions, commit to a
#                new branch, open a pull request into the target branch, then scan and validate it.
#   mode=branch  open a pull request from a branch that already exists, then scan and validate it.
#   mode=promote make a promote/ branch from the target with each file the merge commits listed in
#                components changed, as it is in options.stageBranch (the previous stage; without it the
#                commits are cherry-picked), open a pull request, then scan and validate it.
#   mode=hub     the Release Relay hub committed its retrieve (a Metadata API zip) to the branch:
#                convert it to source format (none for a release with only deletions,
#                a .relay-inbox/<id>.deletions marker instead), remove the deleted components' files,
#                open a pull request into the target, scan and validate.
#                options {"append":true,"appendZip":".relay-inbox/<id>-add-<k>.zip"}: add that zip's changes to the
#                open release's branch (no new pull request), then scan and validate again.
#   mode=resolve merge the target into the branch with the conflict choices the hub committed, then
#                scan and validate again.
#   mode=check   scan and validate an open pull request again (after a fix, or on request).
#   mode=merge   merge the pull request approved in Salesforce, then deploy it to the target org,
#                then merge the target into the branches in options.syncBranches (each one directly).
#   mode=sync    back promote: merge branch (the hub's production branch) into target (a back-promote
#                org's branch, made from branch when missing), deploy what changed to the org in
#                target_environment, and push target only when that deploy worked (results/<id>/sync.json).
#   mode=rollback deploy a snapshot taken before an earlier deploy back into the org in target_environment
#                (options.snapshotPath, else the latest for the release and environment); branch, target and title
#                aren't used (send the target org's branch and a short title). Writes results/<id>/rollback.json.
# Validation and deployment run only when Salesforce passes a target environment (the GitHub
# environment that holds the target org's login). Each step writes its result as JSON to the
# release-relay-results branch, where Salesforce reads it.
# options (JSON, from Salesforce): {"scan":"off"} skips the code scan; {"hub":true} skips the
# ALLOWED_TARGETS check (the hub enforces its route); {"tests":[...]} sets the test classes
# (RunSpecifiedTests, or NoTestRun when empty); {"validateMerged":true} validates the branch merged
# with the target; {"attempt":"..."} is the hub's run token, echoed in every result;
# {"syncBranches":[...]} and {"stageWins":true} are for merge; {"notify":"dev"} makes the
# last job tell that org (signing in with that environment's login) to read the results at once;
# {"snapshot":false} skips the rollback snapshot before a deploy; {"snapshotPath":"REL-00042/prod/<id>"} picks
# the snapshot for mode=rollback.
name: Release Relay
run-name: "${{ ((github.event_name == 'schedule' && github.event.schedule == '17 * * * *') || inputs.mode == 'slack') && 'Release Relay Slack reminders' || ((github.event_name == 'schedule' || inputs.mode == 'archive') && 'Release Relay nightly archive' || format('Release Relay {0} ({1}){2}{3}', inputs.request_id, inputs.mode, inputs.title && format(' · {0}', inputs.title) || '', fromJSON(inputs.options || '{}').by && format(' · by {0}', fromJSON(inputs.options || '{}').by) || '')) }}"

on:
  # Nightly archive. Cron is UTC: 0 8 * * * is 2:00 AM Central in winter (CST), 3:00 AM in summer (CDT); change the
  # hour to your quiet time. GitHub may start it a few minutes late.
  schedule:
    - cron: "0 8 * * *"
    # Slack reminders and daily digests (version 24): every hour at :17; the hub sends only what is due.
    - cron: "17 * * * *"
  workflow_dispatch:
    inputs:
      request_id:
        description: Salesforce release number (blank for archive)
        required: false
        type: string
      mode:
        description: org, branch, promote, hub, resolve, check, merge, sync, rollback, compare, drift, routediff, data, migrate (from the hub), archive (the nightly archive, by hand) or slack (Slack reminders and digests, by hand)
        required: true
        type: choice
        options: [org, branch, promote, hub, resolve, check, merge, sync, rollback, compare, drift, routediff, data, migrate, archive, slack]
      environment:
        description: GitHub environment of the source org (sync = the hub's production org)
        required: false
        type: string
      target_environment:
        description: GitHub environment of the target org (blank = Git only, no validate or deploy)
        required: false
        type: string
        default: ''
      branch:
        description: Source branch (sync = the hub's production branch)
        required: false
        type: string
      target:
        description: Target branch (sync = the back-promote org's branch)
        required: false
        type: string
      title:
        description: Pull request title
        required: false
        type: string
      components:
        description: Type:Name list to retrieve, comma separated (promote = the releases' merge commits)
        required: false
        type: string
        default: ''
      deletions:
        description: Type:Name list to delete, comma separated
        required: false
        type: string
        default: ''
      options:
        description: 'JSON options from Salesforce, for example {"scan":"off","notify":"dev"}'
        required: false
        type: string
        default: '{}'

# Version 27: no permissions by default; each job asks for what it needs (the scan job: read only).
permissions: {}

# One run at a time per release branch; back promotes, one at a time per back-promote branch; rollbacks, one at
# a time per org; the nightly archive, one at a time; each compare on its own.
concurrency:
  group: release-relay-${{ ((github.event_name == 'schedule' && github.event.schedule == '17 * * * *') || inputs.mode == 'slack') && 'slack-due' || github.event_name == 'schedule' && 'archive' || ((inputs.mode == 'compare' || inputs.mode == 'drift' || inputs.mode == 'routediff' || inputs.mode == 'data' || inputs.mode == 'migrate') && format('{0}-{1}', inputs.mode, inputs.request_id) || (inputs.mode == 'rollback' && format('rollback-{0}', inputs.target_environment) || (inputs.mode == 'sync' && inputs.target || inputs.branch))) }}
  cancel-in-progress: false

env:
  RELAY_PROVIDER: github
  REQUEST_ID: ${{ inputs.request_id }}
  MODE: ${{ inputs.mode }}
  ENVIRONMENT: ${{ inputs.environment }}
  TARGET_ENVIRONMENT: ${{ inputs.target_environment }}
  BRANCH: ${{ inputs.branch }}
  TARGET: ${{ inputs.target }}
  TITLE: ${{ inputs.title }}
  # Version 27: every input the hub signs reaches every job, so each one can check the run's signature.
  COMPONENTS: ${{ inputs.components }}
  DELETIONS: ${{ inputs.deletions }}
  OPTIONS: ${{ inputs.options }}
  # "required": a job that can't see RELAY_RUN_KEY fails instead of warning (set it once every environment has the key).
  RELAY_SIGNING: ${{ vars.RELAY_SIGNING }}
  # Branches besides release-relay-hub that may take selfUpdate runs (comma separated; for example a hub test org's).
  RELAY_SELF_UPDATE_BRANCHES: ${{ vars.RELAY_SELF_UPDATE_BRANCHES }}

jobs:
  raise:
    if: ${{ inputs.mode == 'org' || inputs.mode == 'branch' || inputs.mode == 'promote' || inputs.mode == 'hub' || inputs.mode == 'resolve' }}
    runs-on: ubuntu-latest
    permissions:
      contents: write
      pull-requests: write
      actions: read
    # Version 27: a run without a source environment uses relay-signing (the run-signing key's environment).
    environment: ${{ inputs.environment || 'relay-signing' }}
    timeout-minutes: 30
    steps:
      # Optional: a GitHub App token, so the new pull request triggers your own PR checks.
      - name: Create GitHub App token
        id: app
        if: ${{ vars.RELAY_APP_ID != '' }}
        uses: actions/create-github-app-token@d72941d797fd3113feb6b93fd0dec494b13a2547 # v1.12.0
        with:
          app-id: ${{ vars.RELAY_APP_ID }}
          private-key: ${{ secrets.RELAY_APP_PRIVATE_KEY }}
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 0
          token: ${{ steps.app.outputs.token || github.token }}
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        if: ${{ (inputs.mode == 'org' && inputs.components != '') || inputs.mode == 'hub' }}
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        if: ${{ (inputs.mode == 'org' && inputs.components != '') || inputs.mode == 'hub' }}
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        if: ${{ (inputs.mode == 'org' && inputs.components != '') || inputs.mode == 'hub' }}
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      # Inputs reach the script only as environment variables, never inside a shell command.
      - name: Raise pull request
        env:
          STEP: raise
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          GH_TOKEN: ${{ steps.app.outputs.token || github.token }}
          COMPONENTS: ${{ inputs.components }}
          DELETIONS: ${{ inputs.deletions }}
          ORG_LABEL: ${{ vars.ORG_LABEL }}
          ALLOWED_TARGETS: ${{ vars.ALLOWED_TARGETS }}
          SOURCE_PATH: ${{ vars.SOURCE_PATH }}
          WRITE_DESTRUCTIVE_MANIFEST: ${{ vars.WRITE_DESTRUCTIVE_MANIFEST }}
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
        run: node scripts/release-relay.js

  scan:
    needs: raise
    if: ${{ !cancelled() && fromJSON(inputs.options || '{}').scan != 'off' && (needs.raise.result == 'success' || inputs.mode == 'check') }}
    runs-on: ubuntu-latest
    timeout-minutes: 30
    # Version 27: the scan reads the untrusted release branch, so it gets no secrets, a read-only token that isn't left
    # in the checkout, and the pipeline's Code Analyzer settings. Its result goes to the scan-save job as an artifact.
    permissions:
      contents: read
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          ref: ${{ inputs.branch }}
          fetch-depth: 0
          persist-credentials: false
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      - uses: actions/setup-java@c5195efecf7bdfc987ee8bae7a71cb8b11521c00 # v4.7.1
        with:
          distribution: temurin
          java-version: '17'
      # The Salesforce CLI and the Code Analyzer plugin are cached per runner OS and month.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-scan-cli-2.135.7-ca-5.13.0-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI and Code Analyzer
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: |
            ~/.relay-sf
            ~/.local/share/sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI and Code Analyzer
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          export PATH="$HOME/.relay-sf/bin:$PATH"
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
          sf plugins 2>/dev/null | grep -q 'code-analyzer 5.13.0' || sf plugins install @salesforce/plugin-code-analyzer@5.13.0
      - name: Code scan
        env:
          STEP: scan
          SOURCE_PATH: ${{ vars.SOURCE_PATH }}
          SCAN_RULES: ${{ vars.SCAN_RULES }}
          SCAN_BLOCK_SEVERITY: ${{ vars.SCAN_BLOCK_SEVERITY }}
          RELAY_RESULT_FILE: ${{ runner.temp }}/relay-scan/scan.json
          RELAY_NO_FETCH: 'true'
        # The release branch may hold an older copy of the script: always run the pipeline's own.
        run: |
          mkdir -p "$RUNNER_TEMP/relay-scan"
          git show "$GITHUB_SHA:scripts/release-relay.js" > "$RUNNER_TEMP/release-relay.js"
          node "$RUNNER_TEMP/release-relay.js"
      - name: Hand the result to scan-save
        if: ${{ always() }}
        uses: actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02 # v4.6.2
        with:
          name: relay-scan-result
          path: ${{ runner.temp }}/relay-scan/scan.json
          retention-days: 1
          if-no-files-found: ignore

  # Version 27: signs the scan's result and saves it as scan.json on release-relay-results (the scan job can't push).
  scan-save:
    needs: scan
    if: ${{ !cancelled() && needs.scan.result != 'skipped' }}
    runs-on: ubuntu-latest
    environment: relay-signing
    timeout-minutes: 10
    permissions:
      contents: write
      actions: read
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 1
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      - name: Get the scan's result
        continue-on-error: true
        uses: actions/download-artifact@d3f86a106a0bac45b974a628896c90dbdf5c8093 # v4.3.0
        with:
          name: relay-scan-result
          path: ${{ runner.temp }}/relay-scan
      - name: Save the scan result
        env:
          STEP: scan-save
          RELAY_SCAN_FILE: ${{ runner.temp }}/relay-scan/scan.json
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
        run: node scripts/release-relay.js

  validate:
    needs: raise
    if: ${{ !cancelled() && inputs.target_environment != '' && (needs.raise.result == 'success' || inputs.mode == 'check') }}
    runs-on: ubuntu-latest
    permissions:
      contents: write
      actions: read
    environment: ${{ inputs.target_environment }}
    timeout-minutes: 120
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          ref: ${{ inputs.branch }}
          fetch-depth: 0
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      - name: Validate against the target org
        env:
          STEP: validate
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          SOURCE_PATH: ${{ vars.SOURCE_PATH }}
          DEPLOY_TEST_LEVEL: ${{ vars.DEPLOY_TEST_LEVEL }}
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
        # The release branch may hold an older copy of the script: always run the pipeline's own.
        run: |
          git show "$GITHUB_SHA:scripts/release-relay.js" > "$RUNNER_TEMP/release-relay.js"
          node "$RUNNER_TEMP/release-relay.js"

  merge:
    if: ${{ inputs.mode == 'merge' }}
    runs-on: ubuntu-latest
    permissions:
      contents: write
      pull-requests: write
      actions: read
    # Version 27: a run without a source environment uses relay-signing (the run-signing key's environment).
    environment: ${{ inputs.environment || 'relay-signing' }}
    timeout-minutes: 15
    outputs:
      sha: ${{ steps.merge.outputs.sha }}
    steps:
      - name: Create GitHub App token
        id: app
        if: ${{ vars.RELAY_APP_ID != '' }}
        uses: actions/create-github-app-token@d72941d797fd3113feb6b93fd0dec494b13a2547 # v1.12.0
        with:
          app-id: ${{ vars.RELAY_APP_ID }}
          private-key: ${{ secrets.RELAY_APP_PRIVATE_KEY }}
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 0
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      - name: Merge the approved pull request
        id: merge
        env:
          STEP: merge
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          GH_TOKEN: ${{ steps.app.outputs.token || github.token }}
          ALLOWED_TARGETS: ${{ vars.ALLOWED_TARGETS }}
          MERGE_METHOD: ${{ vars.MERGE_METHOD }}
        run: node scripts/release-relay.js

  deploy:
    needs: merge
    if: ${{ inputs.target_environment != '' && needs.merge.result == 'success' }}
    runs-on: ubuntu-latest
    permissions:
      contents: write
      actions: read
    environment: ${{ inputs.target_environment }}
    timeout-minutes: 120
    steps:
      # The deploy needs only the merge commit and its parents (the diff it deploys), not the whole history,
      # plus the pipeline's own commit for the script and its .relay files.
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          ref: ${{ needs.merge.outputs.sha }}
          fetch-depth: 2
      - name: Fetch the pipeline's commit
        run: git cat-file -e "$GITHUB_SHA^{commit}" 2>/dev/null || git fetch --no-tags --depth=1 origin "$GITHUB_SHA"
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      - name: Deploy to the target org
        env:
          STEP: deploy
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          MERGE_SHA: ${{ needs.merge.outputs.sha }}
          SOURCE_PATH: ${{ vars.SOURCE_PATH }}
          DEPLOY_TEST_LEVEL: ${{ vars.DEPLOY_TEST_LEVEL }}
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
        # The release branch may hold an older copy of the script: always run the pipeline's own.
        run: |
          git show "$GITHUB_SHA:scripts/release-relay.js" > "$RUNNER_TEMP/release-relay.js"
          node "$RUNNER_TEMP/release-relay.js"

  # Back promote: production's changes into a back-promote org. Runs in the target org's environment,
  # like deploy, so its login (and any protection rules on that environment) apply.
  sync:
    if: ${{ inputs.mode == 'sync' && inputs.target_environment != '' }}
    runs-on: ubuntu-latest
    permissions:
      contents: write
      actions: read
    environment: ${{ inputs.target_environment }}
    timeout-minutes: 120
    steps:
      # Optional: a GitHub App token, when branch rules only let the app push to the back-promote branch.
      - name: Create GitHub App token
        id: app
        if: ${{ vars.RELAY_APP_ID != '' }}
        uses: actions/create-github-app-token@d72941d797fd3113feb6b93fd0dec494b13a2547 # v1.12.0
        with:
          app-id: ${{ vars.RELAY_APP_ID }}
          private-key: ${{ secrets.RELAY_APP_PRIVATE_KEY }}
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 0
          token: ${{ steps.app.outputs.token || github.token }}
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      - name: Back promote to the target org
        env:
          STEP: sync
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          ALLOWED_TARGETS: ${{ vars.ALLOWED_TARGETS }}
          SOURCE_PATH: ${{ vars.SOURCE_PATH }}
          DEPLOY_TEST_LEVEL: ${{ vars.DEPLOY_TEST_LEVEL }}
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
        # The script checks out other branches: run a copy of the pipeline's own from outside the checkout.
        run: |
          git show "$GITHUB_SHA:scripts/release-relay.js" > "$RUNNER_TEMP/release-relay.js"
          node "$RUNNER_TEMP/release-relay.js"

  # Back promote into a developer org's branch only (version 23): a developer org has no sign-in in GitHub, so no
  # environment and no deploy; the lower branch gets the merge or the picked files.
  sync-branch:
    if: ${{ inputs.mode == 'sync' && inputs.target_environment == '' && fromJSON(inputs.options || '{}').branchOnly == true }}
    runs-on: ubuntu-latest
    # Version 27: no org here, so the run-signing key comes from the relay-signing environment (main only).
    environment: relay-signing
    permissions:
      contents: write
      actions: read
    timeout-minutes: 20
    steps:
      # Optional: a GitHub App token, when branch rules only let the app push to the developer branch.
      - name: Create GitHub App token
        id: app
        if: ${{ vars.RELAY_APP_ID != '' }}
        uses: actions/create-github-app-token@d72941d797fd3113feb6b93fd0dec494b13a2547 # v1.12.0
        with:
          app-id: ${{ vars.RELAY_APP_ID }}
          private-key: ${{ secrets.RELAY_APP_PRIVATE_KEY }}
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 0
          token: ${{ steps.app.outputs.token || github.token }}
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      - name: Back promote into the branch
        env:
          STEP: sync
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          ALLOWED_TARGETS: ${{ vars.ALLOWED_TARGETS }}
          SOURCE_PATH: ${{ vars.SOURCE_PATH }}
        # The script checks out other branches: run a copy of the pipeline's own from outside the checkout.
        run: |
          git show "$GITHUB_SHA:scripts/release-relay.js" > "$RUNNER_TEMP/release-relay.js"
          node "$RUNNER_TEMP/release-relay.js"

  # Rollback: deploys a snapshot (taken before an earlier deploy) back into the org. Runs in the target org's
  # environment, like deploy, so its login and protection rules apply. Release branches aren't touched.
  rollback:
    if: ${{ inputs.mode == 'rollback' && inputs.target_environment != '' }}
    runs-on: ubuntu-latest
    permissions:
      contents: write
      actions: read
    environment: ${{ inputs.target_environment }}
    timeout-minutes: 120
    steps:
      # Only the pipeline's commit is needed: the snapshot is read from release-relay-snapshots.
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 1
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      - name: Roll back the target org
        env:
          STEP: rollback
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          SOURCE_PATH: ${{ vars.SOURCE_PATH }}
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
        run: |
          git show "$GITHUB_SHA:scripts/release-relay.js" > "$RUNNER_TEMP/release-relay.js"
          node "$RUNNER_TEMP/release-relay.js"

  # Tells the Salesforce org that raised the release to read the results now, instead of waiting
  # for its scheduled sync. Signs in with that org's environment; a failure here never fails the run.
  notify:
    needs: [raise, scan, validate, merge, deploy, sync, rollback]
    if: ${{ always() && fromJSON(inputs.options || '{}').notify != null && fromJSON(inputs.options || '{}').notify != '' }}
    runs-on: ubuntu-latest
    permissions:
      contents: read
      actions: read
    environment: ${{ fromJSON(inputs.options || '{}').notify }}
    timeout-minutes: 10
    continue-on-error: true
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          persist-credentials: false
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      - name: Tell Salesforce the run finished
        env:
          STEP: notify
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
        run: node scripts/release-relay.js

  # Compare (version 22): the hub's Compare before raising for a big release. Reads the zips the hub left on
  # release-relay-results, converts them on top of the target branch and writes the result files there. No org login
  # and no environment: the developer org's copy came from the hub.
  compare:
    if: ${{ inputs.mode == 'compare' }}
    runs-on: ubuntu-latest
    # Version 27: no org here, so the run-signing key comes from the relay-signing environment (main only).
    environment: relay-signing
    permissions:
      contents: write
      actions: read
    timeout-minutes: 20
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 0
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      # Inputs reach the script only as environment variables, never inside a shell command.
      - name: Compare with the target branch
        env:
          STEP: compare
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          COMPONENTS: ${{ inputs.components }}
          DELETIONS: ${{ inputs.deletions }}
          ORG_LABEL: ${{ vars.ORG_LABEL }}
          SOURCE_PATH: ${{ vars.SOURCE_PATH }}
        run: node scripts/release-relay.js

  # Sync status, Org vs branch (version 23): reads the whole org in its own environment (its login and protection
  # rules apply) and compares it with its branch. Nothing is pushed except the result on release-relay-results.
  drift:
    if: ${{ inputs.mode == 'drift' && inputs.environment != '' }}
    runs-on: ubuntu-latest
    permissions:
      contents: write
      actions: read
    environment: ${{ inputs.environment }}
    timeout-minutes: 60
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 0
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      # Inputs reach the script only as environment variables, never inside a shell command.
      - name: Compare the org with its branch
        env:
          STEP: drift
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          ORG_LABEL: ${{ vars.ORG_LABEL }}
          SOURCE_PATH: ${{ vars.SOURCE_PATH }}
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
        run: node scripts/release-relay.js

  # Sync status, Down the route (version 23): Git only, no environment and no org.
  routediff:
    if: ${{ inputs.mode == 'routediff' }}
    runs-on: ubuntu-latest
    # Version 27: no org here, so the run-signing key comes from the relay-signing environment (main only).
    environment: relay-signing
    permissions:
      contents: write
      actions: read
    timeout-minutes: 15
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 0
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      - name: Compare the branches down the route
        env:
          STEP: routediff
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          SOURCE_PATH: ${{ vars.SOURCE_PATH }}
        run: node scripts/release-relay.js

  # Move repository (version 26): this repository mirrored into a new, empty one (another provider). Git only, no
  # environment and no org. The target's token is the repository secret RELAY_MIGRATE_TOKEN; the target address comes
  # in options.targetUrl without credentials.
  migrate:
    if: ${{ inputs.mode == 'migrate' }}
    runs-on: ubuntu-latest
    # Version 27: no org here, so the run-signing key comes from the relay-signing environment (main only).
    environment: relay-signing
    permissions:
      contents: write
      actions: read
    timeout-minutes: 120
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 1
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      - name: Copy the repository to the new one
        env:
          STEP: migrate
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          RELAY_MIGRATE_TOKEN: ${{ secrets.RELAY_MIGRATE_TOKEN }}
          RELAY_MIGRATE_USER: ${{ vars.RELAY_MIGRATE_USER }}
        run: node scripts/release-relay.js

  # Data sets (version 24): the source's records, saved to release-relay-results (data-inbox/<id>/). Skipped when the
  # hub already sent them (a developer org has no sign-in here).
  data-export:
    if: ${{ inputs.mode == 'data' && inputs.environment != '' }}
    runs-on: ubuntu-latest
    permissions:
      contents: write
      actions: read
    environment: ${{ inputs.environment }}
    timeout-minutes: 30
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 0
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      # Inputs reach the script only as environment variables, never inside a shell command.
      - name: Export the data set's records
        env:
          STEP: data-export
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          ORG_LABEL: ${{ vars.ORG_LABEL }}
          SOURCE_PATH: ${{ vars.SOURCE_PATH }}
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
        run: node scripts/release-relay.js

  # Data sets (version 24): dry run (counts only) or load into the target, from the saved records.
  data-load:
    needs: [data-export]
    if: ${{ always() && inputs.mode == 'data' && inputs.target_environment != '' && (needs.data-export.result == 'success' || needs.data-export.result == 'skipped') }}
    runs-on: ubuntu-latest
    permissions:
      contents: write
      actions: read
    environment: ${{ inputs.target_environment }}
    timeout-minutes: 60
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 0
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      - name: Dry run or load the data set
        env:
          STEP: data-load
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
          OPTIONS: ${{ inputs.options }}
          ORG_LABEL: ${{ vars.ORG_LABEL }}
          SOURCE_PATH: ${{ vars.SOURCE_PATH }}
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
        run: node scripts/release-relay.js

  # Nightly archive (schedule only): signs in to the hub with its environment's login (as the other jobs do) and
  # calls the archive endpoint once per pass until it answers done (at most 25 calls). Each call's answer is logged.
  # The hub decides: it skips (and says why) unless it is the production hub, the user has Release Relay Admin,
  # "Archive every night" is on and Retention days are set. No script from the repository is needed.
  archive:
    if: ${{ (github.event_name == 'schedule' && github.event.schedule == '0 8 * * *') || inputs.mode == 'archive' }}
    runs-on: ubuntu-latest
    environment: ${{ vars.RELAY_HUB_ENVIRONMENT || 'prod' }}
    permissions:
      contents: read
      actions: read
    timeout-minutes: 30
    steps:
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # Version 27: started by hand (not the schedule), the run must carry the hub's signature.
      - name: Get the pipeline script
        if: ${{ github.event_name != 'schedule' }}
        uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 1
          persist-credentials: false
      - name: Check the run's signature
        if: ${{ github.event_name != 'schedule' }}
        env:
          STEP: verify
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
        run: node scripts/release-relay.js
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      - name: Archive finished releases in the hub
        env:
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
          RUN_URL: ${{ github.server_url }}/${{ github.repository }}/actions/runs/${{ github.run_id }}
        # Secrets reach the shell only as environment variables. The key is written like the script does it:
        # SF_JKS (keystore, base64) with SF_JKS_PASSWORD and SF_JKS_ALIAS, or SF_JWT_KEY (base64 PEM private key).
        run: |
          set -euo pipefail
          for name in SF_USERNAME SF_CLIENT_ID SF_INSTANCE_URL; do
            if [ -z "${!name:-}" ]; then
              echo "::error::$name isn't set for the hub's environment."
              exit 1
            fi
          done
          key="$RUNNER_TEMP/relay.key"
          if [ -n "${SF_JKS:-}" ]; then
            if [ -z "${SF_JKS_PASSWORD:-}" ] || [ -z "${SF_JKS_ALIAS:-}" ]; then
              echo "::error::SF_JKS is set, so SF_JKS_PASSWORD (secret) and SF_JKS_ALIAS (variable) are needed too."
              exit 1
            fi
            dir="$(mktemp -d)"
            printf '%s' "$SF_JKS" | base64 -d > "$dir/store.jks"
            export RELAY_PW="$SF_JKS_PASSWORD"
            keytool -importkeystore -noprompt -srckeystore "$dir/store.jks" -srcstoretype JKS -srcstorepass:env RELAY_PW \
              -srckeypass:env RELAY_PW -srcalias "$SF_JKS_ALIAS" -destkeystore "$dir/store.p12" -deststoretype PKCS12 \
              -deststorepass:env RELAY_PW -destkeypass:env RELAY_PW > /dev/null
            openssl pkcs12 -in "$dir/store.p12" -nocerts -nodes -passin env:RELAY_PW -out "$key" 2> /dev/null
            rm -rf "$dir"
          elif [ -n "${SF_JWT_KEY:-}" ]; then
            printf '%s' "$SF_JWT_KEY" | base64 -d > "$key"
          else
            echo "::error::Set SF_JKS (keystore from Salesforce) or SF_JWT_KEY (private key) for the hub's environment."
            exit 1
          fi
          chmod 600 "$key"
          sf org login jwt --client-id "$SF_CLIENT_ID" --username "$SF_USERNAME" --jwt-key-file "$key" \
            --instance-url "$SF_INSTANCE_URL" --alias relay-hub > /dev/null
          rm -f "$key"
          run_id=""
          for call in $(seq 1 25); do
            body="$(jq -n --arg runUrl "$RUN_URL" --arg runId "$run_id" \
              '{runUrl: $runUrl} + (if $runId == "" then {} else {runId: $runId} end)')"
            # The CLI signs the call itself (sf org display hides the access token since CLI 2.15x).
            answer="$(sf api request rest /services/apexrest/rly/archive --method POST \
              --body "$body" --target-org relay-hub)"
            if [ "$(printf '%s' "$answer" | jq -r '.skipped')" = "true" ]; then
              echo "Call $call: $(printf '%s' "$answer" | jq -r '.reason')"
              echo "Nightly archive: $(printf '%s' "$answer" | jq -r '.reason')" >> "$GITHUB_STEP_SUMMARY"
              break
            fi
            line="$(printf '%s' "$answer" | jq -r '"Pass \(.pass): \(.removed) releases, \(.records) records removed, \(.remaining // "?") eligible left, \(.pipelineRuns // 0) old monitor runs removed. \(.reason // "")"')"
            echo "$line"
            echo "- $line" >> "$GITHUB_STEP_SUMMARY"
            run_id="$(printf '%s' "$answer" | jq -r '.runId // ""')"
            if [ "$(printf '%s' "$answer" | jq -r '.done')" = "true" ]; then
              case "$line" in
                *" failed: "*) echo "::warning::The archive pass failed; the hub's Archive tab has the details. The next night carries on." ;;
              esac
              break
            fi
          done

  # Slack reminders and daily digests (version 24): every hour at :17 (or mode "slack" by hand). Signs in to the hub
  # like the archive job and calls the slack-due endpoint once per pass until it answers done (at most 10 calls). The
  # hub skips (and says why) unless it is the production hub, the user has Release Relay Admin and Slack is connected;
  # an org with reminders and the digest off is never read. Repository variable RELAY_SLACK_DUE=off skips this job.
  slack-due:
    if: ${{ vars.RELAY_SLACK_DUE != 'off' && ((github.event_name == 'schedule' && github.event.schedule == '17 * * * *') || inputs.mode == 'slack') }}
    runs-on: ubuntu-latest
    environment: ${{ vars.RELAY_HUB_ENVIRONMENT || 'prod' }}
    permissions:
      contents: read
      actions: read
    timeout-minutes: 15
    steps:
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # Version 27: started by hand (not the schedule), the run must carry the hub's signature.
      - name: Get the pipeline script
        if: ${{ github.event_name != 'schedule' }}
        uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 1
          persist-credentials: false
      - name: Check the run's signature
        if: ${{ github.event_name != 'schedule' }}
        env:
          STEP: verify
          RELAY_RUN_KEY: ${{ secrets.RELAY_RUN_KEY }}
          RELAY_RUN_READ_TOKEN: ${{ github.token }}
        run: node scripts/release-relay.js
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      - name: Send due Slack reminders and digests
        env:
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
          RUN_URL: ${{ github.server_url }}/${{ github.repository }}/actions/runs/${{ github.run_id }}
        # Secrets reach the shell only as environment variables; the key is written as the archive job writes it.
        run: |
          set -euo pipefail
          for name in SF_USERNAME SF_CLIENT_ID SF_INSTANCE_URL; do
            if [ -z "${!name:-}" ]; then
              echo "::error::$name isn't set for the hub's environment."
              exit 1
            fi
          done
          key="$RUNNER_TEMP/relay.key"
          if [ -n "${SF_JKS:-}" ]; then
            if [ -z "${SF_JKS_PASSWORD:-}" ] || [ -z "${SF_JKS_ALIAS:-}" ]; then
              echo "::error::SF_JKS is set, so SF_JKS_PASSWORD (secret) and SF_JKS_ALIAS (variable) are needed too."
              exit 1
            fi
            dir="$(mktemp -d)"
            printf '%s' "$SF_JKS" | base64 -d > "$dir/store.jks"
            export RELAY_PW="$SF_JKS_PASSWORD"
            keytool -importkeystore -noprompt -srckeystore "$dir/store.jks" -srcstoretype JKS -srcstorepass:env RELAY_PW \
              -srckeypass:env RELAY_PW -srcalias "$SF_JKS_ALIAS" -destkeystore "$dir/store.p12" -deststoretype PKCS12 \
              -deststorepass:env RELAY_PW -destkeypass:env RELAY_PW > /dev/null
            openssl pkcs12 -in "$dir/store.p12" -nocerts -nodes -passin env:RELAY_PW -out "$key" 2> /dev/null
            rm -rf "$dir"
          elif [ -n "${SF_JWT_KEY:-}" ]; then
            printf '%s' "$SF_JWT_KEY" | base64 -d > "$key"
          else
            echo "::error::Set SF_JKS (keystore from Salesforce) or SF_JWT_KEY (private key) for the hub's environment."
            exit 1
          fi
          chmod 600 "$key"
          sf org login jwt --client-id "$SF_CLIENT_ID" --username "$SF_USERNAME" --jwt-key-file "$key" \
            --instance-url "$SF_INSTANCE_URL" --alias relay-hub > /dev/null
          rm -f "$key"
          for call in $(seq 1 10); do
            body="$(jq -n --arg runUrl "$RUN_URL" --argjson pass "$call" '{runUrl: $runUrl, pass: $pass}')"
            answer="$(sf api request rest /services/apexrest/rly/slack-due --method POST --body "$body" --target-org relay-hub)"
            line="$(printf '%s' "$answer" | jq -r '"Pass \(.pass // 0): \(.sent // 0) sent, \(.skipped // 0) skipped. \(.reason // "")"')"
            echo "$line"
            echo "- $line" >> "$GITHUB_STEP_SUMMARY"
            if [ "$(printf '%s' "$answer" | jq -r '.done // true')" = "true" ]; then
              break
            fi
          done

  # Pipeline Monitor (version 20): tells the hub this run started, for its Pipeline Monitor tab. Signs in with the hub
  # environment's login (as the archive job does) and posts to /services/apexrest/rly/pipeline-run. It runs beside the
  # other jobs and never fails the run: a failed call is a warning. Repository variable RELAY_MONITOR=off skips it.
  monitor-start:
    if: ${{ vars.RELAY_MONITOR != 'off' && github.event.schedule != '17 * * * *' && inputs.mode != 'slack' }}
    runs-on: ubuntu-latest
    environment: ${{ vars.RELAY_HUB_ENVIRONMENT || 'prod' }}
    timeout-minutes: 10
    continue-on-error: true
    permissions:
      actions: read
      contents: read
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 1
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      - name: Tell the hub the run started
        env:
          STEP: monitor
          MONITOR_STATUS: in_progress
          GH_TOKEN: ${{ github.token }}
          RELAY_HUB_ENVIRONMENT: ${{ vars.RELAY_HUB_ENVIRONMENT || 'prod' }}
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
        run: |
          node scripts/release-relay.js || echo "::warning::Pipeline Monitor: couldn't tell the hub this run started; the run isn't affected."

  # Pipeline Monitor (version 20): after every other job (always, also when one failed or the run was cancelled) tells
  # the hub how the run ended: Succeeded, Failed or Cancelled from the jobs' results, the finished time and duration,
  # each job's outcome and the first failure (read from this run with its own token: actions and checks read). Never fails the run.
  monitor-end:
    needs: [monitor-start, raise, scan, scan-save, validate, merge, deploy, sync, sync-branch, rollback, notify, archive, compare, drift, routediff, data-export, data-load, migrate]
    if: ${{ always() && vars.RELAY_MONITOR != 'off' && github.event.schedule != '17 * * * *' && inputs.mode != 'slack' }}
    runs-on: ubuntu-latest
    environment: ${{ vars.RELAY_HUB_ENVIRONMENT || 'prod' }}
    timeout-minutes: 10
    continue-on-error: true
    permissions:
      actions: read
      checks: read
      contents: read
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
        with:
          fetch-depth: 1
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020 # v4.4.0
        with:
          node-version: 22
      # The Salesforce CLI (pinned, version 27) is cached per runner OS and CLI version, so most runs skip the install.
      - name: Salesforce CLI cache key
        id: sfkey
        run: echo "key=relay-sf-cli-2.135.7-${RUNNER_OS}-node22" >> "$GITHUB_OUTPUT"
      - name: Cache Salesforce CLI
        uses: actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830 # v4.3.0
        with:
          path: ~/.relay-sf
          key: ${{ steps.sfkey.outputs.key }}
      - name: Install Salesforce CLI
        run: |
          # Version 27: from outside the checkout, so a release branch's .npmrc never applies.
          cd "$RUNNER_TEMP"
          [ -x "$HOME/.relay-sf/bin/sf" ] || npm install --global --prefix "$HOME/.relay-sf" @salesforce/cli@2.135.7 --no-audit --no-fund
          echo "$HOME/.relay-sf/bin" >> "$GITHUB_PATH"
      - name: Tell the hub how the run ended
        env:
          STEP: monitor
          MONITOR_STATUS: end
          NEEDS_JSON: ${{ toJSON(needs) }}
          GH_TOKEN: ${{ github.token }}
          RELAY_HUB_ENVIRONMENT: ${{ vars.RELAY_HUB_ENVIRONMENT || 'prod' }}
          SF_INSTANCE_URL: ${{ vars.SF_INSTANCE_URL }}
          SF_USERNAME: ${{ secrets.SF_USERNAME }}
          SF_CLIENT_ID: ${{ secrets.SF_CLIENT_ID }}
          SF_JWT_KEY: ${{ secrets.SF_JWT_KEY }}
          SF_JKS: ${{ secrets.SF_JKS }}
          SF_JKS_PASSWORD: ${{ secrets.SF_JKS_PASSWORD }}
          SF_JKS_ALIAS: ${{ vars.SF_JKS_ALIAS }}
        run: |
          node scripts/release-relay.js || echo "::warning::Pipeline Monitor: couldn't tell the hub how this run ended; the run isn't affected."
