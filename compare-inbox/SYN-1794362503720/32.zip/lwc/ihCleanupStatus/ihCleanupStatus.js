import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getStatus from '@salesforce/apex/IntegrationHubCleanupStatus.getStatus';
import scheduleCleanup from '@salesforce/apex/IntegrationHubCleanupStatus.scheduleCleanup';
import scheduleAutoRetry from '@salesforce/apex/IntegrationHubCleanupStatus.scheduleAutoRetry';
import { errorMessage } from 'c/ihNav';

/**
 * Monitor card "Scheduled jobs": the nightly clean-up (is it scheduled, next and last run, what the last run deleted
 * and timed out) and auto-retry (are its four jobs scheduled, how many transactions wait and when the next one is due),
 * each with a Schedule button when its jobs are missing (for example after a sandbox refresh). Admins only.
 */
export default class IhCleanupStatus extends LightningElement {
    status;
    error;
    loading = true;
    busy = false;

    connectedCallback() {
        this.load();
    }

    /** Reloads the card; the Monitor calls this from its Refresh button. */
    @api
    async refresh() {
        await this.load();
    }

    async load() {
        try {
            this.status = await getStatus();
            this.error = undefined;
        } catch (e) {
            this.error = errorMessage(e, 'Could not load the scheduled jobs.');
        } finally {
            this.loading = false;
        }
    }

    get scheduled() {
        return Boolean(this.status && this.status.scheduled);
    }

    get notScheduled() {
        return Boolean(this.status && !this.status.scheduled);
    }

    get badgeClass() {
        return 'ih-badge ' + (this.scheduled ? 'ih-badge_on' : 'ih-badge_off_bad');
    }

    get badgeText() {
        return this.scheduled ? 'Scheduled' : 'Not scheduled';
    }

    get hasLastRun() {
        return Boolean(this.status && this.status.lastFinished);
    }

    get deletedText() {
        return this.number(this.status && this.status.lastDeleted);
    }

    get timedOutText() {
        return this.number(this.status && this.status.lastTimedOut);
    }

    // The job started after the last saved result: still running, or it failed before saving.
    get lastRunMissing() {
        const s = this.status;
        if (!s || !s.previousRun) {
            return false;
        }
        return !s.lastFinished || new Date(s.lastFinished) < new Date(s.previousRun);
    }

    /* ---------------- auto-retry ---------------- */

    get autoRetryAll() {
        const s = this.status;
        return Boolean(s && s.autoRetryJobs >= s.autoRetryJobsExpected);
    }

    get autoRetryMissing() {
        return Boolean(this.status) && !this.autoRetryAll;
    }

    get autoRetryBadgeClass() {
        return 'ih-badge ' + (this.autoRetryAll ? 'ih-badge_on' : 'ih-badge_off_bad');
    }

    get autoRetryBadgeText() {
        const s = this.status;
        if (!s) {
            return '';
        }
        if (this.autoRetryAll) {
            return 'Scheduled';
        }
        return s.autoRetryJobs ? `${s.autoRetryJobs} of ${s.autoRetryJobsExpected} scheduled` : 'Not scheduled';
    }

    get waitingText() {
        return this.number(this.status && this.status.waitingForRetry) + (this.status && this.status.waitingForRetry >= 10000 ? '+' : '');
    }

    get hasWaiting() {
        return Boolean(this.status && this.status.waitingForRetry);
    }

    async handleScheduleAutoRetry() {
        this.busy = true;
        try {
            this.status = await scheduleAutoRetry();
            this.error = undefined;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Done', variant: 'success',
                message: 'Auto-retry is scheduled every 15 minutes and runs as you.'
            }));
        } catch (e) {
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error', variant: 'error', message: errorMessage(e, 'Auto-retry could not be scheduled.')
            }));
        } finally {
            this.busy = false;
        }
    }

    number(value) {
        return value == null ? '0' : Number(value).toLocaleString();
    }

    async handleSchedule() {
        this.busy = true;
        try {
            this.status = await scheduleCleanup();
            this.error = undefined;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Done', variant: 'success',
                message: 'The nightly clean-up is scheduled for 02:00, and auto-retry every 15 minutes. They run as you.'
            }));
        } catch (e) {
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error', variant: 'error', message: errorMessage(e, 'The clean-up could not be scheduled.')
            }));
        } finally {
            this.busy = false;
        }
    }
}