import { LightningElement, api } from 'lwc';

// Quoted strings; a string followed by a colon is a JSON key.
const TOKEN = /"(?:\\.|[^"\\\n])*"(\s*:)?/g;
// Very long bodies are shown as plain text (thousands of spans slow the page down).
const HIGHLIGHT_MAX = 40000;

/**
 * Mono text box for requests, answers and JSON bodies: keeps line breaks, scrolls inside a fixed height and
 * colours JSON keys and string values. Text only, never HTML.
 */
export default class IhCode extends LightningElement {
    @api text = '';
    /** CSS max-height of the box, e.g. 360px; 'none' (or empty) means no limit. */
    @api maxHeight = '360px';
    /** Muted look for placeholder text (e.g. "None expected for this event"). */
    @api muted = false;

    get boxClass() {
        return this.muted ? 'code code_muted' : 'code';
    }

    get boxStyle() {
        return this.maxHeight && this.maxHeight !== 'none' ? `max-height: ${this.maxHeight};` : '';
    }

    get parts() {
        const text = this.text == null ? '' : String(this.text);
        if (!text || text.length > HIGHLIGHT_MAX) {
            return [{ k: 0, c: '', t: text }];
        }
        const out = [];
        let last = 0;
        let m;
        TOKEN.lastIndex = 0;
        while ((m = TOKEN.exec(text)) !== null) {
            if (m.index > last) {
                out.push({ k: out.length, c: '', t: text.slice(last, m.index) });
            }
            if (m[1]) {
                const key = m[0].slice(0, m[0].length - m[1].length);
                out.push({ k: out.length, c: 'tk_key', t: key });
                out.push({ k: out.length, c: '', t: m[1] });
            } else {
                out.push({ k: out.length, c: 'tk_str', t: m[0] });
            }
            last = m.index + m[0].length;
        }
        if (last < text.length) {
            out.push({ k: out.length, c: '', t: text.slice(last) });
        }
        return out;
    }
}