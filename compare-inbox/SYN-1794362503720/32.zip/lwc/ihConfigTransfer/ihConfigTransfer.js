import { LightningElement, api, wire } from 'lwc';
import { gql, graphql, refreshGraphQL } from 'lightning/uiGraphQLApi';
import { createRecord, updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import isAdmin from '@salesforce/customPermission/Integration_Hub_Admin';

const FORMAT = 'integration-hub-lite/1';
const CONN_FIELDS = ['Name', 'Named_Credential__c', 'Active__c', 'Timeout_Seconds__c', 'Headers__c', 'Description__c',
    'Connection_Type__c', 'Auth_Class__c'];
const EVENT_FIELDS = ['Name', 'Event_Key__c', 'Direction__c', 'Active__c', 'Related_Object__c', 'Path__c', 'Http_Method__c',
    'Payload_Source__c', 'Payload_Fields__c', 'Payload_Class__c', 'Transaction_Id_Key__c', 'Expects_Callback__c', 'Callback_Timeout_Hours__c', 'Response_Handler_Class__c',
    'Business_Data_In_Response__c', 'Share_With_Related_Record__c', 'Handler_Class__c', 'Retention_Days__c', 'Description__c',
    'Auto_Retry_Max__c', 'Retry_After_Minutes__c'];

const valueOf = (node, f) => (node[f] ? node[f].value : null);
const errorText = (e) => (e && e.body && e.body.message) || (e && e.message) || 'Unknown error';

/**
 * Export and import of Integration Hub connections and their events, as one JSON file. No Apex:
 * reads with GraphQL, writes with createRecord / updateRecord in the user's own access (Integration Hub Admin).
 * Connections match by Name, events by Event Key. Inbound User is never exported (each org has its own user).
 */
export default class IhConfigTransfer extends LightningElement {
    /** Set when shown inside another page (the How To tab): hides the page header. */
    @api embedded = false;

    connections = [];
    events = [];
    selected = new Set();
    loaded = false;
    error;
    graphqlResult;

    fileName;
    file;
    plan = [];
    importInactive = true;
    busy = false;
    results = [];

    get showHero() {
        return !this.embedded;
    }

    get pageClass() {
        return this.embedded ? 'ih-page ih-page_embedded' : 'ih-page';
    }

    get isAdmin() {
        return isAdmin;
    }

    @wire(graphql, {
        query: gql`
            query hubConfig {
                uiapi {
                    query {
                        IH_Connection__c(first: 200, orderBy: { Name: { order: ASC } }) {
                            edges { node { Id Name { value } Named_Credential__c { value } Active__c { value }
                                Timeout_Seconds__c { value } Headers__c { value } Description__c { value }
                                Connection_Type__c { value } Auth_Class__c { value } } }
                        }
                        IH_Event__c(first: 1000, orderBy: { Name: { order: ASC } }) {
                            edges { node { Id Name { value } Event_Key__c { value } Direction__c { value } Active__c { value }
                                Related_Object__c { value } Connection__c { value } Path__c { value } Http_Method__c { value }
                                Payload_Source__c { value } Payload_Fields__c { value } Payload_Class__c { value } Transaction_Id_Key__c { value } Expects_Callback__c { value }
                                Callback_Timeout_Hours__c { value } Response_Handler_Class__c { value } Business_Data_In_Response__c { value }
                                Share_With_Related_Record__c { value } Handler_Class__c { value } Retention_Days__c { value }
                                Description__c { value } Auto_Retry_Max__c { value } Retry_After_Minutes__c { value } } }
                        }
                    }
                }
            }
        `
    })
    wiredConfig(result) {
        this.graphqlResult = result;
        if (result.data) {
            const q = result.data.uiapi.query;
            this.connections = q.IH_Connection__c.edges.map((e) => e.node);
            this.events = q.IH_Event__c.edges.map((e) => e.node);
            if (!this.loaded) {
                this.selected = new Set(this.connections.map((c) => c.Id));
            }
            this.loaded = true;
            this.error = undefined;
        } else if (result.errors) {
            this.error = result.errors.map((e) => e.message).join(', ');
        }
    }

    /* ---------------- export ---------------- */

    get connectionRows() {
        return this.connections.map((c) => ({
            id: c.Id,
            name: valueOf(c, 'Name'),
            credential: valueOf(c, 'Named_Credential__c'),
            checked: this.selected.has(c.Id),
            eventCount: this.events.filter((e) => valueOf(e, 'Connection__c') === c.Id).length + ' event(s)'
        }));
    }

    get hasConnections() {
        return this.connections.length > 0;
    }

    get exportDisabled() {
        return this.selected.size === 0;
    }

    handlePick(event) {
        const next = new Set(this.selected);
        if (event.target.checked) {
            next.add(event.target.dataset.id);
        } else {
            next.delete(event.target.dataset.id);
        }
        this.selected = next;
    }

    handleExport() {
        const conns = this.connections.filter((c) => this.selected.has(c.Id));
        const names = new Map(conns.map((c) => [c.Id, valueOf(c, 'Name')]));
        const file = {
            format: FORMAT,
            exportedAt: new Date().toISOString(),
            note: 'Inbound User is not included: set it on each connection in the new org.',
            connections: conns.map((c) => Object.fromEntries(CONN_FIELDS.map((f) => [f, valueOf(c, f)]))),
            events: this.events
                .filter((e) => names.has(valueOf(e, 'Connection__c')))
                .map((e) => ({
                    ...Object.fromEntries(EVENT_FIELDS.map((f) => [f, valueOf(e, f)])),
                    connectionName: names.get(valueOf(e, 'Connection__c'))
                }))
        };
        const link = document.createElement('a');
        link.href = 'data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(file, null, 2));
        link.download = 'integration-hub-config-' + new Date().toISOString().slice(0, 10) + '.json';
        link.click();
        this.toast('success', `Exported ${file.connections.length} connection(s) and ${file.events.length} event(s).`);
    }

    /* ---------------- import ---------------- */

    handleFile(event) {
        const f = event.target.files && event.target.files[0];
        this.results = [];
        this.plan = [];
        this.file = undefined;
        this.error = undefined;
        if (!f) {
            return;
        }
        this.fileName = f.name;
        const reader = new FileReader();
        reader.onload = () => {
            try {
                const data = JSON.parse(reader.result);
                if (data.format !== FORMAT || !Array.isArray(data.connections) || !Array.isArray(data.events)) {
                    throw new Error('This is not an Integration Hub export file.');
                }
                this.file = data;
                this.buildPlan();
            } catch (e) {
                this.error = 'Cannot read the file: ' + e.message;
            }
        };
        reader.readAsText(f);
    }

    buildPlan() {
        const connByName = new Map(this.connections.map((c) => [String(valueOf(c, 'Name')).toLowerCase(), c]));
        const eventByKey = new Map(this.events.map((e) => [String(valueOf(e, 'Event_Key__c')).toUpperCase(), e]));
        const rows = [];
        this.file.connections.forEach((c, i) => {
            const existing = connByName.get(String(c.Name).toLowerCase());
            rows.push({ key: 'c' + i, kind: 'Connection', name: c.Name, action: existing ? 'Update' : 'Create', existingId: existing && existing.Id, data: c });
        });
        this.file.events.forEach((e, i) => {
            const existing = eventByKey.get(String(e.Event_Key__c).toUpperCase());
            rows.push({ key: 'e' + i, kind: 'Event', name: e.Event_Key__c, action: existing ? 'Update' : 'Create', existingId: existing && existing.Id, data: e });
        });
        this.plan = rows;
    }

    get hasPlan() {
        return this.plan.length > 0;
    }

    get planRows() {
        const byKey = new Map(this.results.map((r) => [r.key, r]));
        return this.plan.map((p) => {
            const r = byKey.get(p.key);
            return { ...p, result: r ? r.text : '', resultClass: r ? (r.ok ? 'ih-ok-text' : 'ih-bad-text') : '' };
        });
    }

    handleInactive(event) {
        this.importInactive = event.target.checked;
    }

    async handleImport() {
        this.busy = true;
        const results = [];
        const connIds = new Map(this.connections.map((c) => [String(valueOf(c, 'Name')).toLowerCase(), c.Id]));
        for (const p of this.plan.filter((x) => x.kind === 'Connection')) {
            const fields = Object.fromEntries(CONN_FIELDS.filter((f) => p.data[f] !== undefined).map((f) => [f, p.data[f]]));
            // eslint-disable-next-line no-await-in-loop
            const id = await this.save('IH_Connection__c', p, fields, results);
            if (id) {
                connIds.set(String(p.data.Name).toLowerCase(), id);
            }
        }
        for (const p of this.plan.filter((x) => x.kind === 'Event')) {
            const fields = Object.fromEntries(EVENT_FIELDS.filter((f) => p.data[f] !== undefined).map((f) => [f, p.data[f]]));
            fields.Connection__c = connIds.get(String(p.data.connectionName || '').toLowerCase()) || null;
            if (this.importInactive) {
                fields.Active__c = false;
            }
            // eslint-disable-next-line no-await-in-loop
            await this.save('IH_Event__c', p, fields, results);
        }
        this.results = results;
        this.busy = false;
        const failed = results.filter((r) => !r.ok).length;
        this.toast(failed ? 'warning' : 'success', failed ? `${failed} item(s) could not be imported. See the list.`
            : 'Imported. Set the Inbound User on each connection, check the Named Credentials, then switch the events on.');
        await refreshGraphQL(this.graphqlResult);
    }

    async save(apiName, p, fields, results) {
        try {
            if (p.existingId) {
                await updateRecord({ fields: { Id: p.existingId, ...fields } });
                results.push({ key: p.key, ok: true, text: 'Updated' });
                return p.existingId;
            }
            const rec = await createRecord({ apiName, fields });
            results.push({ key: p.key, ok: true, text: 'Created' });
            return rec.id;
        } catch (e) {
            results.push({ key: p.key, ok: false, text: errorText(e) });
            return null;
        }
    }

    get importDisabled() {
        return this.busy || !this.hasPlan;
    }

    toast(variant, message) {
        this.dispatchEvent(new ShowToastEvent({ title: variant === 'success' ? 'Done' : 'Check', message, variant }));
    }
}