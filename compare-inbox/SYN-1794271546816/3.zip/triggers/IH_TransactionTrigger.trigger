/**
 * Integration Hub transaction trigger: one line. The logic is in IntegrationHub.handleTrigger().
 */
trigger IH_TransactionTrigger on IH_Transaction__c (after insert, after update) {
    IntegrationHub.handleTrigger();
}