import { LightningElement, api, wire } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import isAdmin from '@salesforce/customPermission/Integration_Hub_Admin';
import checkEvent from '@salesforce/apex/IntegrationHubEndpointCheck.checkEvent';
import DIRECTION_FIELD from '@salesforce/schema/IH_Event__c.Direction__c';
import EVENT_KEY_FIELD from '@salesforce/schema/IH_Event__c.Event_Key__c';
import RELATED_OBJECT_FIELD from '@salesforce/schema/IH_Event__c.Related_Object__c';
import IhPayloadPreview from 'c/ihPayloadPreview';
import { errorMessage } from 'c/ihNav';

const BAD_CODES = [401, 403, 404];

/**
 * Integration Event page card (admins). Outbound: Check endpoint, one GET to the event's Named Credential URL plus
 * its Path with no body and no record data, so the exact endpoint the event sends to is tested. Outbound and
 * inbound: Preview payload, the request the event builds for one record (nothing is sent or saved).
 */
export default class IhEventCheck extends LightningElement {
    @api recordId;

    checking = false;
    result;
    event;

    @wire(getRecord, { recordId: '$recordId', optionalFields: [DIRECTION_FIELD, EVENT_KEY_FIELD, RELATED_OBJECT_FIELD] })
    wiredEvent({ data }) {
        if (data) {
            this.event = data;
        }
    }

    get direction() {
        return this.event ? getFieldValue(this.event, DIRECTION_FIELD) : undefined;
    }

    /** Unknown direction (record not loaded yet) behaves as outbound, as the card always did. */
    get isOutbound() {
        return this.direction !== 'Inbound';
    }

    get cardTitle() {
        return this.isOutbound ? 'Endpoint check' : 'Inbound call preview';
    }

    get canCheck() {
        return isAdmin;
    }

    get good() {
        return Boolean(this.result && this.result.reached && !BAD_CODES.includes(this.result.statusCode));
    }

    get resultClass() {
        return 'result ' + (this.good ? 'result_ok' : 'result_bad');
    }

    get resultIcon() {
        return this.good ? 'utility:success' : 'utility:error';
    }

    get resultTime() {
        return this.result && this.result.millis != null ? `${this.result.millis} ms` : '';
    }

    async handleCheck() {
        this.checking = true;
        this.result = undefined;
        try {
            this.result = await checkEvent({ eventId: this.recordId });
        } catch (e) {
            this.result = { reached: false, message: errorMessage(e, 'The check could not run.') };
        } finally {
            this.checking = false;
        }
    }

    async handlePreview() {
        await IhPayloadPreview.open({
            size: 'large',
            label: 'Preview payload',
            eventId: this.recordId,
            eventKey: this.event ? getFieldValue(this.event, EVENT_KEY_FIELD) : '',
            direction: this.direction,
            relatedObject: this.event ? getFieldValue(this.event, RELATED_OBJECT_FIELD) : ''
        });
    }
}