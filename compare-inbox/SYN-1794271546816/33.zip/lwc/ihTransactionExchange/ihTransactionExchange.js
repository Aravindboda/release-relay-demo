import { api } from 'lwc';
import LightningModal from 'lightning/modal';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getExchange from '@salesforce/apex/IntegrationHubPreview.getExchange';
import rerun from '@salesforce/apex/IntegrationHubBusiness.rerun';
import { errorMessage, retryLine } from 'c/ihNav';

// After a rerun the handler runs in the background: reload every few seconds while Business Status is Processing.
const POLL_MS = 3000;
const POLL_TRIES = 20;

const BUSINESS_TONE = { Done: 'tone tone_ok', Failed: 'tone tone_bad', Processing: 'tone tone_info' };

/**
 * View request modal of one Integration Transaction: request, answer, callback, business processing (with Rerun
 * handler for admins, confirmed inside the modal) and attempts.
 * Open with IhTransactionExchange.open({ size: 'large', transactionId, label: 'View request' }).
 */
export default class IhTransactionExchange extends NavigationMixin(LightningModal) {
    @api transactionId;

    ex;
    error;
    loading = true;
    confirming = false;
    rerunning = false;
    pollTimer;
    pollTries = 0;
    isAlive = false;

    connectedCallback() {
        this.isAlive = true;
        this.load();
    }

    disconnectedCallback() {
        this.isAlive = false;
        clearTimeout(this.pollTimer);
    }

    async load() {
        try {
            this.ex = await getExchange({ transactionId: this.transactionId });
            this.error = undefined;
        } catch (e) {
            this.error = errorMessage(e, 'The request could not be loaded.');
        } finally {
            this.loading = false;
        }
    }

    /* ---------------- header ---------------- */

    get conn() {
        return (this.ex && this.ex.connectionName) || 'the middleware';
    }

    get isInbound() {
        return Boolean(this.ex && this.ex.direction === 'Inbound');
    }

    get headerLabel() {
        if (this.confirming) {
            return `Rerun handler · ${this.ex.name}`;
        }
        if (!this.ex) {
            return 'View request';
        }
        return this.isInbound ? `What ${this.conn} sent us · ${this.ex.name}` : `What was sent to ${this.conn} · ${this.ex.name}`;
    }

    get showMain() {
        return Boolean(this.ex) && !this.confirming;
    }

    get introStart() {
        return this.isInbound ? 'Exactly as received on' : 'Exactly as sent on';
    }

    get hasSentAt() {
        return Boolean(this.ex && this.ex.sentAt);
    }

    /** "Will retry automatically at 10:45 (2 of 3)" while a Failed transaction waits for auto-retry. */
    get retryText() {
        const ex = this.ex;
        return ex ? retryLine(ex.nextRetryAt, ex.autoRetries, ex.autoRetryMax) : '';
    }

    /* ---------------- 1. request ---------------- */

    get requestTitle() {
        return this.isInbound ? `1. Request from ${this.conn}` : '1. Request';
    }

    get requestText() {
        const ex = this.ex || {};
        const lines = [];
        if (ex.requestUrl) {
            lines.push(ex.requestUrl);
        }
        (ex.requestHeaders || []).forEach((h) => lines.push(`${h.name}: ${h.value}`));
        let text = lines.join('\n');
        if (ex.requestBody) {
            text = text ? `${text}\n\n${ex.requestBody}` : ex.requestBody;
        }
        return text || 'Nothing stored for this request.';
    }

    get requestCut() {
        return Boolean(this.ex && this.ex.requestCut && this.ex.requestFileId);
    }

    /* ---------------- 2. answer ---------------- */

    get answerTitle() {
        return this.isInbound ? '2. What Salesforce answered' : `2. Answer from ${this.conn}`;
    }

    get answerText() {
        const ex = this.ex || {};
        const head = ex.httpStatus != null ? `HTTP ${ex.httpStatus}` : 'No answer recorded';
        return ex.responseBody ? `${head}\n${ex.responseBody}` : head;
    }

    get responseCut() {
        return Boolean(this.ex && this.ex.responseCut && this.ex.responseFileId);
    }

    /* ---------------- 3. callback (outbound only) ---------------- */

    get showCallback() {
        return Boolean(this.ex) && !this.isInbound;
    }

    get hasCallbackBody() {
        return Boolean(this.ex && this.ex.callbackBody);
    }

    get callbackText() {
        const ex = this.ex || {};
        if (ex.callbackBody) {
            return ex.callbackBody;
        }
        if (ex.expectsCallback) {
            return 'Not received yet';
        }
        return ex.businessData ? 'None expected for this event\n(the answer above carried the data)' : 'None expected for this event';
    }

    get callbackMuted() {
        return !this.hasCallbackBody;
    }

    get callbackCut() {
        return Boolean(this.ex && this.ex.callbackCut && this.ex.callbackFileId);
    }

    /* ---------------- 4. business processing ---------------- */

    get businessData() {
        return Boolean(this.ex && this.ex.businessData);
    }

    get businessTitle() {
        return `${this.showCallback ? 4 : 3}. Business processing`;
    }

    get attemptsTitle() {
        let n = this.showCallback ? 4 : 3;
        if (this.businessData) {
            n += 1;
        }
        return `${n}. Attempts`;
    }

    get businessStatus() {
        return (this.ex && this.ex.businessStatus) || 'Not run yet';
    }

    get businessClass() {
        return BUSINESS_TONE[this.ex && this.ex.businessStatus] || 'tone';
    }

    get businessWhen() {
        const ex = this.ex || {};
        const parts = ['(background)'];
        if (ex.businessRuns) {
            parts.push(`run ${ex.businessRuns}`);
        }
        if (ex.businessStatus === 'Processing') {
            parts.push('refreshing…');
        }
        return parts.join(' · ');
    }

    get handlerClass() {
        return (this.ex && this.ex.handlerClass) || '—';
    }

    get dataSource() {
        return this.ex && this.ex.expectsCallback ? 'callback' : 'answer';
    }

    get inputText() {
        const ex = this.ex || {};
        const cut = this.dataSource === 'callback' ? ex.callbackCut : ex.responseCut;
        return `"data" from the ${this.dataSource}` + (cut ? ' (full body kept as a File)' : ' (full body kept)');
    }

    get hasResult() {
        return Boolean(this.ex && this.ex.businessResult);
    }

    get hasBusinessError() {
        return Boolean(this.ex && this.ex.businessError);
    }

    get canRerun() {
        return Boolean(this.ex && this.ex.canRerun);
    }

    /* ---------------- 5. attempts ---------------- */

    get attemptRows() {
        const list = (this.ex && this.ex.attempts) || [];
        return list.map((a, i) => {
            const rerunRow = a.kind && a.kind !== 'Send';
            return {
                key: `${a.n != null ? a.n : i}-${i}`,
                n: a.n != null ? a.n : i + 1,
                at: a.at,
                http: a.httpStatus != null ? a.httpStatus : '–',
                outcome: rerunRow ? [a.kind, a.outcome].filter(Boolean).join(' · ') : a.outcome || '',
                payload: a.payloadUsed || (rerunRow ? 'stored ' + this.dataSource : ''),
                error: a.error
            };
        });
    }

    get hasAttempts() {
        return this.attemptRows.length > 0;
    }

    /* ---------------- rerun ---------------- */

    get rerunData() {
        const ex = this.ex || {};
        return (ex.expectsCallback && ex.callbackBody) || ex.responseBody || '';
    }

    get hasRerunData() {
        return Boolean(this.rerunData);
    }

    get rerunDataTitle() {
        return `Data it will use (the stored ${this.dataSource})`;
    }

    get rerunCut() {
        const ex = this.ex || {};
        return Boolean(this.dataSource === 'callback' ? ex.callbackCut : ex.responseCut);
    }

    handleRerun() {
        this.confirming = true;
    }

    handleCancelRerun() {
        this.confirming = false;
    }

    async handleRerunNow() {
        this.rerunning = true;
        try {
            await rerun({ transactionId: this.transactionId });
            this.toast('success', 'Handler rerun started. It runs in the background.');
            this.confirming = false;
            await this.load();
            this.pollTries = 0;
            this.schedulePoll();
        } catch (e) {
            this.toast('error', errorMessage(e, 'The handler could not be rerun.'));
        } finally {
            this.rerunning = false;
        }
    }

    schedulePoll() {
        clearTimeout(this.pollTimer);
        if (!this.isAlive || !this.ex || this.ex.businessStatus !== 'Processing' || this.pollTries >= POLL_TRIES) {
            return;
        }
        this.pollTries += 1;
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this.pollTimer = setTimeout(async () => {
            await this.load();
            this.schedulePoll();
        }, POLL_MS);
    }

    /* ---------------- copy and download ---------------- */

    handleCopy(event) {
        const what = event.currentTarget.dataset.what;
        const text = {
            request: this.requestText,
            answer: this.answerText,
            callback: this.ex && this.ex.callbackBody,
            rerun: this.rerunData
        }[what];
        this.copy(text);
    }

    async copy(text) {
        try {
            await navigator.clipboard.writeText(text || '');
            this.toast('success', 'Copied.');
        } catch (e) {
            this.toast('warning', 'The browser blocked copying. Select the text in the box and press Ctrl+C (Cmd+C on a Mac).');
        }
    }

    handleDownload(event) {
        event.preventDefault();
        const fileId = event.currentTarget.dataset.file;
        if (fileId) {
            this[NavigationMixin.Navigate]({
                type: 'standard__namedPage',
                attributes: { pageName: 'filePreview' },
                state: { recordIds: fileId, selectedRecordId: fileId }
            });
        }
    }

    toast(variant, message) {
        const title = { success: 'Done', error: 'Error' }[variant] || 'Check';
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }

    handleClose() {
        this.close();
    }
}