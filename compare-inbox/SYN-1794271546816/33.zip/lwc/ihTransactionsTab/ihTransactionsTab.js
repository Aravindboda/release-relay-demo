import { LightningElement, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { gql, graphql, refreshGraphQL } from 'lightning/uiGraphQLApi';
import { updateRecord } from 'lightning/uiRecordApi';
import { IsConsoleNavigation, EnclosingTabId } from 'lightning/platformWorkspaceApi';
import isAdmin from '@salesforce/customPermission/Integration_Hub_Admin';
import { openPage, recordPage, errorMessage, retryLine } from 'c/ihNav';

const PAGE = 50;
const RETRYABLE = ['Failed', 'Abandoned'];

// Auto-refresh while transactions are in progress. Pending/Received/Retry change within seconds; Sent waits for
// an external callback that can take hours, so it is polled slowly. Polling stops after POLL_MAX of continuous
// polling (a manual refresh or a retry starts it again), while the browser tab is hidden, and on disconnect.
const FAST_STATUSES = ['Pending', 'Received', 'Retry'];
const POLL_FAST = 5000;
const POLL_SLOW = 30000;
const POLL_MAX = 30 * 60 * 1000;
const DAY = 24 * 60 * 60 * 1000;
// Created periods (combobox values) that can match many rows: the results show a hint to narrow them when paged.
const WIDE_PERIODS = ['90', 'year', 'all'];
const DATES = ['Last_Attempt__c', 'Completed_At__c', 'Next_Retry_At__c', 'CreatedDate', 'LastModifiedDate'];

/** Every field of a transaction, in the order the detail panel shows them. */
const DETAIL = [
    ['Name', 'Transaction'], ['Direction__c', 'Direction'], ['Status__c', 'Status'], ['Event_Name__c', 'Event'],
    ['Target_Name__c', 'Connection or handler'], ['Related_Object__c', 'Related object'],
    ['Related_Record_Id__c', 'Related record Id'], ['External_Reference_Id__c', 'External reference'],
    ['Http_Status_Code__c', 'HTTP status'], ['Attempt_Count__c', 'Attempts'], ['Last_Attempt__c', 'Last attempt'],
    ['Completed_At__c', 'Completed'], ['Correlation_Id__c', 'Correlation Id'],
    ['Request_Id__c', 'Request Id'], ['Error_Message__c', 'Error'], ['Next_Retry_At__c', 'Next retry at'],
    ['Auto_Retries__c', 'Auto retries'],
    ['CreatedDate', 'Created'], ['LastModifiedDate', 'Last modified']
];
const BODIES = [['Request_Payload__c', 'Request payload'], ['Response_Body__c', 'Response'], ['Callback_Body__c', 'Callback']];


/** 'YYYY-MM-DD' (lightning-input type="date") to local midnight of that day, plus `addDays`; null when blank. */
const localDay = (text, addDays = 0) => {
    if (!text) {
        return null;
    }
    const [y, m, d] = text.split('-').map(Number);
    return new Date(y, m - 1, d + addDays);
};
const pad2 = (n) => String(n).padStart(2, '0');
const todayIso = () => {
    const d = new Date();
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
};

const pretty = (text) => {
    if (!text) {
        return '';
    }
    try {
        return JSON.stringify(JSON.parse(text), null, 2);
    } catch (e) {
        return text;
    }
};

/**
 * Transactions tab: every Integration Transaction the user can see, with filters, paging and a detail panel
 * that shows all of its information. No Apex: GraphQL wire adapter for reading, updateRecord for retry (admins).
 */
export default class IhTransactionsTab extends NavigationMixin(LightningElement) {
    @wire(IsConsoleNavigation) isConsole;
    @wire(EnclosingTabId) tabId;

    search = '';
    direction = 'all';
    status = 'all';
    created = '7';
    // Custom (days): what the box shows, and the last valid number the query uses (an invalid number is not queried).
    daysInput = 45;
    customDays = 45;
    // Custom range: what the From/To inputs show, and the last valid pair the query uses.
    fromInput = '';
    toInput = '';
    customFrom = '';
    customTo = '';
    after = null;
    pages = [];
    rows = [];
    total = 0;
    hasNext = false;
    endCursor;
    loading = true;
    error;
    selectedId;
    checked = new Set();
    busy = false;
    graphqlResult;
    polling = false;
    pollTimer;
    pollStarted;
    connected = false;
    searchTimer;

    get isAdmin() {
        return isAdmin;
    }

    /* ---------------- query ---------------- */

    get where() {
        const and = [];
        if (this.direction !== 'all') {
            and.push({ Direction__c: { eq: this.direction } });
        }
        if (this.status === 'bad') {
            and.push({ Status__c: { in: RETRYABLE } });
        } else if (this.status === 'wait') {
            and.push({ Status__c: { in: ['Pending', 'Received', 'Sent', 'Retry'] } });
        } else if (this.status !== 'all') {
            and.push({ Status__c: { eq: this.status } });
        }
        const range = this.createdRange;
        if (range.gte) {
            and.push({ CreatedDate: { gte: { value: range.gte } } });
        }
        if (range.lt) {
            and.push({ CreatedDate: { lt: { value: range.lt } } });
        }
        const q = this.search.trim();
        if (q) {
            const like = { like: `%${q}%` };
            and.push({ or: [
                { Name: like }, { Event_Name__c: like }, { Target_Name__c: like }, { Error_Summary__c: like },
                { Related_Record_Id__c: like }, { External_Reference_Id__c: like }, { Request_Id__c: like }
            ] });
        }
        return and.length ? { and } : {};
    }

    /** CreatedDate bounds as ISO strings (gte inclusive, lt exclusive); an empty object means no condition. */
    get createdRange() {
        const now = new Date();
        switch (this.created) {
            case 'all':
                return {};
            case 'today':
                return { gte: new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString() };
            case 'year':
                return { gte: new Date(now.getFullYear(), 0, 1).toISOString() };
            case 'custom':
                // Last N days ending today: from local midnight N - 1 days ago.
                return { gte: new Date(now.getFullYear(), now.getMonth(), now.getDate() - (this.customDays - 1)).toISOString() };
            case 'range': {
                const from = localDay(this.customFrom);
                const to = localDay(this.customTo, 1);
                return { gte: from ? from.toISOString() : undefined, lt: to ? to.toISOString() : undefined };
            }
            default:
                // Last N days: rolling window back from now.
                return { gte: new Date(Date.now() - Number(this.created) * DAY).toISOString() };
        }
    }

    get variables() {
        return { where: this.where, first: PAGE, after: this.after };
    }

    @wire(graphql, {
        query: gql`
            query allTransactions($where: IH_Transaction__c_Filter, $first: Int, $after: String) {
                uiapi {
                    query {
                        IH_Transaction__c(where: $where, first: $first, after: $after, orderBy: { CreatedDate: { order: DESC } }) {
                            totalCount
                            pageInfo { hasNextPage endCursor }
                            edges {
                                node {
                                    Id
                                    Name { value }
                                    Direction__c { value }
                                    Status__c { value }
                                    Event_Name__c { value }
                                    Target_Name__c { value }
                                    Related_Object__c { value }
                                    Related_Record_Id__c { value }
                                    External_Reference_Id__c { value }
                                    Http_Status_Code__c { value }
                                    Attempt_Count__c { value }
                                    Last_Attempt__c { value }
                                    Completed_At__c { value }
                                    Correlation_Id__c { value }
                                    Request_Id__c { value }
                                    Error_Summary__c { value }
                                    Error_Message__c { value }
                                    Next_Retry_At__c { value }
                                    Auto_Retries__c { value }
                                    Auto_Retry_Max__c { value }
                                    Request_Payload__c { value }
                                    Response_Body__c { value }
                                    Callback_Body__c { value }
                                    CreatedDate { value }
                                    LastModifiedDate { value }
                                }
                            }
                        }
                    }
                }
            }
        `,
        variables: '$variables'
    })
    wiredTransactions(result) {
        this.graphqlResult = result;
        const { data, errors } = result;
        if (data) {
            const conn = data.uiapi.query.IH_Transaction__c;
            const page = conn.edges.map((e) => this.toRow(e.node));
            this.rows = this.after ? [...this.pages, ...page] : page;
            this.total = conn.totalCount;
            this.hasNext = conn.pageInfo.hasNextPage;
            this.endCursor = conn.pageInfo.endCursor;
            this.error = undefined;
            this.loading = false;
            // A ticked row that is no longer Failed/Abandoned (for example after a poll) is unticked.
            const retryableIds = new Set(this.rows.filter((r) => r.retryable).map((r) => r.id));
            if ([...this.checked].some((id) => !retryableIds.has(id))) {
                this.checked = new Set([...this.checked].filter((id) => retryableIds.has(id)));
            }
            this.schedulePoll();
        } else if (errors) {
            this.error = errors.map((e) => e.message).join(', ');
            this.loading = false;
            this.stopPolling();
        }
    }

    toRow(n) {
        const v = (f) => (n[f] ? n[f].value : null);
        const status = v('Status__c');
        const inbound = v('Direction__c') === 'Inbound';
        return {
            id: n.Id,
            node: n,
            name: v('Name'),
            url: '/' + n.Id,
            directionText: inbound ? 'IN' : 'OUT',
            directionClass: 'ih-tag ' + (inbound ? 'ih-tag_in' : 'ih-tag_rest'),
            eventName: v('Event_Name__c'),
            targetName: v('Target_Name__c'),
            status,
            badgeClass: 'ih-badge ih-badge_' + status,
            relatedId: v('Related_Record_Id__c'),
            relatedUrl: '/' + v('Related_Record_Id__c'),
            relatedText: (v('Related_Object__c') || 'Record') + ' ' + (v('Related_Record_Id__c') || ''),
            note: RETRYABLE.includes(status) ? [this.retryText(n, status), v('Error_Summary__c')].filter(Boolean).join(' · ')
                : v('External_Reference_Id__c'),
            noteClass: RETRYABLE.includes(status) ? 'ih-note ih-note_bad' : 'ih-note',
            attempts: v('Attempt_Count__c') || 0,
            createdDate: v('CreatedDate'),
            retryable: RETRYABLE.includes(status)
        };
    }

    /** "Will retry automatically at 10:45 (2 of 3)" for a Failed row waiting for auto-retry, else ''. */
    retryText(n, status) {
        const v = (f) => (n[f] ? n[f].value : null);
        return status === 'Failed' ? retryLine(v('Next_Retry_At__c'), v('Auto_Retries__c'), v('Auto_Retry_Max__c')) : '';
    }

    get viewRows() {
        return this.rows.map((r) => ({
            ...r,
            rowClass: r.id === this.selectedId ? 'row row_on' : 'row',
            checked: this.checked.has(r.id),
            selectDisabled: !r.retryable,
            selectLabel: 'Select ' + r.name
        }));
    }

    /* ---------------- filters ---------------- */

    reset() {
        this.after = null;
        this.pages = [];
        this.loading = true;
        this.checked = new Set();
    }

    get directionOptions() {
        return [
            { label: 'Both directions', value: 'all' },
            { label: 'Outbound', value: 'Outbound' },
            { label: 'Inbound', value: 'Inbound' }
        ];
    }

    get statusOptions() {
        return [
            { label: 'All statuses', value: 'all' },
            { label: 'Failed or Abandoned', value: 'bad' },
            { label: 'In progress', value: 'wait' },
            { label: 'Success', value: 'Success' },
            { label: 'Sent (waiting for callback)', value: 'Sent' },
            { label: 'Failed', value: 'Failed' },
            { label: 'Abandoned', value: 'Abandoned' }
        ];
    }

    get createdOptions() {
        return [
            { label: 'Today', value: 'today' },
            { label: 'Last 7 days', value: '7' },
            { label: 'Last 30 days', value: '30' },
            { label: 'Last 90 days', value: '90' },
            { label: 'This year', value: 'year' },
            { label: 'All time', value: 'all' },
            { label: 'Custom (days)', value: 'custom' },
            { label: 'Custom range', value: 'range' }
        ];
    }

    get isCustom() {
        return this.created === 'custom';
    }

    get isRange() {
        return this.created === 'range';
    }

    /** Latest day the date pickers allow: today. */
    get maxDay() {
        return todayIso();
    }

    /** From/To change: the query only changes when the pair is valid (no future day, From on or before To). */
    handleRange(event) {
        this[event.target.dataset.field] = event.detail.value || '';
        const today = todayIso();
        const future = [this.fromInput, this.toInput].some((d) => d && d > today);
        const reversed = Boolean(this.fromInput && this.toInput && this.fromInput > this.toInput);
        const field = event.target;
        field.setCustomValidity(future ? 'Pick today or an earlier day.' : reversed ? 'From must be on or before To.' : '');
        field.reportValidity();
        if (future || reversed || (this.fromInput === this.customFrom && this.toInput === this.customTo)) {
            return;
        }
        this.reset();
        this.customFrom = this.fromInput;
        this.customTo = this.toInput;
    }

    /** Custom (days) change: the query only changes for a whole number from 1 to 3,650. */
    handleDays(event) {
        this.daysInput = event.detail.value;
        const n = Number(this.daysInput);
        const valid = Number.isInteger(n) && n >= 1 && n <= 3650;
        const field = event.target;
        field.setCustomValidity(valid ? '' : 'Enter a whole number of days from 1 to 3,650.');
        field.reportValidity();
        if (!valid || n === this.customDays) {
            return;
        }
        this.reset();
        this.customDays = n;
    }

    handleFilter(event) {
        this.reset();
        this[event.target.dataset.field] = event.detail.value;
        // Invalid values left behind are dropped: the inputs show what the query uses.
        this.daysInput = this.customDays;
        this.fromInput = this.customFrom;
        this.toInput = this.customTo;
    }

    handleSearch(event) {
        const value = event.detail.value || '';
        clearTimeout(this.searchTimer);
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this.searchTimer = setTimeout(() => {
            this.reset();
            this.search = value;
        }, 400);
    }

    handleMore() {
        this.pages = this.rows;
        this.after = this.endCursor;
    }

    async handleRefresh() {
        this.busy = true;
        this.pollStarted = undefined;
        try {
            this.reset();
            this.after = null;
            await refreshGraphQL(this.graphqlResult);
        } finally {
            this.busy = false;
            this.loading = false;
            this.schedulePoll();
        }
    }

    get countText() {
        return `${this.rows.length} of ${this.total} shown, newest first`;
    }

    /** Paged results for a period that can hold many transactions. */
    get showWideHint() {
        if (!this.hasNext) {
            return false;
        }
        if (WIDE_PERIODS.includes(this.created)) {
            return true;
        }
        if (this.created === 'custom') {
            return this.customDays > 90;
        }
        if (this.created !== 'range') {
            return false;
        }
        const from = localDay(this.customFrom);
        const to = localDay(this.customTo, 1) || new Date();
        return !from || to - from > 90 * DAY;
    }

    get wideHintText() {
        return `Showing the newest ${this.rows.length} of ${this.total}. Narrow the filters or use Load more.`;
    }

    get hasRows() {
        return this.rows.length > 0;
    }

    get isEmpty() {
        return !this.loading && !this.error && this.rows.length === 0;
    }

    /* ---------------- detail ---------------- */

    handleSelect(event) {
        this.selectedId = event.currentTarget.dataset.id;
    }

    get selected() {
        return this.rows.find((r) => r.id === this.selectedId);
    }

    get detailFields() {
        const s = this.selected;
        if (!s) {
            return [];
        }
        return DETAIL.map(([f, label]) => {
            const raw = s.node[f] ? s.node[f].value : null;
            const isDate = DATES.includes(f) && Boolean(raw);
            return { key: f, label, value: raw === null || raw === undefined || raw === '' ? '—' : raw, isDate, plain: !isDate };
        });
    }

    get detailBodies() {
        const s = this.selected;
        if (!s) {
            return [];
        }
        return BODIES.filter(([f]) => s.node[f] && s.node[f].value).map(([f, label]) => ({ key: f, label, text: pretty(s.node[f].value) }));
    }

    get hasBodies() {
        return this.detailBodies.length > 0;
    }

    get selectedCanRetry() {
        return isAdmin && this.selected && this.selected.retryable;
    }

    closeDetail() {
        this.selectedId = undefined;
    }

    handleOpen(event) {
        event.preventDefault();
        event.stopPropagation();
        openPage(this, recordPage(event.currentTarget.dataset.id), { isConsole: this.isConsole, tabId: this.tabId,
            label: event.currentTarget.dataset.label });
    }

    /* ---------------- retry (admins) ---------------- */

    handleCheck(event) {
        event.stopPropagation();
        const next = new Set(this.checked);
        if (event.target.checked) {
            next.add(event.target.dataset.id);
        } else {
            next.delete(event.target.dataset.id);
        }
        this.checked = next;
    }

    stop(event) {
        event.stopPropagation();
    }

    get retrySelectedLabel() {
        return `Retry selected (${this.checked.size})`;
    }

    get noneChecked() {
        return this.checked.size === 0 || this.busy;
    }

    // menu value / button data-mode: 'new' = rebuild the payload from current data, 'original' = resend the stored one.
    handleRetrySelected(event) {
        this.retry([...this.checked], event.detail.value === 'new');
    }

    handleRetryOne(event) {
        this.retry([this.selectedId], event.currentTarget.dataset.mode === 'new');
    }

    async retry(ids, rebuild) {
        if (!isAdmin || !ids.length) {
            return;
        }
        this.busy = true;
        let ok = 0;
        const failures = [];
        // rebuild=false resends the stored payload. A stored copy that is empty or was cut down for length is
        // always rebuilt by the sender, so that choice is safe for every transaction.
        for (const id of ids) {
            try {
                // eslint-disable-next-line no-await-in-loop
                await updateRecord({ fields: { Id: id, Status__c: 'Retry', Next_Retry_At__c: null,
                    Rebuild_Payload__c: rebuild === true, Error_Message__c: null, Error_Summary__c: null } });
                ok++;
            } catch (e) {
                failures.push(errorMessage(e, 'failed'));
            }
        }
        this.busy = false;
        this.toast(failures.length ? 'warning' : 'success',
            `${ok} transaction(s) queued ` + (rebuild ? 'with a new payload.' : 'with the original payload.') + (failures.length ? ` ${failures.length} could not be retried: ${failures[0]}` : ''));
        this.reset();
        this.pollStarted = undefined;
        try {
            await refreshGraphQL(this.graphqlResult);
        } finally {
            this.loading = false;
            this.schedulePoll();
        }
    }

    /* ---------------- auto-refresh ---------------- */

    connectedCallback() {
        this.connected = true;
        document.addEventListener('visibilitychange', this.handleVisibility);
    }

    disconnectedCallback() {
        this.connected = false;
        document.removeEventListener('visibilitychange', this.handleVisibility);
        this.stopPolling();
    }

    handleVisibility = () => {
        if (document.visibilityState === 'hidden') {
            this.stopPolling();
        } else if (this.pollDelay()) {
            // Back on the tab: catch up now, then carry on with a fresh time limit.
            this.pollStarted = undefined;
            this.poll();
        }
    };

    /** 5 s while any loaded row is Pending/Received/Retry, 60 s while any is Sent, else 0 (stop). */
    pollDelay() {
        if (this.rows.some((r) => FAST_STATUSES.includes(r.status))) {
            return POLL_FAST;
        }
        return this.rows.some((r) => r.status === 'Sent') ? POLL_SLOW : 0;
    }

    /** Called after every data load: one timer at most, never stacked. */
    schedulePoll() {
        clearTimeout(this.pollTimer);
        this.pollTimer = undefined;
        const delay = this.pollDelay();
        if (!delay) {
            this.pollStarted = undefined;
        }
        if (!delay || !this.connected || document.visibilityState === 'hidden') {
            this.polling = false;
            return;
        }
        if (!this.pollStarted) {
            this.pollStarted = Date.now();
        } else if (Date.now() - this.pollStarted >= POLL_MAX) {
            this.polling = false;
            return;
        }
        this.polling = true;
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this.pollTimer = setTimeout(() => this.poll(), delay);
    }

    stopPolling() {
        clearTimeout(this.pollTimer);
        this.pollTimer = undefined;
        this.polling = false;
    }

    /** Background refresh: no spinner, no busy, filters and selection kept. */
    async poll() {
        this.pollTimer = undefined;
        if (!this.connected || !this.graphqlResult) {
            return;
        }
        try {
            await refreshGraphQL(this.graphqlResult);
        } catch (e) {
            // Keep the rows on screen; the next load or a manual refresh shows any error.
        }
        // The wire handler reschedules when data changes; this covers a refresh that returned the same data.
        this.schedulePoll();
    }

    toast(variant, message) {
        this.dispatchEvent(new ShowToastEvent({ title: variant === 'error' ? 'Error' : 'Done', message, variant }));
    }
}