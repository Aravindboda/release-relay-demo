import { LightningElement, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { IsConsoleNavigation, EnclosingTabId } from 'lightning/platformWorkspaceApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { openPage, tabPage, objectListPage } from 'c/ihNav';
import IH_HELP from '@salesforce/resourceUrl/IH_Help';
import IS_ADMIN from '@salesforce/customPermission/Integration_Hub_Admin';

const TRIGGER_CODE = `// IntegrationHub.publish takes a List, never a Set or a Map. Two forms:
//   List<Id> publish(String eventKey, List<SObject> records)   records need an Id (after insert / update)
//   List<Id> publish(String eventKey, List<Id> recordIds)
// It returns the Ids of the transactions it created (empty when nothing was sent).

List<Case> webCases = new List<Case>();          // filled in your handler where the condition is met
IntegrationHub.publish('CASE_WEB_CREATED', webCases);

// From a Set or a Map, convert to a List:
Set<Id> caseIds = new Set<Id>();
IntegrationHub.publish('CASE_WEB_CREATED', new List<Id>(caseIds));

Map<Id, Case> casesById = new Map<Id, Case>();
IntegrationHub.publish('CASE_WEB_CREATED', casesById.values());`;

const RESPONSE_CODE = `// 1. Create this class (any name), 2. type its name in the event's Response Handler Class field.
public with sharing class CaseReplyHandler implements IntegrationHub.IResponseHandler {
    public void handle(IntegrationHub.ResponseContext ctx) {
        // ctx.isCallback      false = the immediate HTTP reply, true = the callback
        // ctx.body            the reply or callback JSON (text)
        // ctx.httpStatus      HTTP status of the reply (null on the callback)
        // ctx.relatedRecordId the record that was sent (e.g. the Case)
        // ctx.txn             the Integration Transaction (Status__c, External_Reference_Id__c ...)
        // ctx.data            the parsed "data" object of the reply or callback (null when there is none)
        // ctx.result          set a short line here; it is shown as Business Result on the transaction
        if (String.isBlank(ctx.body) || ctx.relatedRecordId == null) {
            return;
        }
        Object parsed = JSON.deserializeUntyped(ctx.body);
        if (!(parsed instanceof Map<String, Object>)) {
            return;
        }
        Map<String, Object> body = (Map<String, Object>) parsed;
        // Your process here, for example copy a value to the Case:
        // update new Case(Id = ctx.relatedRecordId, Your_Field__c = (String) body.get('reference'));
    }
}`;

const INBOUND_HANDLER_CODE = `// 1. Create this class (any name), 2. type its name in the inbound event's Handler Class field.
public with sharing class CaseCreateHandler implements IntegrationHub.IInboundHandler {
    public IntegrationHub.InboundResult handle(IntegrationHub.InboundContext ctx) {
        Map<String, Object> req = ctx.data;   // the JSON body, parsed
        if (req == null || req.get('subject') == null) {
            return IntegrationHub.inboundFailure(400, 'subject is required');
        }
        Case c = new Case(Subject = (String) req.get('subject'), Origin = 'Web');
        insert c;
        return IntegrationHub.inboundSuccess(c.Id, new Map<String, Object>{ 'caseId' => c.Id });
    }
}`;

const PAYLOAD_CLASS_CODE = `// Payload Source = Apex Class: 1. create this class (any name), 2. type its name in the event's Payload Class field.
public with sharing class CasePayloadBuilder implements IntegrationHub.IPayloadBuilder {
    public Map<Id, Object> build(IntegrationHub.PayloadRequest req) {
        // req.recordIds: every record of this send, as one list (query them once)
        // req.transactionIdByRecordId, req.eventKey, req.relatedObject
        Map<Id, Object> bodies = new Map<Id, Object>();
        for (Case c : [SELECT Id, CaseNumber, Subject, Account.Name FROM Case WHERE Id IN :req.recordIds]) {
            bodies.put(c.Id, new Map<String, Object>{
                'caseNumber' => c.CaseNumber,
                'title' => c.Subject,
                'customer' => c.Account.Name
            });
        }
        // A Map body gets sfTransactionId added for you. A String body is sent exactly as returned.
        return bodies;
    }
}`;

const PAYLOAD_CODE = `{
  "sfTransactionId": "a0X5g00000AbCdE",
  "eventName": "CASE_WEB_CREATED",
  "recordId": "5005g00000XyZ12",
  "object": "Case",
  "fields": { "CaseNumber": "00045812", "Subject": "Device error", "Account.Name": "Acme" }
}`;

const CALLBACK_CODE = `PATCH {My Domain}/services/apexrest/integrationhub/v1/callback/{sfTransactionId}
Authorization: Bearer <token>
Content-Type: application/json

{ "status": "ACCEPTED", "reference": "EXT-7781", "message": "Created in the target system" }

200 {transactionId, status}  400 bad JSON  403 not the connection's inbound user  404 unknown  409 inbound transaction`;

const INBOUND_CODE = `POST {My Domain}/services/apexrest/integrationhub/v1/{EVENT_KEY}
Authorization: Bearer <token>
Content-Type: application/json
X-Request-Id: <unique per call>

{ "subject": "Broken device" }

GET  {My Domain}/services/apexrest/integrationhub/v1/status/{transactionId}`;

const EXAMPLES_CODE = `// Part 1: run the outbound examples once (Self Org, sandbox). Sends run in the background:
// wait a few seconds, then look at the Transactions tab or the Monitor.
List<Case> cases = [SELECT Id, CaseNumber FROM Case WHERE Subject != null ORDER BY CreatedDate DESC LIMIT 1];
List<Account> accounts = [SELECT Id, Name FROM Account ORDER BY CreatedDate DESC LIMIT 1];
List<String> caseEvents = new List<String>{
    'SELF_SEND_OK', 'SELF_SEND_CALLBACK', 'SELF_SEND_CLASS', 'SELF_SEND_REJECT',
    'SELF_SEND_DOWN', 'SELF_SEND_CREATE_CASE', 'SELF_SEND_TOKENS'
};
if (cases.isEmpty()) {
    System.debug(LoggingLevel.WARN, 'No Case with a Subject found.');
} else {
    List<Id> caseIds = new List<Id>{ cases[0].Id };
    System.debug(LoggingLevel.INFO, 'Case: ' + cases[0].CaseNumber);
    for (String eventKey : caseEvents) {
        List<Id> txnIds = IntegrationHub.publish(eventKey, caseIds);
        System.debug(LoggingLevel.INFO, eventKey + ' transaction ids: ' + txnIds);
    }
}
if (accounts.isEmpty()) {
    System.debug(LoggingLevel.WARN, 'No Account found.');
} else {
    List<Id> txnIds = IntegrationHub.publish('SELF_SEND_ACCOUNT', new List<Id>{ accounts[0].Id });
    System.debug(LoggingLevel.INFO, 'SELF_SEND_ACCOUNT (' + accounts[0].Name + ') transaction ids: ' + txnIds);
}

// Part 2: the callback for SELF_SEND_CALLBACK. Run it on its own (not together with Part 1)
// once that transaction shows Sent. Same as:
// PATCH {My Domain}/services/apexrest/integrationhub/v1/callback/{sfTransactionId}
// { "status": "SUCCESS", "reference": "SELF-001", "message": "Done" }
List<IH_Transaction__c> txns = [SELECT Id FROM IH_Transaction__c
    WHERE Event_Name__c = 'SELF_SEND_CALLBACK' AND Status__c = 'Sent' ORDER BY CreatedDate DESC LIMIT 1];
if (txns.isEmpty()) {
    System.debug(LoggingLevel.WARN, 'No Sent SELF_SEND_CALLBACK transaction; run Part 1 and wait.');
} else {
    HttpRequest req = new HttpRequest();
    req.setEndpoint('callout:IH_Self_Org/services/apexrest/integrationhub/v1/callback/' + txns[0].Id);
    req.setMethod('PATCH');
    req.setHeader('Content-Type', 'application/json');
    req.setBody(JSON.serialize(new Map<String, Object>{
        'status' => 'SUCCESS', 'reference' => 'SELF-001', 'message' => 'Done' }));
    HttpResponse res = new Http().send(req);
    System.debug(LoggingLevel.INFO, 'Callback ' + txns[0].Id + ': ' + res.getStatusCode() + ' ' + res.getBody());
}`;

const OUTBOUND_REQUEST_CODE = `POST callout:<Named Credential><event Path>
Content-Type: application/json
X-Correlation-Id: <same value on every resend of this transaction>
<the connection's Headers JSON, e.g. x-api-version: 2>

${PAYLOAD_CODE}`;

const CALLBACK_BODY_CODE = `{ "status": "SUCCESS",
  "reference": "VOUCHER-12345",
  "message": "Voucher issued",
  "data": { ... only with Business Data In Response ... } }`;

const INBOUND_BODY_CODE = `POST https://<my-domain>.my.salesforce.com/services/apexrest/integrationhub/v1/CASE_WEB_IN
Authorization: Bearer <token of the Inbound User>
Content-Type: application/json
X-Request-Id: 7f3c2a10-0001

{ "subject": "Broken device" }

200 { "transactionId": "a0X...", "status": "Success", "recordId": "500...", "data": { "caseId": "500..." } }`;

const ENVELOPE_CODE = `{
  "status": "SUCCESS",
  "reference": "VOUCHER-12345",
  "message": "Voucher issued",
  "data": { ...any JSON... }
}`;

const BUSINESS_HANDLER_CODE = `// Event: tick Business Data In Response and type this class name in Response Handler Class.
// Runs in the background (Queueable). It can run more than once on the same data: update or upsert, never a blind insert.
public with sharing class VoucherHandler implements IntegrationHub.IResponseHandler {
    public void handle(IntegrationHub.ResponseContext ctx) {
        if (ctx.data == null || ctx.relatedRecordId == null) {
            ctx.result = 'No data';
            return;
        }
        String voucher = (String) ctx.data.get('voucherNumber');
        update new Case(Id = ctx.relatedRecordId, Voucher_Number__c = voucher);
        ctx.result = 'Voucher ' + voucher + ' saved on the Case';
        // An exception here sets Business Status = Failed; an admin can use Rerun handler after the fix.
    }
}`;

const AUTH_CODE = `// Connection: Connection Type = Apex Auth, Auth Class = this class. The Named Credential stays: it gives the URL.
// No secret in code or in a field: the login goes through a Named Credential (here Partner_Login) whose External
// Credential holds the client Id and secret (tick "Allow Formulas in HTTP Body" on it for the merge fields below).
public with sharing class PartnerAuth implements IntegrationHub.IConnectionAuth {
    public void authorize(IntegrationHub.AuthContext ctx) {
        // ctx.request     the request about to be sent: set the login header on it
        // ctx.connection  the connection (Id, Name, Named_Credential__c, Auth_Class__c)
        // ctx.refresh     true after a 401: log in again, do not use the cached token
        // ctx.eventKey    the event being sent (null for Check connection)
        String token = ctx.refresh ? null : IntegrationHubTokenCache.cachedToken(ctx.connection.Id);
        if (token == null) {
            HttpRequest login = new HttpRequest();
            login.setEndpoint('callout:Partner_Login/oauth/token');
            login.setMethod('POST');
            login.setHeader('Content-Type', 'application/x-www-form-urlencoded');
            login.setBody('grant_type=client_credentials&client_id={!$Credential.Partner_Login.ClientId}'
                + '&client_secret={!$Credential.Partner_Login.ClientSecret}');
            Map<String, Object> answer = (Map<String, Object>) JSON.deserializeUntyped(new Http().send(login).getBody());
            token = (String) answer.get('access_token');
            Integer seconds = Integer.valueOf(answer.get('expires_in'));
            // Kept for this job, and in Platform Cache (default partition) when the org has it.
            IntegrationHubTokenCache.putToken(ctx.connection.Id, token, seconds - 60);
        }
        ctx.request.setHeader('Authorization', 'Bearer ' + token);
        // A CalloutException (token URL down or timed out) is temporary: auto-retry applies. Any other exception
        // fails the transaction for good (permanent) with your message.
    }
}`;

const WHERE = [
    { key: 'w1', what: 'Login and URL of the outside system', where: 'Setup > Named Credentials (Named Credential + External Credential)' },
    { key: 'w2', what: 'Which Named Credential, which user may call Salesforce', where: 'Integration Hub > Connections > the connection record' },
    { key: 'w12', what: 'A custom token login a Named Credential cannot do', where: 'Connection: Connection Type = Apex Auth and Auth Class = your class (IConnectionAuth)' },
    { key: 'w3', what: 'Event key, path, method, payload source (fields or class), callback, handler classes', where: 'Integration Hub > Events > the event record' },
    { key: 'w4', what: 'When a record is sent', where: 'Your trigger handler: IntegrationHub.publish(eventKey, list)' },
    { key: 'w9', what: 'Your own JSON shape', where: 'Your class (IPayloadBuilder), named in the event Payload Class with Payload Source = Apex Class' },
    { key: 'w5', what: 'Extra work after the reply or callback', where: 'Your class (IResponseHandler), named in the event Response Handler Class' },
    { key: 'w10', what: 'Save business data from the answer or callback', where: 'Event: tick Business Data In Response and set Response Handler Class' },
    { key: 'w6', what: 'What an inbound call does', where: 'Your class (IInboundHandler), named in the event Handler Class' },
    { key: 'w11', what: 'See the JSON before or after a send', where: 'Event page > Preview payload; transaction page > View request' },
    { key: 'w13', what: 'Resend temporary failures by themselves', where: 'Event: Auto Retry Max and Retry After (minutes); jobs on Monitor > Scheduled jobs' },
    { key: 'w7', what: 'Who sees and who manages', where: 'Permission sets Integration Hub Admin and Integration Hub Read' },
    { key: 'w8', what: 'Switch sending off (e.g. data loads)', where: 'Setup > Custom Settings > Integration Hub Settings > Disable Publishing' }
];

const SAMPLE_FILES = [
    { label: 'IH_SamplePayloadBuilder', file: 'IH_SamplePayloadBuilder.cls' },
    { label: 'IH_SamplePayloadBuilderTest', file: 'IH_SamplePayloadBuilderTest.cls' },
    { label: 'IH_SampleResponseHandler', file: 'IH_SampleResponseHandler.cls' },
    { label: 'IH_SampleResponseHandlerTest', file: 'IH_SampleResponseHandlerTest.cls' },
    { label: 'IH_SampleInboundHandler', file: 'IH_SampleInboundHandler.cls' },
    { label: 'IH_SampleInboundHandlerTest', file: 'IH_SampleInboundHandlerTest.cls' },
    { label: 'IH_SampleConnectionAuth', file: 'IH_SampleConnectionAuth.cls' },
    { label: 'IH_SampleConnectionAuthTest', file: 'IH_SampleConnectionAuthTest.cls' },
    { label: 'IH_SelfTestKit', file: 'IH_SelfTestKit.cls' },
    { label: 'IH_SelfTestKitTest', file: 'IH_SelfTestKitTest.cls' },
    { label: 'IH_SelfOrg_import.json', file: 'IH_SelfOrg_import.json' },
    { label: 'package.xml (all framework components)', file: 'package.xml' }
];

// What's implemented & usage / Who uses Integration Hub: the static facts. The live numbers come from c/ihUsage.
// Apex cannot read LWC or Aura source, so these two lists are kept here: the lwc folder plus the setup editor.
const USAGE_LWC = ['ihCleanupStatus', 'ihCode', 'ihConfigTransfer', 'ihConnectionCheck', 'ihEventCheck', 'ihHowTo', 'ihMonitor',
    'ihNav', 'ihPayloadPreview', 'ihRecordTransactions', 'ihSetupEditor', 'ihSetupFieldPicker', 'ihSetupHeaders', 'ihStyles', 'ihTransactionExchange', 'ihTransactionView',
    'ihTransactionsTab', 'ihUsage'];
const USAGE_AURA = [{ name: 'ihSetupOverride', note: 'New / Edit on Connection and Event' }];
const USAGE_OBJECTS = ['IH_Connection__c', 'IH_Event__c', 'IH_Transaction__c', 'IH_Attempt__c', 'IH_Settings__c'];
const USAGE_PERMISSION_SETS = ['Integration Hub Admin', 'Integration Hub Read'];
const USAGE_RESOURCE = 'IH_Help';
const USAGE_JOBS = [
    { name: 'IntegrationHubSender', type: 'Queueable', runsWhen: 'An event is published or a send is retried (by hand or by auto-retry); up to 100 transactions per job, fewer near the 100-callout limit, then it chains', callouts: 'Yes' },
    { name: 'IntegrationHubBusiness', type: 'Queueable', runsWhen: 'Business data in an answer or callback; Rerun handler', callouts: 'No' },
    { name: 'IntegrationHubMaintenance', type: 'Schedulable + Batch', runsWhen: 'Nightly clean-up at 02:00; Retry group from the Monitor', callouts: 'No' },
    { name: 'IntegrationHubAutoRetry', type: 'Schedulable + Batch', runsWhen: 'Every 15 minutes (4 jobs): sets Failed transactions whose Next Retry At has come to Retry, 50 per chunk', callouts: 'No' }
];
const USAGE_INFO = {
    jobs: USAGE_JOBS,
    lwc: USAGE_LWC,
    aura: USAGE_AURA,
    permissionSets: USAGE_PERMISSION_SETS,
    staticResource: USAGE_RESOURCE
};

const GROUPS = [
    { key: 'start', badge: 'S', name: 'Start' },
    { key: 'setup', badge: '1', name: 'Set up' },
    { key: 'build', badge: '2', name: 'Build' },
    { key: 'give', badge: '3', name: 'Give to the middleware' },
    { key: 'run', badge: '4', name: 'Run and fix' },
    { key: 'ref', badge: 'R', name: 'Reference' },
    { key: 'test', badge: 'T', name: 'Sandbox self-test' }
];

const OUTBOUND_ANSWERS = {
    columns: ['Answer from the middleware', 'What Integration Hub does'],
    rows: [
        ['2xx', 'Accepted: Success, or Sent when the event has Expects Callback'],
        ['"reference" or "id" at the top level', 'Kept as External Reference Id'],
        ['408, 429, 5xx or no answer', 'Failed (temporary). Sent again by itself when the event has Auto Retry Max; otherwise Resend original payload when the system is back'],
        ['Any other 4xx', 'Failed (permanent). Fix the data or the setup, then Retry with new payload']
    ],
    mono: [0]
};

const CALLBACK_ANSWERS = {
    title: 'Answers to the callback',
    columns: ['Code', 'Meaning'],
    rows: [
        ['200', 'Recorded'],
        ['400', 'Body is not a JSON object'],
        ['403', 'Not the Inbound User'],
        ['404', 'Unknown sfTransactionId'],
        ['409', 'Not an outbound request']
    ],
    mono: [0]
};

const INBOUND_ANSWERS = {
    title: 'Answers to an inbound call',
    columns: ['Code', 'Meaning', 'What the middleware does'],
    rows: [
        ['200', '{transactionId, status, recordId, data}', 'Done'],
        ['400', 'Bad data, or the body is not JSON', 'Fix the body, send with a NEW X-Request-Id'],
        ['403', 'Not the Inbound User', 'Log in as the connection\'s Inbound User'],
        ['404', 'Event unknown or inactive', 'Check the Event Key and that the event is Active'],
        ['405', 'GET on an event path', 'Use POST (GET only on .../status/{transactionId})'],
        ['422', 'Record refused (the reason is in the answer)', 'Fix the data, send with a NEW X-Request-Id'],
        ['5xx or timeout', 'Not sure it was handled', 'Resend with the SAME X-Request-Id: the first answer is replayed, no duplicate']
    ],
    mono: [0]
};

/*
 * One entry per topic, in reading order (Previous / Next follow this order).
 * short = name in the index and breadcrumb; title = heading of the pane.
 * Optional: points[], tables[{title, columns, rows, mono, live}], codes[{label, code}], images[], template or files[],
 * filesNote, embedConfigTransfer, usage, chooser, tip, go + tab/object.
 * usage = 'implemented' or 'who': the topic embeds c/ihUsage (live scan, admins). A table with live: true is the static
 * version of a live table: the PDF book and readers see it; admins see the live one from c/ihUsage instead.
 */
const TOPICS = [
    {
        key: 'overview', group: 'start', short: 'Overview', title: 'How Integration Hub works',
        lead: 'Set up a connection and an event, publish from your trigger, give the middleware three small contracts, then watch the Monitor.',
        points: [
            'Outbound: your trigger calls IntegrationHub.publish. The hub builds the JSON, sends it in the background and logs a transaction.',
            'Callback (optional): the middleware reports the final result later with one PATCH.',
            'Inbound: the middleware calls Salesforce; your handler class does the work.',
            'Everything is set up on standard record pages. The table below shows where each part lives.',
            'New here? Start with "Which option do I need?". Already set up? Jump to the group you need on the left.'
        ],
        tables: [{ title: 'Where everything is configured', columns: ['What', 'Where'], rows: WHERE.map((w) => [w.what, w.where]) }]
    },
    {
        key: 'chooser', group: 'start', short: 'Which option do I need?', title: 'Which option do I need?',
        lead: 'Answer six questions. The table shows which fields to set and where to read more.',
        chooser: true
    },
    {
        key: 'credential', group: 'setup', short: 'Named Credential', title: 'Create the Named Credential', icon: 'utility:lock',
        lead: 'The Named Credential holds the URL and the login of the outside system. Salesforce keeps the secret.',
        points: [
            'Already have a Named Credential for this system? Skip to the last two points: reuse it (just type its Name on the connection) and check its principal access. Create a new one only if none exists.',
            'Setup > search "Named Credentials" > External Credentials tab > New. Label and Name (e.g. Partner_Auth), Authentication Protocol (OAuth 2.0 for client credentials, Custom for an API key), then Save. (Picture 1)',
            'On the External Credential, Principals > New: Parameter Name, Identity Type Named Principal, and the client Id and secret from the system team. Salesforce stores the secret encrypted. (Picture 2)',
            'Named Credentials tab > New: Label, Name (you type this Name on the Integration Hub connection), URL of the system, the External Credential from above, keep Generate Authorization Header ticked. (Picture 3)',
            'Setup > Permission Sets > Integration Hub Read > External Credential Principal Access > Edit: move the principal to Enabled and Save. Do the same on Integration Hub Admin. Without it, calls fail with 401. (Picture 4)',
            'Existing Named Credential: open it in Setup and check (a) the URL is the base address, because Integration Hub adds the event Path after it, (b) Generate Authorization Header is ticked, (c) if it uses an External Credential, its principal is enabled on Integration Hub Read and Integration Hub Admin (Picture 4). A legacy Named Credential (with its own user name and password, no External Credential) needs no permission set access.',
            'Use the same Name in every org (sandbox, production); each org points it at its own URL.'
        ],
        images: [
            { file: '1-external-credential.svg', caption: '1. New External Credential' },
            { file: '2-principal.svg', caption: '2. Principal with the client Id and secret' },
            { file: '3-named-credential.svg', caption: '3. New Named Credential' },
            { file: '4-permission-set.svg', caption: '4. Principal access on the permission set' }
        ]
    },
    {
        key: 'connection', group: 'setup', short: 'Connection', title: 'Add a connection record', object: 'IH_Connection__c', go: 'Open Connections',
        lead: 'One connection per outside system. It names the Named Credential and the user the system logs in as.',
        points: [
            'Where: Integration Hub app > Connections tab > New. One record per outside system (or per middleware). New and Edit open a guided editor in 3 steps: Basics, Endpoint & headers, Inbound user & check. A new connection is saved inactive.',
            'Connection Name: any name, e.g. Partner API.',
            'Named Credential: pick it from the list of Named Credentials in this org (the Name from step 1, Picture 3), e.g. Partner_API. Outbound calls go to that URL.',
            'Connection Type (step Endpoint & headers): Named Credential (the default; blank means the same) lets Salesforce log in. Apex Auth: your Auth Class adds the login header at send time, for a custom token login a Named Credential cannot do. See Which connection type?',
            'Auth Class (Apex Auth only): pick the class that implements IntegrationHub.IConnectionAuth; test classes are never offered. The Named Credential stays required for both types: it gives the URL.',
            'Inbound User: the Salesforce user the system logs in as when it calls Salesforce. Only this user may call the callback and the inbound events of this connection; give it Integration Hub Read.',
            'Timeout (seconds) and Headers are optional. In the editor add headers as Header / Value rows; they are saved as JSON, e.g. {"x-api-version":"2"}.',
            'The record page shows a summary: the connection type and Auth Class, whether the Named Credential exists, whether the Inbound User has an Integration Hub permission set, and the events on this connection. Edit is shown to admins only.'
        ]
    },
    {
        key: 'conntype', group: 'setup', short: 'Which connection type?', title: 'Which connection type?', icon: 'utility:lock',
        object: 'IH_Connection__c', go: 'Open Connections',
        lead: 'Almost every login is a Named Credential. Apex Auth is only for a custom token login that a Named Credential cannot do.',
        tables: [{
            title: 'Logins a Named Credential already handles',
            columns: ['Login the system needs', 'How the Named Credential does it', 'Connection Type'],
            rows: [
                ['OAuth 2.0 client credentials', 'External Credential, protocol OAuth 2.0, flow Client Credentials with Client Secret', 'Named Credential'],
                ['OAuth 2.0 JWT bearer', 'External Credential, protocol OAuth 2.0, flow JWT Bearer, signed with a certificate', 'Named Credential'],
                ['Basic (user and password)', 'External Credential, protocol Custom: user and password as principal parameters, custom header Authorization = "Basic " + BASE64ENCODE(user:password)', 'Named Credential'],
                ['API key in a header', 'External Credential, protocol Custom: the key as a principal parameter, custom header e.g. x-api-key = {!$Credential.Partner.apiKey}', 'Named Credential'],
                ['AWS Signature Version 4', 'External Credential, protocol AWS Signature Version 4', 'Named Credential'],
                ['Client certificate (mutual TLS)', 'Named Credential > Client Certificate (Setup > Certificate and Key Management)', 'Named Credential'],
                ['A token call of its own (custom body or answer, token in a custom field, a session login, a signature only code can build)', 'Not possible with the settings alone', 'Apex Auth']
            ]
        }],
        points: [
            'Use Named Credential whenever a row above fits: Salesforce keeps the secret, logs in and refreshes the token for you. It is the default, and a blank Connection Type means Named Credential, so existing connections keep working.',
            'Use Apex Auth only for a token call a Named Credential cannot make. The connection keeps its Named Credential (it gives the base URL); your Auth Class logs in through this or another Named Credential, for example Partner_Login for the token URL. No secret is stored in code or in a field.',
            'Set it up: deploy a class that implements IntegrationHub.IConnectionAuth (template below) with its test class, then on the connection pick Connection Type = Apex Auth and the class in Auth Class.',
            'Before each send the hub calls authorize(ctx): set the header on ctx.request. Keep the token with IntegrationHubTokenCache: it is kept for the job, and in Platform Cache when the org has a default partition (without it everything works; the class just logs in once per job).',
            'After a 401 the hub calls the class again with ctx.refresh = true and resends once. A class that is missing, or an error the class throws, fails the transaction for good (no auto-retry), with its message. A CalloutException at the token URL (down or timed out) is temporary: auto-retry applies.',
            'Check connection runs the Auth Class first and says in plain words when the login fails. Preview payload and View request never show the token: they show "Authorization: added by <Auth Class> at send time (hidden)".',
            'Callouts: one Apex Auth send may use up to 4 callouts (login, send, login again, resend). The send job keeps room for them under the 100-callout limit and chains the rest.'
        ],
        codes: [{ label: 'An auth class (IntegrationHub.IConnectionAuth)', code: AUTH_CODE }],
        template: 'IH_SampleConnectionAuth',
        tip: 'Platform Events are not a connection type. When a team hits the daily Platform Event delivery allowance because the middleware subscribes to events (e.g. subscribing over Pub/Sub), move that flow to an outbound event of the hub: its callouts do not use the event delivery allowance.'
    },
    {
        key: 'event', group: 'setup', short: 'Event', title: 'Add an event record', object: 'IH_Event__c', go: 'Open Events',
        lead: 'One event per business event. It says where to send, what to send and what to expect back.',
        points: [
            'Where: Integration Hub app > Events tab > New. One record per business event. New and Edit open a guided editor in 4 steps: Basics, What to send, Reply & callback, Check & save. A new event is saved inactive; activate it when the checks are green.',
            'Related Object: any standard or custom object. The editor shows its label, API name and Id prefix (e.g. Voucher · Voucher__c · a0X). Payload Fields: pick the fields, including parent fields (Account.Name), from the list.',
            'Class pickers list only classes that implement the right interface; test classes are never offered.',
            'Every event: Event Name, Event Key (capitals and underscores, e.g. CASE_WEB_CREATED; this is what your code and the URL use), Direction, Connection, Active.',
            'Outbound event: Related Object (e.g. Case), Path (added to the Named Credential URL, e.g. /api/cases), HTTP Method, Transaction Id Key (default sfTransactionId).',
            'An active outbound event must have a Path (validation rule Outbound_Needs_Path).',
            'Path may contain {recordId} and {transactionId}, filled per record, and a query string, e.g. /api/cases/{recordId}?ref={transactionId}.',
            'Payload Source (picklist): Selected Fields = the fields listed in Payload Fields (CaseNumber, Subject, Account.Name...). Apex Class = your class builds the JSON; type its name in Payload Class (see the code below).',
            'Outbound with a callback: tick Expects Callback and set Callback Timeout (hours). A 2xx reply then sets Sent until the callback arrives.',
            'Outbound, optional: Response Handler Class = the name of your class (Build > Response handler). Leave blank if Status and External Reference are enough.',
            'Business Data In Response: tick it when the answer or the callback carries business data to save. It needs a Response Handler Class (validation rule Business_Data_Needs_Handler).',
            'Inbound event: Handler Class = the name of your class (Build > Inbound handler). The URL is /services/apexrest/integrationhub/v1/ + Event Key.',
            'Share With Related Record (on by default): users see transactions of records they can open. Retention (days): the nightly clean-up deletes Success transactions older than this; leave it blank to keep them for ever.',
            'Auto-retry (outbound, step Reply & callback): Auto Retry Max (0 to 10; blank or 0 = off) and Retry After (minutes, default 15, doubled for each retry). The editor suggests 3 and 15. Existing events stay off until you set them. See Run and fix > Auto-retry.',
            'Done? Click Preview payload on the event page to see the exact JSON for a real record. Nothing is sent.'
        ],
        codes: [{ label: 'What Selected Fields sends, and a payload class', code: PAYLOAD_CODE + '\n\n' + PAYLOAD_CLASS_CODE }],
        template: 'IH_SamplePayloadBuilder'
    },
    {
        key: 'trigger', group: 'build', short: 'Publish from a trigger', title: 'Publish from your trigger handler',
        lead: 'One line of Apex sends records. It is safe to deploy before the event exists.',
        points: [
            'The only code for outbound. An unknown or inactive event does nothing, so it is safe to deploy first.',
            'Pass a List of records or a List of record Ids. A Set or a Map is not accepted: use new List<Id>(set) or map.values(). Null-safe: a null or empty list, null records and records without an Id are skipped, and duplicates are sent once.',
            'Publishing is skipped for users or profiles with Disable Publishing (see Run and fix > Switch sending off).'
        ],
        codes: [{ label: 'Publish', code: TRIGGER_CODE }]
    },
    {
        key: 'payload', group: 'build', short: 'Payload class', title: 'Build your own JSON with a payload class',
        lead: 'Use it only when Selected Fields is not enough, for example nested objects or other field names.',
        points: [
            'On the event set Payload Source = Apex Class and type the class name in Payload Class.',
            'The class implements IntegrationHub.IPayloadBuilder and gets every record of one send in req.recordIds. Query them once, not one by one.',
            'Return one body per record Id. A Map body gets sfTransactionId added for you (or the name in Transaction Id Key). A String body is sent exactly as returned.',
            'Check the result with Preview payload on the event page before the first send.'
        ],
        tables: [{
            columns: ['Payload Source', 'What is sent'],
            rows: [
                ['Selected Fields', '{sfTransactionId, eventName, recordId, object, fields:{...}}; empty fields are left out'],
                ['Apex Class', 'Whatever your class returns; a Map body gets sfTransactionId added']
            ]
        }],
        codes: [{ label: 'A payload class', code: PAYLOAD_CLASS_CODE }],
        template: 'IH_SamplePayloadBuilder'
    },
    {
        key: 'response', group: 'build', short: 'Response handler', title: 'Handle the reply and the callback (optional)',
        lead: 'Without a class the hub already sets the status and the reference. Add a class only for extra steps.',
        points: [
            'Without any code: a 2xx reply sets Success (or Sent when the event has Expects Callback). Any error sets Failed; retry it by hand from the Monitor or the Transactions tab, or let Auto-retry resend temporary failures.',
            'The callback: the system keeps sfTransactionId from the payload and calls PATCH .../callback/{sfTransactionId} as the connection Inbound User. status ACCEPTED, SUCCESS, OK, CREATED or COMPLETED sets Success; FAILED, REJECTED or ERROR sets Failed; reference fills External Reference Id.',
            'To do more (update the Case, create records, call another process): create a class that implements IntegrationHub.IResponseHandler, then open the event (Events tab) and type the class name in Response Handler Class. It runs after the reply and again after the callback.',
            'After the immediate answer: ctx.isCallback = false, ctx.httpStatus and ctx.body are set. After the callback: ctx.isCallback = true.',
            'New: ctx.data is the parsed "data" object of the answer or callback, and ctx.result is a short line you set; it is shown as Business Result.',
            'An error in the handler marks the transaction Failed. With Business Data In Response it sets Business Status = Failed instead and leaves the delivery status alone.',
            'A handler can run more than once on the same data (Rerun handler, a repeated callback). Update or upsert; never a blind insert.'
        ],
        codes: [{ label: 'Callback call and a response handler', code: CALLBACK_CODE + '\n\n' + RESPONSE_CODE }],
        template: 'IH_SampleResponseHandler'
    },
    {
        key: 'business', group: 'build', short: 'Business data in response', title: 'Business data in the answer or callback',
        lead: 'The middleware returns business data (a voucher, an order number, a list). Your handler saves it in the background.',
        points: [
            'On the event tick Business Data In Response. It needs a Response Handler Class.',
            'The middleware wraps its data in the envelope below, in the immediate answer or in the callback. When the event also expects a callback, an immediate answer without "data" does not run the handler; the callback does.',
            'The hub stores the status and reference first, as always. Then it sets Business Status = Processing and runs your handler in the background (Queueable).',
            'When the handler ends: Business Status = Done and the line in ctx.result is shown as Business Result. When it throws an error: Business Status = Failed and the error is kept. The delivery status does not change.',
            'Fix the cause, then open the transaction and click Rerun handler (admins, only when Business Status is Failed). Nothing is sent again.',
            'A handler can run more than once on the same data (Rerun handler, a repeated callback). Update or upsert; never a blind insert.',
            'The handler runs without callouts: it saves data in Salesforce only.'
        ],
        tables: [{
            columns: ['Business Status', 'Meaning'],
            rows: [
                ['Processing', 'The handler is queued or running'],
                ['Done', 'The handler finished; see Business Result'],
                ['Failed', 'The handler threw an error; see Business Error; Rerun handler is offered']
            ]
        }],
        codes: [
            { label: 'Envelope the middleware sends (answer or callback)', code: ENVELOPE_CODE },
            { label: 'A handler that saves the data', code: BUSINESS_HANDLER_CODE }
        ],
        template: 'IH_SampleResponseHandler'
    },
    {
        key: 'inbound', group: 'build', short: 'Inbound handler', title: 'Receive calls (inbound)',
        lead: 'The middleware calls Salesforce. Your class decides what happens and what is answered.',
        points: [
            'Create a class that implements IntegrationHub.IInboundHandler, then open the inbound event (Events tab) and type the class name in Handler Class.',
            'The caller logs in as the Inbound User of the event connection and calls POST .../integrationhub/v1/{Event Key}. Any other user gets 403.',
            'The class returns inboundSuccess (200 with your data) or inboundFailure (your status code and message). X-Request-Id stops a repeated call from running twice.'
        ],
        codes: [{ label: 'Inbound call and handler class', code: INBOUND_CODE + '\n\n' + INBOUND_HANDLER_CODE }],
        template: 'IH_SampleInboundHandler'
    },
    {
        key: 'give-outbound', group: 'give', short: 'Outbound: what we send', title: 'Outbound: what we send to the middleware',
        lead: 'Give this to the middleware team so they know the call they will receive.',
        tables: [
            {
                columns: ['Item', 'Value'],
                rows: [
                    ['URL', 'The Named Credential URL + the event Path. {recordId} and {transactionId} are filled; a query string is allowed'],
                    ['Method', 'POST, or PUT / PATCH as set on the event'],
                    ['Headers', 'Content-Type: application/json, X-Correlation-Id (same on resends), plus the connection\'s Headers JSON'],
                    ['Login', 'From the Named Credential, or with Connection Type Apex Auth the header the Auth Class adds (e.g. Authorization: Bearer ...)'],
                    ['Body (Selected Fields)', '{sfTransactionId, eventName, recordId, object, fields:{...}}; empty fields are left out'],
                    ['Body (Apex Class)', 'The shape your payload class builds; a Map body gets sfTransactionId added'],
                    ['Transaction Id Key', 'Renames sfTransactionId in the body, e.g. requestRef']
                ],
                mono: []
            },
            Object.assign({ title: 'What we expect back' }, OUTBOUND_ANSWERS)
        ],
        codes: [{ label: 'Example request', code: OUTBOUND_REQUEST_CODE }],
        tip: 'Tip: Preview payload on any event builds this request for a real record. Nothing is sent or saved.'
    },
    {
        key: 'give-callback', group: 'give', short: 'Callback: what they send back', title: 'Callback: what the middleware sends back',
        lead: 'When an event has Expects Callback, the middleware reports the result with one PATCH, using the sfTransactionId it received.',
        tables: [
            {
                columns: ['Item', 'Value'],
                rows: [
                    ['URL', 'PATCH https://<my-domain>.my.salesforce.com/services/apexrest/integrationhub/v1/callback/{sfTransactionId}'],
                    ['Headers', 'Authorization: Bearer <token of the Inbound User> · Content-Type: application/json'],
                    ['Body', '{"status", "reference", "message"}, plus "data" only with Business Data In Response'],
                    ['Status words', 'SUCCESS, ACCEPTED, OK, CREATED, COMPLETED = success · FAILED, REJECTED, ERROR = failure'],
                    ['Deadline', 'The event\'s Callback Timeout (default 24 h). Else the nightly clean-up sets Failed']
                ],
                mono: [1]
            },
            CALLBACK_ANSWERS
        ],
        codes: [{ label: 'Body', code: CALLBACK_BODY_CODE }],
        tip: 'Tip: on any event, Preview payload builds a ready example of this callback for a real record.'
    },
    {
        key: 'give-inbound', group: 'give', short: 'Inbound: how they call us', title: 'Inbound: how the middleware calls Salesforce',
        lead: 'One POST per record. X-Request-Id makes a resend safe.',
        tables: [
            {
                columns: ['Item', 'Value'],
                rows: [
                    ['URL', 'POST https://<my-domain>.my.salesforce.com/services/apexrest/integrationhub/v1/{Event Key}'],
                    ['Headers', 'Authorization: Bearer <token of the Inbound User> · Content-Type: application/json · X-Request-Id: <unique per request>'],
                    ['Body', 'A JSON object; the fields your handler class accepts'],
                    ['Result later', 'GET .../integrationhub/v1/status/{transactionId} returns the result']
                ],
                mono: [1]
            },
            INBOUND_ANSWERS
        ],
        points: [
            'Without X-Request-Id the call still works, but a resend creates a duplicate.',
            'After a timeout or 5xx: send the same body with the SAME X-Request-Id. The first answer is replayed; nothing runs twice.',
            'After 400 or 422: fix the data and send with a NEW X-Request-Id.'
        ],
        codes: [{ label: 'Example call', code: INBOUND_BODY_CODE }]
    },
    {
        key: 'give-answers', group: 'give', short: 'Answers and retry rules', title: 'Answers and retry rules',
        lead: 'What each answer means, in both directions. Temporary failures are sent again by themselves only when the event has Auto Retry Max.',
        tables: [
            Object.assign({}, OUTBOUND_ANSWERS, { title: 'Our outbound call: the middleware answers' }),
            CALLBACK_ANSWERS,
            INBOUND_ANSWERS
        ],
        points: [
            'Outbound, automatically: a temporary failure (408, 429, 5xx, no answer, a send job that stopped) is sent again by itself when the event has Auto Retry Max, after 15, 30, 60 minutes... (Run and fix > Auto-retry). A permanent one (any other 4xx, a handler error, a missing Auth Class) never is.',
            'Outbound, by hand: a person uses Retry with new payload or Resend original payload (Run and fix > Retry), for permanent failures and when auto-retry is off or used up.',
            'Every resend keeps the same X-Correlation-Id, so the middleware can spot a duplicate.',
            'Inbound: the middleware resends with the SAME X-Request-Id after a timeout or 5xx, and with a NEW one after 400 or 422.'
        ]
    },
    {
        key: 'monitor', group: 'run', short: 'Monitor', title: 'Watch and fix', tab: 'IH_Monitor', go: 'Open Monitor',
        lead: 'The Monitor shows totals and failures. The Transactions tab shows every single call.',
        points: [
            'Monitor: totals and failures grouped by event and error; retry a whole group after fixing the cause (new payload). Temporary failures of events with Auto Retry Max are retried automatically; the Scheduled jobs card shows how many wait and when the next one is due.',
            'Transactions tab: search everything, see every field and body, retry one or many.',
            'Connection page: Check connection sends one GET to the Named Credential URL (no record data) and says whether the system answered; 401 or 403 means the credential was refused. For an Apex Auth connection it runs the Auth Class first and says when the login fails. The page also lists the connection\'s events.',
            'Event page: Check endpoint sends one GET to the Named Credential URL plus the event Path (no record data). 405 means the endpoint exists but takes POST, 404 means a wrong Path (the start of the system\'s reply is shown), 401 or 403 means the credential was refused.',
            'Record pages: add "Integration Transactions (no Apex)" in Lightning App Builder.'
        ]
    },
    {
        key: 'preview', group: 'run', short: 'Preview payload & View request', title: 'Preview payload and View request',
        lead: 'See the exact JSON before a send, and everything that happened after it.',
        points: [
            'Preview payload: a button on the event page (admins). Type a record Id, or the value of the object\'s name field (Case Number, Account Name, an auto number of a custom object), and click Build.',
            'It shows how we send it (method, URL, headers, JSON) and how we expect it back (answers, callback, the "data" envelope). Nothing is sent or saved.',
            'Inbound events: leave the record blank to get a body template for the middleware.',
            'View request: a button on the transaction page. It shows the request, the answer, the callback, the business processing and every attempt.',
            'Each part has a Copy button. A body over 131,072 characters is cut on screen; the full body is saved as a File on the transaction and opens from the link.',
            'Secrets are never shown: a header whose name contains authorization, token, secret, password or api-key is masked (e.g. Bearer ••••), and an Apex Auth connection shows "Authorization: added by <Auth Class> at send time (hidden)".',
            'While a Failed transaction waits for auto-retry, View request and the transaction card say "Will retry automatically at 10:45 (2 of 3)".'
        ]
    },
    {
        key: 'retry', group: 'run', short: 'Retry, resend, rerun handler', title: 'Retry, resend or rerun the handler',
        lead: 'Pick the button by what failed: the send, or the business processing after it.',
        tables: [{
            columns: ['What failed', 'Button', 'What it does'],
            rows: [
                ['The send: wrong data or payload fields', 'Retry with new payload', 'Rebuilds the JSON from the record as it is now and sends it'],
                ['The send: connectivity, timeout, 429, 5xx', 'Resend original payload (or let Auto-retry do it)', 'Sends the stored Request Payload unchanged'],
                ['The business processing (Business Status Failed)', 'Rerun handler', 'Runs the handler again on the stored answer; nothing is sent (admins)']
            ]
        }],
        points: [
            'Two ways to retry a failed send, on the Transactions tab, on the transaction record and in the record\'s Integration Transactions list: Retry with new payload rebuilds the JSON from the record as it is now (use it when the data or the payload fields were wrong). Resend original payload sends the stored Request Payload unchanged (use it when the data was fine and the call failed on connectivity, a timeout, 429 or 5xx). Both keep the same X-Correlation-Id, so the receiver can spot a duplicate. A stored payload that is empty or was cut down for length is always rebuilt. Retry group on the Monitor always uses a new payload.',
            'Every send is logged as an Integration Attempt under its transaction (time, outcome, HTTP status, new or original payload, error). Attempts on the transaction counts them; the list is on the transaction page under Related.',
            'Each send and each handler rerun is an Integration Attempt (Kind = Send, Auto Retry or Handler Rerun).',
            'Temporary failures can be resent by themselves, without anyone clicking: see Auto-retry, the next topic. A Retry by hand sends at once and cancels the planned automatic one.'
        ]
    },
    {
        key: 'autoretry', group: 'run', short: 'Auto-retry', title: 'Auto-retry: resend temporary failures by themselves',
        tab: 'IH_Monitor', go: 'Open Monitor',
        lead: 'Switch it on per event. Temporary failures are sent again after 15, 30, 60 minutes...; permanent rejections never are.',
        tables: [
            {
                title: 'What is retried',
                columns: ['Failure', 'Auto-retry'],
                rows: [
                    ['408, 429, 5xx', 'Yes (temporary)'],
                    ['No answer: timeout or callout error (also at the token URL of an Auth Class)', 'Yes (temporary)'],
                    ['The send job stopped (a governor limit, an unhandled error), or no job could be queued', 'Yes (temporary)'],
                    ['Any other 4xx (400, 403, 404, 422, a 401 that the Apex Auth resend did not fix)', 'Never (permanent): fix the data or the setup, then retry by hand'],
                    ['Response handler error, missing Auth Class or an error the Auth Class throws, inactive event or connection', 'Never (permanent)']
                ]
            },
            {
                title: 'Backoff with Retry After = 15 minutes (the default)',
                columns: ['Automatic retry', 'Waits after the failure', 'Time since the first failure'],
                rows: [
                    ['1', '15 min', '15 min'],
                    ['2', '30 min', '45 min'],
                    ['3', '60 min', '1 h 45 min'],
                    ['4', '2 h', '3 h 45 min'],
                    ['5', '4 h', '7 h 45 min']
                ]
            }
        ],
        points: [
            'Switch it on per event: Events > the event > Edit > Reply & callback: Auto Retry Max (0 to 10; blank or 0 = off) and Retry After (minutes, 1 to 1440, default 15). The editor suggests 3 and 15. Existing events stay off until you set them.',
            'A temporary failure stays Failed with Next Retry At = now + Retry After x 2^(automatic retries made), at most one week, and the error says "Will retry automatically at 10:45 (1 of 3)". The error summary ends "(temporary: will retry automatically)", so the Monitor keeps one group per cause.',
            'Every 15 minutes the sweep sets the due transactions to Retry, adds 1 to Auto Retries and clears Next Retry At. The transaction trigger sends them through the normal Sender job; each send is an Integration Attempt with Kind = Auto Retry and keeps the same X-Correlation-Id.',
            'When Auto Retries reaches Auto Retry Max, the error says "auto-retry stopped after 3 of 3": retry it by hand when the system is back.',
            'A Retry by hand (Monitor, Transactions tab, the record\'s list) sends at once and clears Next Retry At. Auto Retries is not reset.',
            'The schedule: four jobs, Integration Hub Auto Retry :00, :15, :30 and :45. IntegrationHubMaintenance.scheduleAll() schedules them with the nightly clean-up and skips any job that already exists. A sandbox refresh removes them: Monitor > Scheduled jobs > Schedule auto-retry. They run as the user who schedules them, so use one that stays active.',
            'Disable Publishing (Integration Hub Settings) for the user the jobs run as, or for the org, pauses the sweep.',
            'Limits: the sweep hands transactions on in chunks of 50, so one send job per 50 (a send job chains when it nears the callout limit). It never resubmits a permanent rejection, so a bad payload cannot loop.'
        ],
        tip: 'Where to see it: the transaction card, the Transactions tab and View request show "Will retry automatically at 10:45 (2 of 3)"; Monitor > Scheduled jobs shows how many wait and the next time.'
    },
    {
        key: 'cleanup', group: 'run', short: 'Nightly clean-up', title: 'Nightly clean-up', tab: 'IH_Monitor', go: 'Open Monitor',
        lead: 'A job runs every night at 02:00. It removes old successes and closes callbacks that never came.',
        points: [
            'Monitor > Scheduled jobs > Nightly clean-up: shows whether the clean-up job is scheduled, its next run, who it runs as, and what the last run did (Success transactions deleted past retention, Sent transactions set to Failed because no callback came in time). It runs every night at 02:00 and never deletes Failed, Abandoned or Sent transactions.',
            'It deletes only Success transactions older than the event\'s Retention (days). Blank Retention = keep for ever.',
            'It marks Sent transactions as Failed when the callback did not come within the event\'s Callback Timeout.',
            'After a sandbox refresh, or in a new org, the job is missing: click Schedule clean-up on that card (or run IntegrationHubMaintenance.scheduleAll(); in Execute Anonymous, which also schedules the auto-retry jobs and skips any job that exists). It runs as the user who schedules it, so use one that stays active.'
        ]
    },
    {
        key: 'switchoff', group: 'run', short: 'Switch sending off', title: 'Switch sending off (data loads)',
        lead: 'Stop outbound sends for one user or profile, for example during a data load.',
        points: [
            'Setup > Custom Settings > Integration Hub Settings > Manage > New.',
            'Pick the user or profile (Location), tick Disable Publishing and Save.',
            'For that user or profile IntegrationHub.publish sends nothing. Inbound calls and callbacks keep working.',
            'Set for the user the auto-retry jobs run as (or for the org), it also pauses auto-retry until it is unticked.',
            'Skipped records are not sent later. Publish them again after the load if the middleware needs them.',
            'Untick it (or delete the row) when the load is done. Leave the Last Clean-up fields alone; the nightly clean-up uses them.'
        ]
    },
    {
        key: 'statuses', group: 'ref', short: 'Statuses', title: 'Transaction statuses',
        lead: 'Status is the delivery. Business Status is your handler\'s work on business data.',
        tables: [
            {
                title: 'Status',
                columns: ['Status', 'Meaning'],
                rows: [
                    ['Pending', 'Queued; the send runs in the background'],
                    ['Received', 'Inbound call being handled'],
                    ['Sent', '2xx received; waiting for the callback'],
                    ['Success', 'Done'],
                    ['Retry', 'Marked for resend'],
                    ['Failed', 'The send, the answer or the callback failed; see the error'],
                    ['Failed + Next Retry At', 'Waiting for auto-retry: it is sent again at about that time (temporary failures of events with Auto Retry Max)'],
                    ['Abandoned', 'Given up; it will not be sent']
                ]
            },
            {
                title: 'Business Status (only with Business Data In Response)',
                columns: ['Business Status', 'Meaning'],
                rows: [
                    ['Processing', 'The handler is queued or running'],
                    ['Done', 'The handler finished; see Business Result'],
                    ['Failed', 'The handler threw an error; Rerun handler after the fix']
                ]
            }
        ]
    },
    {
        key: 'limits', group: 'ref', short: 'Limits', title: 'Salesforce limits your handler runs under',
        lead: 'Screen calls and callbacks run synchronously. The business handler runs in a Queueable.',
        tables: [
            {
                columns: ['Where', 'CPU', 'Heap', 'SOQL', 'DML', 'Rows'],
                rows: [
                    ['Sync (screen calls, callback)', '10 s', '6 MB', '100', '150', '10,000'],
                    ['Queueable (business handler)', '60 s', '12 MB', '200', '150', '10,000']
                ]
            },
            {
                title: 'Callouts of a send job',
                columns: ['Send', 'Callouts it may use'],
                rows: [
                    ['Through a Named Credential connection', '1'],
                    ['Through an Apex Auth connection', 'Up to 4: the Auth Class login, the send, a new login after a 401, the resend'],
                    ['One send job', 'At most 100 (Salesforce limit), the Auth Class logins included; the job keeps 2 free and chains the rest. Up to 100 transactions per job']
                ]
            }
        ],
        points: [
            'One background job handles one batch of answers; more jobs are chained.',
            'Callouts per send job include the logins of an Auth Class: before each send the job checks that the send, its logins and a resend still fit under 100, and chains the rest to the next job.',
            'Bigger work: let the handler start a Batch job.'
        ]
    },
    {
        key: 'implemented', group: 'ref', short: 'What\'s implemented & usage', title: 'What\'s implemented & usage',
        lead: 'Every piece of Integration Hub in this org, how much Apex it uses, and its background jobs today.',
        usage: 'implemented',
        tables: [
            {
                title: 'Components',
                columns: ['Type', 'Count', 'Names'],
                rows: [
                    ['Apex classes and test classes', 'Live', 'Classes named IntegrationHub... or IH_...; admins see each one with its characters on the How To tab'],
                    ['Apex trigger', '1', 'IH_TransactionTrigger'],
                    ['Lightning web components', String(USAGE_LWC.length), USAGE_LWC.join(', ')],
                    ['Aura components', String(USAGE_AURA.length), USAGE_AURA.map((a) => a.name + ' (' + a.note + ')').join(', ')],
                    ['Objects', String(USAGE_OBJECTS.length), USAGE_OBJECTS.join(', ')],
                    ['Permission sets · static resource', USAGE_PERMISSION_SETS.length + ' · 1', USAGE_PERMISSION_SETS.join(', ') + ' · ' + USAGE_RESOURCE]
                ],
                mono: [2],
                live: true
            },
            {
                title: 'Background (async) jobs',
                columns: ['Class', 'Type', 'Runs when', 'Callouts'],
                rows: USAGE_JOBS.map((j) => [j.name, j.type, j.runsWhen, j.callouts]),
                mono: [0],
                live: true
            },
            {
                title: 'Synchronous entry points (no job)',
                columns: ['Where', 'Class', 'Notes'],
                rows: [
                    ['Middleware calls us (inbound, callback, status)', 'IntegrationHubInboundApi', 'REST; runs as the connection\'s Inbound User'],
                    ['Screens (Monitor, Preview payload, View request, setup editor, How To)', 'IntegrationHubMonitorController, IntegrationHubCleanupStatus, IntegrationHubEndpointCheck, IntegrationHubPreview, IntegrationHubBusiness, IntegrationHubSetup, IntegrationHubUsage', '@AuraEnabled; admins (View request: anyone who can see the transaction)'],
                    ['Your trigger or class', 'IntegrationHub.publish(...)', 'Saves the transactions and queues the Sender job'],
                    ['A transaction is saved', 'IH_TransactionTrigger', 'Shares it like its related record; a retry (by hand or by auto-retry) queues the Sender job']
                ],
                mono: [1]
            }
        ],
        tip: 'Only Integration Hub is counted, never the whole org. Admins: the numbers are read from this org when you open this topic; Scan again reads them again. Test classes do not count toward the 6,000,000-character Apex limit.'
    },
    {
        key: 'whouses', group: 'ref', short: 'Who uses Integration Hub', title: 'Who uses Integration Hub',
        lead: 'Every trigger, class, event and background job in this org that uses the framework, so you can track it.',
        usage: 'who',
        tables: [
            {
                title: 'What the scan shows',
                columns: ['Section', 'What it lists'],
                rows: [
                    ['1 · Your code that sends', 'Apex classes and triggers outside Integration Hub whose code calls IntegrationHub.publish, the event keys written in those calls (a key with no event is flagged) and what runs next'],
                    ['2 · Your classes plugged into events and connections', 'Classes named in Payload Class, Response Handler Class and Handler Class, and in a connection\'s Auth Class (role Connection auth), plus classes implementing an Integration Hub interface that nothing uses (flagged none): role, where it is used, where it runs, a test class and characters'],
                    ['3 · Events and their async calls (last 24 h)', 'Per event: transactions, failed ones, the latest one, and the background jobs a call goes through']
                ],
                live: true
            },
            {
                title: '4 · Screens',
                columns: ['Component', 'Type', 'Where', 'Apex it calls'],
                rows: [
                    ['ihSetupOverride', 'Aura', 'New / Edit on Connection and Event (hosts ihSetupEditor)', '–'],
                    ['ihSetupEditor', 'LWC', 'Connection and Event editor, record pages', 'IntegrationHubSetup'],
                    ['ihMonitor, ihCleanupStatus', 'LWC', 'Monitor tab', 'IntegrationHubMonitorController, IntegrationHubCleanupStatus'],
                    ['ihEventCheck, ihConnectionCheck, ihPayloadPreview', 'LWC', 'Event and Connection record pages', 'IntegrationHubEndpointCheck, IntegrationHubPreview'],
                    ['ihTransactionView, ihTransactionExchange', 'LWC', 'Transaction record page', 'IntegrationHubPreview, IntegrationHubBusiness'],
                    ['ihTransactionsTab, ihRecordTransactions', 'LWC', 'Transactions tab, record pages', '– (no Apex)'],
                    ['ihHowTo, ihUsage, ihConfigTransfer', 'LWC', 'How To tab', 'IntegrationHubUsage'],
                    ['ihCode, ihNav, ihStyles', 'LWC', 'Shared parts of the screens', '–']
                ],
                mono: [0, 3]
            }
        ],
        tip: 'Apex code of these components only: Integration Hub plus your plugged-in classes. Test classes and anything outside Integration Hub are not counted. The scan reads Apex class and trigger code, events, transactions and background jobs; admins only.'
    },
    {
        key: 'downloads', group: 'ref', short: 'Downloads', title: 'Downloads',
        lead: 'Every sample class, test class, import file and the package.xml in one place.',
        files: SAMPLE_FILES,
        filesNote: 'Templates: rename, change the marked parts, deploy with the test class. Self-test kit: sandboxes only. package.xml lists every framework component, for example to retrieve them with VS Code (SFDX: Retrieve Source in Manifest from Org).'
    },
    {
        key: 'transfer', group: 'ref', short: 'Move setup to another org', title: 'Move the setup to another org',
        lead: 'Export connections and their events here, then import the file in the other org (on its How To tab).',
        embedConfigTransfer: true
    },
    {
        key: 'selfsetup', group: 'test', short: 'Set up the self-org (A–H)', title: 'Self-test in a sandbox: set up',
        lead: 'The sandbox calls itself, so every kind of event can be tried end to end.',
        points: [
            'What it is: the sandbox calls its own Integration Hub endpoint through a Named Credential, so every kind of event can be tried end to end and nothing leaves Salesforce. Sandbox only. A refresh removes the setup, the kit classes and the events: do steps A to H again after each refresh.',
            'A. External Client App: Setup > External Client App Manager > New. Name IH Self Org; enable OAuth; Callback URL https://login.salesforce.com/services/oauth2/success (not used); scope "Manage user data via APIs (api)"; tick Enable Client Credentials Flow; Save. In Policies set Run As to your admin user (this user creates the records). Copy the Consumer Key and Consumer Secret.',
            'B. External Credential: Setup > Named Credentials > External Credentials > New. Label and Name IH_Self_Org, Authentication Protocol OAuth 2.0, Authentication Flow Type Client Credentials with Client Secret Flow, Identity Provider URL https://<this sandbox My Domain>.my.salesforce.com/services/oauth2/token. Then Principals > New: Parameter Name SelfOrgPrincipal, Client Id = Consumer Key, Client Secret = Consumer Secret.',
            'C. Named Credential: Named Credentials tab > New. Label and Name IH_Self_Org, URL https://<this sandbox My Domain>.my.salesforce.com (no path), External Credential IH_Self_Org, Generate Authorization Header ticked.',
            'D. Principal access: Setup > Permission Sets > Integration Hub Admin > External Credential Principal Access > Edit, enable IH_Self_Org - SelfOrgPrincipal. Do the same on Integration Hub Read if other users will publish the examples.',
            'E. Classes: download IH_SelfTestKit and its test class below and deploy them. They are not in the package on purpose: the kit is for sandboxes only.',
            'F. Connection and events: download IH_SelfOrg_import.json below, then on this tab use Move the setup to another org > Import, with Import events inactive unticked. This creates the Self Org connection and all SELF_ events.',
            'G. Inbound User: open the Self Org connection and set Inbound User = the Run As user from A. Without it the inbound calls answer 403.',
            'H. Check: on the Self Org connection page, Check connection should say Reached. On the SELF_SEND_OK event page, Check endpoint should say Endpoint found (405). Then run the code below.'
        ],
        files: [
            { label: 'Download IH_SelfTestKit', file: 'IH_SelfTestKit.cls' },
            { label: 'Download IH_SelfTestKitTest', file: 'IH_SelfTestKitTest.cls' },
            { label: 'Download IH_SelfOrg_import.json', file: 'IH_SelfOrg_import.json' }
        ],
        filesNote: 'Self-test kit: deploy the two classes, import the JSON (steps E and F).'
    },
    {
        key: 'examples', group: 'test', short: 'Run the examples', title: 'Self-test in a sandbox: run the examples',
        lead: 'Run the code once, then compare each transaction with what to expect.',
        points: [
            'The examples:',
            'SELF_SEND_OK: Selected Fields of a Case to SELF_ECHO. Expect Success; the Response Handler Class (IH_SelfTestKit) runs on the reply.',
            'SELF_SEND_CALLBACK: Expects Callback. Expect Sent; after PATCH .../callback/{sfTransactionId} with status SUCCESS and a reference, Success and External Reference Id filled.',
            'SELF_SEND_CLASS: Payload Source = Apex Class (IH_SelfTestKit builds the JSON). Expect Success.',
            'SELF_SEND_REJECT: the target answers 422 (business error). Expect Failed; fix the data, then Retry with new payload.',
            'SELF_SEND_DOWN: the target answers 503 (system down). Expect Failed; when the system is back, Resend original payload. Set Auto Retry Max on the event to watch auto-retry: Next Retry At is filled and the send runs again by itself.',
            'SELF_SEND_CREATE_CASE to SELF_CASE_CREATE: a round trip. The outbound sends Subject, Origin, Status and Priority; the inbound event (handler IH_SelfTestKit) creates a copy Case. Expect the outbound Success and an inbound transaction linked to the new Case.',
            'SELF_SEND_ACCOUNT: any object. Account with parent fields (Owner.Name, CreatedBy.Name) in Payload Fields. Works the same for custom objects.',
            'SELF_SEND_TOKENS: Path tokens. Path is /services/apexrest/integrationhub/v1/SELF_ECHO?caseId={recordId}&ref={transactionId}, and Transaction Id Key = requestRef, so the body carries "requestRef" instead of "sfTransactionId".',
            'Inbound targets SELF_ECHO (success), SELF_REJECT (422), SELF_DOWN (503): call them yourself with POST .../integrationhub/v1/{Event Key}. Send the same X-Request-Id twice and the second call replays the first answer without running again.',
            'Check endpoint: on any outbound example\'s event page, Check endpoint answers 405 "Endpoint found" (the hub only takes POST there).'
        ],
        codes: [{ label: 'Run the outbound examples (Developer Console > Execute Anonymous)', code: EXAMPLES_CODE }]
    }
];

const QUESTIONS = [
    {
        key: 'q1', text: 'Does the middleware need its own JSON shape (nested objects, other names), not just a list of fields?',
        yes: { field: 'Payload Source = Apex Class, Payload Class = your class', topic: 'payload' },
        no: { field: 'Payload Source = Selected Fields, list them in Payload Fields', topic: 'event' }
    },
    {
        key: 'q2', text: 'Does the middleware report the final result later, after its first answer?',
        yes: { field: 'Tick Expects Callback, set Callback Timeout (hours)', topic: 'give-callback' },
        no: { field: 'Leave Expects Callback unticked; a 2xx answer means Success', topic: 'give-outbound' }
    },
    {
        key: 'q3', text: 'Does the answer or the callback bring business data you must save in Salesforce?',
        yes: { field: 'Tick Business Data In Response and set Response Handler Class', topic: 'business' },
        no: { field: 'Leave Business Data In Response unticked; Response Handler Class only for small extra steps', topic: 'response' }
    },
    {
        key: 'q4', text: 'Does the other system also call Salesforce to create or change records?',
        yes: { field: 'Add an inbound event with a Handler Class; set Inbound User on the connection', topic: 'inbound' },
        no: { field: 'No inbound event needed', topic: null }
    },
    {
        key: 'q5', text: 'Does the system need its own token call that a Named Credential cannot make (not OAuth, JWT, API key, Basic, AWS or a certificate)?',
        yes: { field: 'Connection Type = Apex Auth, Auth Class = your IConnectionAuth class (the Named Credential stays for the URL)', topic: 'conntype' },
        no: { field: 'Connection Type = Named Credential (the default)', topic: 'credential' }
    },
    {
        key: 'q6', text: 'Should timeouts, 429 and 5xx answers be sent again without anyone clicking Retry?',
        yes: { field: 'Event: Auto Retry Max (e.g. 3) and Retry After (minutes, e.g. 15); keep the auto-retry jobs scheduled', topic: 'autoretry' },
        no: { field: 'Leave Auto Retry Max blank; retry by hand from the Monitor', topic: 'retry' }
    }
];

const YES_NO = [
    { label: 'Yes', value: 'yes' },
    { label: 'No', value: 'no' }
];

const STORE_LAST = 'ihHowTo.lastTopic';
const STORE_VISITED = 'ihHowTo.visited';
const NARROW_PX = 800;

// Download buttons of a step: its template class and test, or its listed files. All live in IH_Help/samples.
function downloadsOf(s) {
    const file = (label, name) => ({ key: s.key + name, label, name, href: IH_HELP + '/samples/' + name });
    if (s.files) {
        return s.files.map((f) => file(f.label, f.file));
    }
    return s.template
        ? [file('Download class', s.template + '.cls'), file('Download test class', s.template + 'Test.cls')]
        : [];
}

// Browser storage may be blocked (private window, preview): every access is guarded, the page works without it.
function readStore(key) {
    try {
        return window.localStorage.getItem(key);
    } catch (e) {
        return null;
    }
}

function writeStore(key, value) {
    try {
        window.localStorage.setItem(key, value);
    } catch (e) {
        // ignore: storage is a convenience only
    }
}

function readVisited() {
    try {
        const list = JSON.parse(readStore(STORE_VISITED) || '[]');
        return Array.isArray(list) ? list.filter((k) => TOPICS.some((t) => t.key === k)) : [];
    } catch (e) {
        return [];
    }
}

function tableView(table, prefix) {
    const mono = table.mono || [];
    return {
        key: prefix,
        title: table.title,
        hasTitle: Boolean(table.title),
        cols: table.columns.map((c, i) => ({ key: prefix + 'c' + i, label: c })),
        rows: table.rows.map((r, ri) => ({
            key: prefix + 'r' + ri,
            cells: r.map((text, ci) => ({
                key: prefix + 'r' + ri + 'c' + ci,
                text,
                cls: mono.includes(ci) ? 'ih-mono cell' : 'cell'
            }))
        }))
    };
}

function searchText(t) {
    const parts = [t.short, t.title, t.lead || ''].concat(t.points || []);
    (t.tables || []).forEach((tb) => tb.rows.forEach((r) => parts.push(r.join(' '))));
    return parts.join(' ').toLowerCase();
}

const CODE_BY_KEY = {};
TOPICS.forEach((t) => (t.codes || []).forEach((c, i) => {
    CODE_BY_KEY[t.key + '-code' + i] = c;
}));
const SEARCH_INDEX = TOPICS.map((t) => searchText(t));

/**
 * How to use Integration Hub: a stepper index on the left, one topic on the right, copyable code. Apex only in the
 * embedded c/ihUsage (What's implemented & usage, Who uses Integration Hub; admins).
 * Works as a tab, on an app or home page, or on a record page.
 */
export default class IhHowTo extends NavigationMixin(LightningElement) {
    @wire(IsConsoleNavigation) isConsole;
    @wire(EnclosingTabId) tabId;

    currentKey = TOPICS[0].key;
    visited = [];
    query = '';
    narrow = false;
    answers = {};
    resizeObserver;
    observed = false;
    scrollPending = false;

    connectedCallback() {
        const last = readStore(STORE_LAST);
        if (last && TOPICS.some((t) => t.key === last)) {
            this.currentKey = last;
        }
        this.visited = readVisited();
        this.markVisited(this.currentKey);
        try {
            this.narrow = window.innerWidth < NARROW_PX;
        } catch (e) {
            this.narrow = false;
        }
    }

    renderedCallback() {
        if (!this.observed) {
            this.observed = true;
            this.observeWidth();
        }
        if (this.scrollPending) {
            this.scrollPending = false;
            this.scrollToPane();
        }
    }

    disconnectedCallback() {
        if (this.resizeObserver) {
            try {
                this.resizeObserver.disconnect();
            } catch (e) {
                // ignore
            }
            this.resizeObserver = null;
        }
        this.observed = false;
    }

    observeWidth() {
        const root = this.template.querySelector('.how');
        if (!root) {
            this.observed = false;
            return;
        }
        try {
            // eslint-disable-next-line no-undef
            this.resizeObserver = new ResizeObserver((entries) => {
                const width = entries && entries[0] ? entries[0].contentRect.width : root.clientWidth;
                const narrow = width > 0 && width < NARROW_PX;
                if (narrow !== this.narrow) {
                    this.narrow = narrow;
                }
            });
            this.resizeObserver.observe(root);
        } catch (e) {
            this.narrow = root.clientWidth > 0 && root.clientWidth < NARROW_PX;
        }
    }

    scrollToPane() {
        try {
            const pane = this.template.querySelector('.pane');
            if (pane && pane.getBoundingClientRect().top < 0) {
                pane.scrollIntoView({ block: 'start', behavior: 'smooth' });
            }
        } catch (e) {
            // ignore
        }
    }

    markVisited(key) {
        if (!this.visited.includes(key)) {
            this.visited = [...this.visited, key];
            writeStore(STORE_VISITED, JSON.stringify(this.visited));
        }
    }

    select(key) {
        if (!key || !TOPICS.some((t) => t.key === key)) {
            return;
        }
        this.currentKey = key;
        this.markVisited(key);
        writeStore(STORE_LAST, key);
        this.scrollPending = true;
    }

    // ---------- index ----------

    /** The How To as one PDF book, made from this content when the package is built (IH_Help). */
    get pdfUrl() {
        return IH_HELP + '/IntegrationHub_HowTo.pdf';
    }

    get matchingKeys() {
        const q = this.query.trim().toLowerCase();
        if (!q) {
            return null;
        }
        const words = q.split(/\s+/);
        return TOPICS.filter((t, i) => words.every((w) => SEARCH_INDEX[i].includes(w))).map((t) => t.key);
    }

    get groups() {
        const matching = this.matchingKeys;
        const current = this.currentTopic;
        const out = [];
        GROUPS.forEach((g, gi) => {
            const all = TOPICS.filter((t) => t.group === g.key);
            const shown = matching ? all.filter((t) => matching.includes(t.key)) : all;
            if (!shown.length) {
                return;
            }
            const isCurrent = current.group === g.key;
            const read = all.every((t) => this.visited.includes(t.key));
            let state = 'todo';
            if (isCurrent) {
                state = 'current';
            } else if (read) {
                state = 'read';
            }
            out.push({
                key: g.key,
                name: g.name,
                badge: g.badge,
                showTick: state === 'read',
                firstKey: shown[0].key,
                cls: 'group group_' + state + (read ? ' group_done' : '') + (gi === GROUPS.length - 1 ? ' group_last' : ''),
                topics: shown.map((t) => {
                    const on = t.key === this.currentKey;
                    const seen = this.visited.includes(t.key);
                    return {
                        key: t.key,
                        label: t.short,
                        ariaCurrent: on ? 'page' : null,
                        cls: 'topic' + (on ? ' topic_on' : '') + (seen ? ' topic_seen' : '')
                    };
                })
            });
        });
        return out;
    }

    get noMatch() {
        return this.groups.length === 0;
    }

    get progressText() {
        return this.visited.length + ' of ' + TOPICS.length + ' topics read';
    }

    get topicOptions() {
        return TOPICS.map((t) => {
            const g = GROUPS.find((x) => x.key === t.group);
            return { label: g.badge + ' · ' + g.name + ' › ' + t.short, value: t.key };
        });
    }

    get wideClass() {
        return this.narrow ? 'how how_narrow' : 'how';
    }

    get showIndex() {
        return !this.narrow;
    }

    // ---------- current topic ----------

    get currentIndex() {
        const i = TOPICS.findIndex((t) => t.key === this.currentKey);
        return i < 0 ? 0 : i;
    }

    get currentTopic() {
        return TOPICS[this.currentIndex];
    }

    get topic() {
        const t = this.currentTopic;
        const g = GROUPS.find((x) => x.key === t.group);
        const downloads = downloadsOf(t);
        // A live table's static version is for the PDF book and readers; admins see the live one in c/ihUsage.
        const tables = (t.tables || []).map((tb, i) => (tb.live && IS_ADMIN ? null : tableView(tb, t.key + 't' + i))).filter(Boolean);
        return {
            key: t.key,
            title: t.title,
            lead: t.lead,
            hasLead: Boolean(t.lead),
            crumb: g.badge + ' · ' + g.name + ' › ' + t.short,
            points: (t.points || []).map((text, i) => ({ key: t.key + 'p' + i, text })),
            hasPoints: Boolean(t.points && t.points.length),
            tables,
            hasTables: tables.length > 0,
            codes: (t.codes || []).map((c, i) => ({ key: t.key + '-code' + i, label: c.label, code: c.code })),
            hasCodes: Boolean(t.codes && t.codes.length),
            pictures: (t.images || []).map((img) => ({ key: img.file, src: IH_HELP + '/' + img.file, caption: img.caption })),
            hasImages: Boolean(t.images),
            downloads,
            hasDownloads: downloads.length > 0,
            downloadNote: t.filesNote || 'Template to start from: a ready-to-deploy class and its test class. Rename both, change the marked parts, deploy.',
            tip: t.tip,
            hasTip: Boolean(t.tip),
            isChooser: Boolean(t.chooser),
            embedConfigTransfer: Boolean(t.embedConfigTransfer),
            hasUsage: Boolean(t.usage),
            usage: t.usage,
            hasGo: Boolean(t.tab || t.object),
            go: t.go,
            target: t.tab || t.object,
            kind: t.object ? 'object' : 'tab'
        };
    }

    get prevTopic() {
        const i = this.currentIndex;
        return i > 0 ? { key: TOPICS[i - 1].key, label: TOPICS[i - 1].short } : null;
    }

    get nextTopic() {
        const i = this.currentIndex;
        return i < TOPICS.length - 1 ? { key: TOPICS[i + 1].key, label: TOPICS[i + 1].short } : null;
    }

    /** Static facts for c/ihUsage (jobs, components it cannot read from Apex). */
    get usageInfo() {
        return USAGE_INFO;
    }

    // ---------- chooser ----------

    get questions() {
        return QUESTIONS.map((q, i) => ({
            key: q.key,
            label: (i + 1) + '. ' + q.text,
            value: this.answers[q.key] || null
        }));
    }

    get yesNo() {
        return YES_NO;
    }

    get chooserRows() {
        return QUESTIONS.filter((q) => this.answers[q.key]).map((q) => {
            const pick = q[this.answers[q.key]];
            const target = TOPICS.find((t) => t.key === pick.topic);
            return {
                key: q.key,
                field: pick.field,
                topicKey: pick.topic,
                hasTopic: Boolean(target),
                topicLabel: target ? target.short : ''
            };
        });
    }

    get hasChooserRows() {
        return this.chooserRows.length > 0;
    }

    get chooserDone() {
        return QUESTIONS.every((q) => this.answers[q.key]);
    }

    handleAnswer(event) {
        const key = event.target.dataset.key;
        this.answers = { ...this.answers, [key]: event.detail.value };
    }

    handleResetChooser() {
        this.answers = {};
    }

    // ---------- events ----------

    handlePick(event) {
        this.select(event.currentTarget.dataset.key);
    }

    handleCombo(event) {
        this.select(event.detail.value);
    }

    handleSearch(event) {
        this.query = event.target.value || '';
    }

    handleOpenChooser() {
        this.select('chooser');
    }

    handlePrev() {
        if (this.prevTopic) {
            this.select(this.prevTopic.key);
        }
    }

    handleNext() {
        if (this.nextTopic) {
            this.select(this.nextTopic.key);
        }
    }

    handleResetProgress() {
        this.visited = [this.currentKey];
        writeStore(STORE_VISITED, JSON.stringify(this.visited));
    }

    handleGo(event) {
        const { target, kind } = event.currentTarget.dataset;
        const page = kind === 'object' ? objectListPage(target) : tabPage(target);
        openPage(this, page, { isConsole: this.isConsole, tabId: this.tabId, asWorkspaceTab: true });
    }

    async handleCopy(event) {
        const block = CODE_BY_KEY[event.currentTarget.dataset.key];
        let ok = false;
        try {
            await navigator.clipboard.writeText(block.code);
            ok = true;
        } catch (e) {
            ok = false;
        }
        this.dispatchEvent(new ShowToastEvent({
            title: ok ? 'Copied' : 'Copy not available',
            message: ok ? block.label + ' copied.' : 'Select the code and copy it with your keyboard.',
            variant: ok ? 'success' : 'warning'
        }));
    }
}