import { LightningElement, api, wire } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import STATUS from '@salesforce/schema/IH_Transaction__c.Status__c';
import NEXT_RETRY from '@salesforce/schema/IH_Transaction__c.Next_Retry_At__c';
import AUTO_RETRIES from '@salesforce/schema/IH_Transaction__c.Auto_Retries__c';
import AUTO_RETRY_MAX from '@salesforce/schema/IH_Transaction__c.Auto_Retry_Max__c';
import IhTransactionExchange from 'c/ihTransactionExchange';
import { retryLine } from 'c/ihNav';

/**
 * Integration Transaction page card: View request button. Opens the request, the answer, the callback, business
 * processing and attempts of this transaction in a modal. Admins and readers may view; Rerun handler inside the
 * modal is for admins only (decided by Apex). A Failed transaction waiting for auto-retry shows when it is resent.
 */
export default class IhTransactionView extends LightningElement {
    @api recordId;

    record;

    @wire(getRecord, { recordId: '$recordId', optionalFields: [STATUS, NEXT_RETRY, AUTO_RETRIES, AUTO_RETRY_MAX] })
    wiredRecord({ data }) {
        this.record = data;
    }

    /** "Will retry automatically at 10:45 (2 of 3)", or '' when no automatic retry is planned. */
    get retryText() {
        const r = this.record;
        if (!r || getFieldValue(r, STATUS) !== 'Failed') {
            return '';
        }
        return retryLine(getFieldValue(r, NEXT_RETRY), getFieldValue(r, AUTO_RETRIES), getFieldValue(r, AUTO_RETRY_MAX));
    }

    async handleView() {
        await IhTransactionExchange.open({ size: 'large', label: 'View request', transactionId: this.recordId });
    }
}