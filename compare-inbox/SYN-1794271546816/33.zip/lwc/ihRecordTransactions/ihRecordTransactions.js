import { LightningElement, api, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { gql, graphql, refreshGraphQL } from 'lightning/uiGraphQLApi';
import { updateRecord } from 'lightning/uiRecordApi';
import { IsConsoleNavigation, EnclosingTabId } from 'lightning/platformWorkspaceApi';
import isAdmin from '@salesforce/customPermission/Integration_Hub_Admin';
import { openPage, recordPage, errorMessage, retryLine } from 'c/ihNav';

const RETRYABLE = ['Failed', 'Abandoned'];

// Auto-refresh while transactions are in progress. Pending/Received/Retry change within seconds; Sent waits for
// an external callback that can take hours, so it is polled slowly. Polling stops after POLL_MAX of continuous
// polling (a manual refresh or a retry starts it again), while the browser tab is hidden, and on disconnect.
const FAST_STATUSES = ['Pending', 'Received', 'Retry'];
const POLL_FAST = 5000;
const POLL_SLOW = 30000;
const POLL_MAX = 30 * 60 * 1000;

/**
 * Integration transactions of the current record. No Apex: reads with the GraphQL wire adapter (the user's own
 * sharing and field access apply) and retries with updateRecord. Works on any record page, standard or console.
 */
export default class IhRecordTransactions extends NavigationMixin(LightningElement) {
    @api recordId;
    @api cardTitle = 'Integration Transactions';
    @api maxRows = 50;
    /** Rows shown before the list scrolls (the rest stay loaded; scroll to see them). */
    @api visibleRows = 5;

    @wire(IsConsoleNavigation) isConsole;
    @wire(EnclosingTabId) tabId;

    rows = [];
    total = 0;
    error;
    loading = true;
    busy = false;
    statusFilter = 'all';
    graphqlResult;
    polling = false;
    pollTimer;
    pollStarted;
    connected = false;

    get variables() {
        return {
            // The transactions of this record, or, on a transaction's own page, that transaction.
            where: { or: [{ Related_Record_Id__c: { eq: this.recordId } }, { Id: { eq: this.recordId } }] },
            first: Math.min(Number(this.maxRows) || 50, 200)
        };
    }

    @wire(graphql, {
        query: gql`
            query recordTransactions($where: IH_Transaction__c_Filter, $first: Int) {
                uiapi {
                    query {
                        IH_Transaction__c(where: $where, first: $first, orderBy: { CreatedDate: { order: DESC } }) {
                            totalCount
                            edges {
                                node {
                                    Id
                                    Name { value }
                                    Direction__c { value }
                                    Event_Name__c { value }
                                    Target_Name__c { value }
                                    Status__c { value }
                                    Error_Summary__c { value }
                                    External_Reference_Id__c { value }
                                    Attempt_Count__c { value }
                                    Http_Status_Code__c { value }
                                    Next_Retry_At__c { value }
                                    Auto_Retries__c { value }
                                    Auto_Retry_Max__c { value }
                                    CreatedDate { value }
                                }
                            }
                        }
                    }
                }
            }
        `,
        variables: '$variables'
    })
    wiredTransactions(result) {
        this.graphqlResult = result;
        const { data, errors } = result;
        if (data) {
            const conn = data.uiapi.query.IH_Transaction__c;
            this.total = conn.totalCount;
            this.rows = conn.edges.map((e) => {
                const n = e.node;
                const status = n.Status__c.value;
                const failed = RETRYABLE.includes(status);
                const retry = status === 'Failed' && n.Next_Retry_At__c
                    ? retryLine(n.Next_Retry_At__c.value, n.Auto_Retries__c.value, n.Auto_Retry_Max__c.value) : '';
                return {
                    id: n.Id,
                    name: n.Name.value,
                    url: '/' + n.Id,
                    direction: n.Direction__c.value === 'Inbound' ? 'IN' : 'OUT',
                    directionClass: 'ih-tag ' + (n.Direction__c.value === 'Inbound' ? 'ih-tag_in' : 'ih-tag_rest'),
                    eventName: n.Event_Name__c.value,
                    targetName: n.Target_Name__c.value,
                    status,
                    badgeClass: 'ih-badge ih-badge_' + status,
                    note: failed ? [retry, n.Error_Summary__c.value].filter(Boolean).join(' · ')
                        : (n.External_Reference_Id__c.value || (status === 'Sent' ? 'Waiting for callback' : '')),
                    noteClass: failed ? 'ih-note ih-note_bad' : 'ih-note',
                    attempts: n.Attempt_Count__c.value || 0,
                    http: n.Http_Status_Code__c.value,
                    createdDate: n.CreatedDate.value,
                    canRetry: isAdmin && failed,
                    retryLabel: 'Retry choices for ' + n.Name.value
                };
            });
            this.error = undefined;
            this.loading = false;
            this.schedulePoll();
        } else if (errors) {
            this.error = errors.map((e) => e.message).join(', ');
            this.rows = [];
            this.loading = false;
            this.stopPolling();
        }
    }

    /* ---------------- auto-refresh ---------------- */

    connectedCallback() {
        this.connected = true;
        document.addEventListener('visibilitychange', this.handleVisibility);
    }

    disconnectedCallback() {
        this.connected = false;
        document.removeEventListener('visibilitychange', this.handleVisibility);
        this.stopPolling();
    }

    handleVisibility = () => {
        if (document.visibilityState === 'hidden') {
            this.stopPolling();
        } else if (this.pollDelay()) {
            // Back on the tab: catch up now, then carry on with a fresh time limit.
            this.pollStarted = undefined;
            this.poll();
        }
    };

    /** 5 s while any loaded row is Pending/Received/Retry, 60 s while any is Sent, else 0 (stop). */
    pollDelay() {
        if (this.rows.some((r) => FAST_STATUSES.includes(r.status))) {
            return POLL_FAST;
        }
        return this.rows.some((r) => r.status === 'Sent') ? POLL_SLOW : 0;
    }

    /** Called after every data load: one timer at most, never stacked. */
    schedulePoll() {
        clearTimeout(this.pollTimer);
        this.pollTimer = undefined;
        const delay = this.pollDelay();
        if (!delay) {
            this.pollStarted = undefined;
        }
        if (!delay || !this.connected || document.visibilityState === 'hidden') {
            this.polling = false;
            return;
        }
        if (!this.pollStarted) {
            this.pollStarted = Date.now();
        } else if (Date.now() - this.pollStarted >= POLL_MAX) {
            this.polling = false;
            return;
        }
        this.polling = true;
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this.pollTimer = setTimeout(() => this.poll(), delay);
    }

    stopPolling() {
        clearTimeout(this.pollTimer);
        this.pollTimer = undefined;
        this.polling = false;
    }

    /** Background refresh: no spinner, no busy, filters and selection kept. */
    async poll() {
        this.pollTimer = undefined;
        if (!this.connected || !this.graphqlResult) {
            return;
        }
        try {
            await refreshGraphQL(this.graphqlResult);
        } catch (e) {
            // Keep the rows on screen; the next load or a manual refresh shows any error.
        }
        // The wire handler reschedules when data changes; this covers a refresh that returned the same data.
        this.schedulePoll();
    }

    get filtered() {
        if (this.statusFilter === 'all') {
            return this.rows;
        }
        if (this.statusFilter === 'bad') {
            return this.rows.filter((r) => RETRYABLE.includes(r.status));
        }
        return this.rows.filter((r) => ['Pending', 'Received', 'Sent', 'Retry'].includes(r.status));
    }

    get tiles() {
        const count = (list) => this.rows.filter((r) => list.includes(r.status)).length;
        const tile = (key, label, value, tone) => ({
            key, label, value,
            cls: `ih-tile ih-tone_${tone}` + (this.statusFilter === key ? ' ih-tile_on' : '')
        });
        return [
            tile('all', 'All', this.rows.length, 'brand'),
            tile('wait', 'In progress', count(['Pending', 'Received', 'Sent', 'Retry']), 'info'),
            tile('bad', 'Failed', count(RETRYABLE), 'bad')
        ];
    }

    handleTile(event) {
        this.statusFilter = event.currentTarget.dataset.key;
    }

    // About 6rem per row (status line, details line, one or two lines of note).
    get listStyle() {
        const rows = Math.max(Number(this.visibleRows) || 5, 1);
        return this.filtered.length > rows ? `max-height: ${rows * 6}rem; overflow-y: auto;` : '';
    }

    get title() {
        return this.total ? `${this.cardTitle} (${this.total})` : this.cardTitle;
    }

    get hasRows() {
        return this.filtered.length > 0;
    }

    get isEmpty() {
        return !this.loading && !this.error && this.rows.length === 0;
    }

    get showMore() {
        return this.total > this.rows.length;
    }

    get moreText() {
        return `Showing the latest ${this.rows.length} of ${this.total}. The Integration Hub app has all of them.`;
    }

    handleOpen(event) {
        event.preventDefault();
        openPage(this, recordPage(event.currentTarget.dataset.id, 'IH_Transaction__c'),
            { isConsole: this.isConsole, tabId: this.tabId, label: event.currentTarget.dataset.label });
    }

    // Menu value: 'new' rebuilds the payload from the record as it is now; 'original' resends the stored one.
    // A stored copy that is empty or was cut down for length is always rebuilt by the sender.
    async handleRetry(event) {
        const id = event.currentTarget.dataset.id;
        const rebuild = event.detail.value === 'new';
        this.busy = true;
        try {
            await updateRecord({ fields: { Id: id, Status__c: 'Retry', Next_Retry_At__c: null,
                Rebuild_Payload__c: rebuild, Error_Message__c: null, Error_Summary__c: null } });
            this.toast('success', rebuild ? 'Queued to send again with a new payload.' : 'Queued to resend the original payload.');
            this.pollStarted = undefined;
            await refreshGraphQL(this.graphqlResult);
            this.schedulePoll();
        } catch (e) {
            this.toast('error', errorMessage(e, 'Retry failed.'));
        } finally {
            this.busy = false;
        }
    }

    async handleRefresh() {
        this.busy = true;
        this.pollStarted = undefined;
        try {
            await refreshGraphQL(this.graphqlResult);
        } finally {
            this.busy = false;
            this.schedulePoll();
        }
    }

    toast(variant, message) {
        this.dispatchEvent(new ShowToastEvent({ title: variant === 'error' ? 'Error' : 'Done', message, variant }));
    }
}