import { LightningElement, api, wire } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getRecord, getFieldValue, notifyRecordUpdateAvailable } from 'lightning/uiRecordApi';
import { decodeDefaultFieldValues, encodeDefaultFieldValues } from 'lightning/pageReferenceUtils';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getSetup from '@salesforce/apex/IntegrationHubSetup.getSetup';
import fieldOptions from '@salesforce/apex/IntegrationHubSetup.fieldOptions';
import objectOptions from '@salesforce/apex/IntegrationHubSetup.objectOptions';
import classOptions from '@salesforce/apex/IntegrationHubSetup.classOptions';
import namedCredentials from '@salesforce/apex/IntegrationHubSetup.namedCredentials';
import userAccess from '@salesforce/apex/IntegrationHubSetup.userAccess';
import saveRecord from '@salesforce/apex/IntegrationHubSetup.save';
import checkEvent from '@salesforce/apex/IntegrationHubEndpointCheck.checkEvent';
import checkConnection from '@salesforce/apex/IntegrationHubEndpointCheck.checkConnection';
import CONNECTION_NAME from '@salesforce/schema/IH_Connection__c.Name';
import CONNECTION_CREDENTIAL from '@salesforce/schema/IH_Connection__c.Named_Credential__c';
import IhPayloadPreview from 'c/ihPayloadPreview';
import { errorMessage } from 'c/ihNav';
import { parseHeaders, isMergeField } from 'c/ihSetupHeaders';
import { splitPaths } from 'c/ihSetupFieldPicker';

const EVENT = 'IH_Event__c';
const CONNECTION = 'IH_Connection__c';
const USER_NAME = 'User.Name';
const OUTBOUND = 'Outbound';
const INBOUND = 'Inbound';
const APEX_CLASS = 'Apex Class';
const APEX_AUTH = 'Apex Auth';
const NAMED_CREDENTIAL = 'Named Credential';
const SUGGESTED_RETRIES = 3;
const SUGGESTED_MINUTES = 15;
const INBOUND_URL = '/services/apexrest/integrationhub/v1/';
const KEY_FORMAT = /^[A-Z][A-Z0-9_]*$/;
const PATH_TOKENS = ['recordId', 'transactionId'];
const BAD_CODES = [401, 403, 404];
const EVENTS_SHOWN = 5;

const EVENT_STEPS = ['Basics', 'What to send', 'Reply & callback', 'Check & save'];
const CONNECTION_STEPS = ['Basics', 'Endpoint & headers', 'Inbound user & check'];

/* The step each field is edited on. */
const EVENT_STEP_OF = {
    Name: 0, Event_Key__c: 0, Direction__c: 0, Connection__c: 0, Related_Object__c: 0, Active__c: 0,
    Share_With_Related_Record__c: 0, Description__c: 0,
    Path__c: 1, Http_Method__c: 1, Payload_Source__c: 1, Payload_Fields__c: 1, Payload_Class__c: 1,
    Transaction_Id_Key__c: 1, Handler_Class__c: 1,
    Response_Handler_Class__c: 2, Business_Data_In_Response__c: 2, Expects_Callback__c: 2, Callback_Timeout_Hours__c: 2,
    Auto_Retry_Max__c: 2, Retry_After_Minutes__c: 2, Retention_Days__c: 2
};
const CONNECTION_STEP_OF = {
    Name: 0, Description__c: 0, Active__c: 0, Connection_Type__c: 1, Named_Credential__c: 1, Auth_Class__c: 1, Timeout_Seconds__c: 1,
    Headers__c: 1, Inbound_User__c: 2
};
/* Event fields that only apply to outbound events. */
const OUTBOUND_ONLY = [
    'Related_Object__c', 'Share_With_Related_Record__c', 'Path__c', 'Http_Method__c', 'Payload_Source__c',
    'Payload_Fields__c', 'Payload_Class__c', 'Transaction_Id_Key__c', 'Response_Handler_Class__c',
    'Business_Data_In_Response__c', 'Expects_Callback__c', 'Callback_Timeout_Hours__c', 'Auto_Retry_Max__c', 'Retry_After_Minutes__c'
];

/* A class whose own name (or its outer class) ends in Test, Tests or TestData is never offered. The server already
   leaves out every class with @IsTest; this is a second guard on the screen. */
const TEST_NAME = /(^|\.)[A-Za-z0-9_]*(Test|Tests|TestData)(\.|$)/;

function blank(v) {
    return v === null || v === undefined || String(v).trim() === '';
}

function text(v) {
    return blank(v) ? '' : String(v).trim();
}

function bool(v) {
    return v === true || v === 'true';
}

function yesNo(v) {
    return bool(v) ? 'Yes' : 'No';
}

function sameText(a, b) {
    return text(a).toLowerCase() === text(b).toLowerCase();
}

/* A whole number from min to max, or blank. */
function wholeIn(v, min, max) {
    if (blank(v)) {
        return true;
    }
    const n = Number(v);
    return Number.isInteger(n) && n >= min && n <= max;
}

/* "Off", or "3 retries · after 15, 30, 60 min" (the waits double). */
function autoRetrySummary(maxValue, minutesValue) {
    const max = Number(maxValue) || 0;
    if (max <= 0) {
        return 'Off';
    }
    const first = Number(minutesValue) > 0 ? Number(minutesValue) : SUGGESTED_MINUTES;
    const waits = [];
    for (let i = 0; i < Math.min(max, 4); i++) {
        waits.push(Math.min(first * 2 ** i, 10080));
    }
    return `${max} ${max === 1 ? 'retry' : 'retries'} · after ${waits.join(', ')}${max > 4 ? ', …' : ''} min`;
}

function row(key, label, value, extra) {
    return { key, label, value: blank(value) ? '—' : String(value), cls: 'kv-row' + (extra && extra.mono ? ' kv-mono' : '') };
}

/**
 * Guided create / edit / view of an Integration Event or Integration Connection.
 * mode 'new' or 'edit': a stepper (Event: Basics, What to send, Reply & callback, Check & save; Connection: Basics,
 * Endpoint & headers, Inbound user & check) with only the fields that apply and their help, a side summary, the
 * problems the validation rules would raise, and Save (a new record is saved inactive). Fires save { recordId } and
 * cancel. mode 'view' (the default on a record page): a read-only summary in numbered cards; admins get Edit.
 */
export default class IhSetupEditor extends NavigationMixin(LightningElement) {
    /** IH_Event__c or IH_Connection__c (set by the record page; required for a new record). */
    @api objectApiName;

    _recordId;
    _mode;
    connected = false;

    loading = true;
    loadError;
    setup;
    values = {};
    original = {};
    step = 0;
    saving = false;
    stepErrors = {};
    headersValid = true;

    objectOpts = [];
    relatedTyped = false;
    classOpts = { payload: [], response: [], inbound: [], auth: [] };
    credentialOpts = [];
    credentialsLoaded = false;
    fieldOpts = [];
    fieldsLoading = false;
    fieldsError;
    fieldsFor;
    fieldsTimer;
    accessText;
    accessFor;

    objectInfo;
    connectionRecord;
    userRecord;
    pageDefaults;

    checking = false;
    checkResult;

    /** The record; blank for a new one. */
    @api
    get recordId() {
        return this._recordId;
    }
    set recordId(value) {
        const changed = value !== this._recordId;
        this._recordId = value;
        if (changed && this.connected) {
            this.load();
        }
    }

    /** 'new', 'edit' or 'view'. Default: 'view' when there is a record, otherwise 'new'. */
    @api
    get mode() {
        return this.effectiveMode;
    }
    set mode(value) {
        const changed = value !== this._mode;
        this._mode = value;
        if (changed && this.connected) {
            this.load();
        }
    }

    get effectiveMode() {
        const m = text(this._mode).toLowerCase();
        if (!this._recordId || m === 'new') {
            return 'new';
        }
        return m === 'edit' ? 'edit' : 'view';
    }

    connectedCallback() {
        this.connected = true;
        this.load();
    }

    disconnectedCallback() {
        this.connected = false;
        clearTimeout(this.fieldsTimer);
    }

    /* ------------------------------------------------------------------ wires */

    /* New event from a connection: the Connection comes in the page state (defaultFieldValues). */
    @wire(CurrentPageReference)
    wiredPageRef(ref) {
        const encoded = ref && ref.state ? ref.state.defaultFieldValues : null;
        let defaults = null;
        if (encoded) {
            try {
                defaults = decodeDefaultFieldValues(encoded);
            } catch (e) {
                defaults = null;
            }
        }
        this.pageDefaults = defaults;
        if (defaults && this.setup && this.isNew) {
            this.values = { ...this.values, ...this.allowedDefaults(defaults) };
            this.loadFieldsSoon(0);
        }
    }

    /* Label, API name and Id key prefix of the Related Object, for any standard or custom object. */
    @wire(getObjectInfo, { objectApiName: '$relatedApi' })
    wiredObjectInfo({ data, error }) {
        if (data) {
            this.objectInfo = data;
        } else if (error) {
            this.objectInfo = undefined;
        }
    }

    @wire(getRecord, { recordId: '$connectionId', optionalFields: [CONNECTION_NAME, CONNECTION_CREDENTIAL] })
    wiredConnection({ data }) {
        this.connectionRecord = data
            ? { id: data.id, name: getFieldValue(data, CONNECTION_NAME), credential: getFieldValue(data, CONNECTION_CREDENTIAL) }
            : undefined;
    }

    @wire(getRecord, { recordId: '$inboundUserId', optionalFields: [USER_NAME] })
    wiredUser({ data }) {
        this.userRecord = data ? { id: data.id, name: data.fields.Name ? data.fields.Name.value : null } : undefined;
    }

    get relatedApi() {
        return this.isEvent && this.isOutbound && !blank(this.values.Related_Object__c) ? text(this.values.Related_Object__c) : undefined;
    }

    get connectionId() {
        return this.isEvent && !blank(this.values.Connection__c) ? this.values.Connection__c : undefined;
    }

    get inboundUserId() {
        return this.isConnection && !blank(this.values.Inbound_User__c) ? this.values.Inbound_User__c : undefined;
    }

    /* ------------------------------------------------------------------ loading */

    async load() {
        this.loading = true;
        this.loadError = undefined;
        this.stepErrors = {};
        this.checkResult = undefined;
        try {
            const s = await getSetup({ objectApiName: this.objectApiName || null, recordId: this.isNew ? null : this._recordId });
            this.setup = s;
            this.values = this.isNew ? this.newValues(s) : { ...s.values };
            this.original = { ...this.values };
            this.step = 0;
            this.headersValid = true;
            this.accessText = s.userAccess;
            this.accessFor = this.isConnection ? this.values.Inbound_User__c : undefined;
            if (this.canEdit) {
                this.loadPickers();
            }
        } catch (e) {
            this.setup = undefined;
            this.loadError = errorMessage(e, 'The setup could not be loaded.');
        } finally {
            this.loading = false;
        }
    }

    newValues(s) {
        const vals = {};
        (s.fields || []).forEach((fi) => {
            if (fi.defaultValue !== null && fi.defaultValue !== undefined) {
                vals[fi.apiName] = fi.dataType === 'BOOLEAN' ? fi.defaultValue === 'true' : fi.defaultValue;
            }
        });
        vals.Active__c = false;
        return { ...vals, ...this.allowedDefaults(this.pageDefaults) };
    }

    allowedDefaults(defaults) {
        const out = {};
        if (!defaults || !this.setup) {
            return out;
        }
        const allowed = new Set((this.setup.fields || []).map((fi) => fi.apiName));
        Object.keys(defaults).forEach((k) => {
            if (allowed.has(k) && k !== 'Active__c') {
                out[k] = defaults[k];
            }
        });
        return out;
    }

    loadPickers() {
        if (this.isEvent) {
            objectOptions()
                .then((r) => {
                    this.objectOpts = r || [];
                })
                .catch(() => {
                    this.objectOpts = [];
                });
            Promise.all(['payload', 'response', 'inbound'].map((kind) => classOptions({ kind })
                .then((r) => [kind, (r || []).filter((o) => !TEST_NAME.test(o.value))])
                .catch(() => [kind, []])))
                .then((pairs) => {
                    const opts = {};
                    pairs.forEach(([kind, list]) => {
                        opts[kind] = list;
                    });
                    this.classOpts = opts;
                });
            this.loadFieldsSoon(0);
        } else {
            classOptions({ kind: 'auth' })
                .then((r) => {
                    this.classOpts = { ...this.classOpts, auth: (r || []).filter((o) => !TEST_NAME.test(o.value)) };
                })
                .catch(() => {
                    this.classOpts = { ...this.classOpts, auth: [] };
                });
            namedCredentials()
                .then((r) => {
                    this.credentialOpts = r || [];
                })
                .catch(() => {
                    this.credentialOpts = [];
                })
                .finally(() => {
                    this.credentialsLoaded = true;
                });
        }
    }

    loadFieldsSoon(delay) {
        clearTimeout(this.fieldsTimer);
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this.fieldsTimer = setTimeout(() => this.loadFields(), delay);
    }

    async loadFields() {
        const objectName = this.relatedApi;
        if (!this.canEdit || !objectName) {
            this.fieldOpts = [];
            this.fieldsError = undefined;
            this.fieldsFor = undefined;
            return;
        }
        if (sameText(objectName, this.fieldsFor) && !this.fieldsError) {
            return;
        }
        this.fieldsFor = objectName;
        this.fieldsLoading = true;
        this.fieldsError = undefined;
        try {
            const r = await fieldOptions({ objectApiName: objectName });
            if (sameText(objectName, this.relatedApi)) {
                this.fieldOpts = r || [];
            }
        } catch (e) {
            if (sameText(objectName, this.relatedApi)) {
                this.fieldOpts = [];
                this.fieldsError = errorMessage(e, 'The fields could not be loaded.');
            }
        } finally {
            this.fieldsLoading = false;
        }
    }

    async loadAccess(userId) {
        this.accessFor = userId;
        if (!userId) {
            this.accessText = null;
            return;
        }
        try {
            const r = await userAccess({ userId });
            if (this.accessFor === userId) {
                this.accessText = r;
            }
        } catch (e) {
            this.accessText = null;
        }
    }

    /* ------------------------------------------------------------------ state */

    get isEvent() {
        return Boolean(this.setup) && this.setup.objectApiName === EVENT;
    }

    get isConnection() {
        return Boolean(this.setup) && this.setup.objectApiName === CONNECTION;
    }

    get isNew() {
        return this.effectiveMode === 'new';
    }

    get isAdmin() {
        return Boolean(this.setup && this.setup.isAdmin);
    }

    get canEdit() {
        return this.isAdmin && this.effectiveMode !== 'view';
    }

    get showEditor() {
        return Boolean(this.setup) && this.canEdit;
    }

    get showView() {
        return Boolean(this.setup) && !this.canEdit && !this.isNew;
    }

    get showNoAccess() {
        return Boolean(this.setup) && !this.isAdmin && this.isNew;
    }

    get notAdminInEdit() {
        return !this.isAdmin && this.effectiveMode === 'edit';
    }

    get isOutbound() {
        return text(this.values.Direction__c || OUTBOUND) !== INBOUND;
    }

    get isInbound() {
        return !this.isOutbound;
    }

    get savedId() {
        return this.isNew ? null : this._recordId;
    }

    get objectLabel() {
        return this.isEvent ? 'Integration Event' : 'Integration Connection';
    }

    get editorTitle() {
        if (this.isNew) {
            return 'New ' + this.objectLabel;
        }
        const name = text(this.original.Name);
        return 'Edit ' + this.objectLabel + (name ? ' · ' + name : '');
    }

    /* ------------------------------------------------------------------ fields */

    get infoByApi() {
        const map = {};
        ((this.setup && this.setup.fields) || []).forEach((fi) => {
            map[fi.apiName] = fi;
        });
        return map;
    }

    /** Label, help, required flag and picklist values of every field, by API name, for the template. */
    get f() {
        const out = {};
        const infos = this.infoByApi;
        this.knownFields.forEach((api) => {
            const fi = infos[api] || { label: api, help: '', required: false, options: [] };
            out[api] = {
                label: fi.label,
                help: fi.help || '',
                required: Boolean(fi.required) || this.requiredHere(api),
                options: (fi.options || []).map((o) => ({ label: o.label, value: o.value }))
            };
        });
        return out;
    }

    /** Every field the template names, whether or not the org describes it. */
    get knownFields() {
        return Object.keys(this.isEvent ? EVENT_STEP_OF : CONNECTION_STEP_OF);
    }

    requiredHere(api) {
        const v = this.values;
        switch (api) {
            case 'Connection__c':
            case 'Path__c':
            case 'Named_Credential__c':
                return true;
            case 'Related_Object__c':
                return this.isOutbound;
            case 'Payload_Class__c':
                return v.Payload_Source__c === APEX_CLASS;
            case 'Handler_Class__c':
                return this.isInbound;
            case 'Response_Handler_Class__c':
                return bool(v.Business_Data_In_Response__c);
            case 'Auth_Class__c':
                return this.isApexAuth;
            default:
                return false;
        }
    }

    /** Whether a field applies to the record as it is now (inbound / outbound, payload source, callback). */
    applies(api) {
        if (!this.isEvent) {
            return api !== 'Auth_Class__c' || this.isApexAuth;
        }
        if (api === 'Active__c') {
            return !this.isNew;
        }
        if (api === 'Handler_Class__c') {
            return this.isInbound;
        }
        if (OUTBOUND_ONLY.includes(api) && this.isInbound) {
            return false;
        }
        if (api === 'Payload_Fields__c') {
            return this.values.Payload_Source__c !== APEX_CLASS;
        }
        if (api === 'Payload_Class__c') {
            return this.values.Payload_Source__c === APEX_CLASS;
        }
        if (api === 'Callback_Timeout_Hours__c') {
            return bool(this.values.Expects_Callback__c);
        }
        return true;
    }

    get show() {
        const out = {};
        const infos = this.infoByApi;
        this.knownFields.forEach((api) => {
            out[api] = Boolean(infos[api]) && this.applies(api);
        });
        return out;
    }

    /** Checkbox values as booleans. */
    get flags() {
        const v = this.values;
        return {
            Active__c: bool(v.Active__c),
            Share_With_Related_Record__c: bool(v.Share_With_Related_Record__c),
            Expects_Callback__c: bool(v.Expects_Callback__c),
            Business_Data_In_Response__c: bool(v.Business_Data_In_Response__c)
        };
    }

    get directionOptions() {
        const fi = this.infoByApi.Direction__c;
        return fi ? fi.options.map((o) => ({ label: o.label, value: o.value })) : [];
    }

    /* ------------------------------------------------------------------ pickers */

    get relatedObjectOptions() {
        const opts = this.objectOpts.map((o) => ({ label: o.label, value: o.value, description: o.detail }));
        const current = text(this.values.Related_Object__c);
        if (current && !opts.some((o) => sameText(o.value, current))) {
            opts.unshift({ label: current, value: current, description: this.relatedLine });
        }
        return opts;
    }

    /** The Related Object value as the list spells it, so the combobox shows it as chosen. */
    get relatedComboValue() {
        const current = text(this.values.Related_Object__c);
        const found = this.objectOpts.find((o) => sameText(o.value, current));
        return found ? found.value : current;
    }

    get useRelatedCombo() {
        return this.objectOpts.length > 0 && !this.relatedTyped;
    }

    get relatedToggleLabel() {
        return this.relatedTyped ? 'Pick from the list' : 'Type the API name';
    }

    get showRelatedToggle() {
        return this.objectOpts.length > 0;
    }

    /** e.g. "Voucher · API name Voucher__c · Id prefix a0X". */
    get relatedLine() {
        const api = text(this.values.Related_Object__c);
        if (!api) {
            return '';
        }
        const info = this.objectInfo;
        if (info && sameText(info.apiName, api)) {
            return `${info.label} · API name ${info.apiName}` + (info.keyPrefix ? ` · Id prefix ${info.keyPrefix}` : '');
        }
        const listed = this.objectOpts.find((o) => sameText(o.value, api));
        if (listed) {
            return `${listed.label} · ${listed.detail}`;
        }
        const saved = this.setup && this.setup.relatedObject;
        if (saved && sameText(saved.value, api)) {
            return `${saved.label} · ${saved.detail}`;
        }
        return `${api} · API name ${api}`;
    }

    get relatedLabel() {
        const api = text(this.values.Related_Object__c);
        const info = this.objectInfo;
        if (info && sameText(info.apiName, api)) {
            return info.label;
        }
        const listed = this.objectOpts.find((o) => sameText(o.value, api));
        return listed ? listed.label : api;
    }

    classComboOptions(kind, api, optional) {
        const current = text(this.values[api]);
        const opts = (this.classOpts[kind] || []).map((o) => ({ label: o.label, value: o.value }));
        if (current && !opts.some((o) => o.value === current)) {
            opts.unshift({ label: current, value: current, description: 'Not among the classes found for this interface' });
        }
        if (optional) {
            opts.unshift({ label: 'None', value: '' });
        }
        return opts;
    }

    get payloadClassOptions() {
        return this.classComboOptions('payload', 'Payload_Class__c', false);
    }

    get responseClassOptions() {
        return this.classComboOptions('response', 'Response_Handler_Class__c', true);
    }

    get inboundClassOptions() {
        return this.classComboOptions('inbound', 'Handler_Class__c', false);
    }

    get hasPayloadClasses() {
        return this.classOpts.payload.length > 0;
    }

    get hasResponseClasses() {
        return this.classOpts.response.length > 0;
    }

    get hasInboundClasses() {
        return this.classOpts.inbound.length > 0;
    }

    get authClassOptions() {
        return this.classComboOptions('auth', 'Auth_Class__c', false);
    }

    get hasAuthClasses() {
        return this.classOpts.auth.length > 0;
    }

    /* ------------------------------------------------------------------ connection type and auto-retry */

    /** Connection: the Auth Class logs in (Apex Auth). Blank is Named Credential. */
    get isApexAuth() {
        return this.isConnection && this.values.Connection_Type__c === APEX_AUTH;
    }

    get connectionTypeValue() {
        return text(this.values.Connection_Type__c) || NAMED_CREDENTIAL;
    }

    get connectionTypeOptions() {
        const fi = this.infoByApi.Connection_Type__c;
        const opts = fi && fi.options && fi.options.length ? fi.options : [{ label: NAMED_CREDENTIAL, value: NAMED_CREDENTIAL }, { label: APEX_AUTH, value: APEX_AUTH }];
        return opts.map((o) => ({
            label: o.value === APEX_AUTH ? 'Apex Auth: my Auth Class adds the login (custom token login)'
                : 'Named Credential: Salesforce logs in (OAuth, JWT, API key, Basic, AWS, certificate)',
            value: o.value
        }));
    }

    get connectionTypeLine() {
        return this.isApexAuth ? `Apex Auth · ${text(this.values.Auth_Class__c) || 'Auth Class not set'}` : NAMED_CREDENTIAL;
    }

    get autoRetryText() {
        return autoRetrySummary(this.values.Auto_Retry_Max__c, this.values.Retry_After_Minutes__c);
    }

    get showRetrySuggestion() {
        return !(Number(this.values.Auto_Retry_Max__c) > 0);
    }

    handleSuggestRetry() {
        this.setValue('Auto_Retry_Max__c', SUGGESTED_RETRIES);
        this.setValue('Retry_After_Minutes__c', SUGGESTED_MINUTES);
    }

    get credentialOptions() {
        const opts = this.credentialOpts.map((o) => ({
            label: o.value,
            value: o.value,
            description: [o.label, o.detail].filter((x) => !blank(x)).join(' · ')
        }));
        const current = text(this.values.Named_Credential__c);
        if (current && !opts.some((o) => sameText(o.value, current))) {
            opts.unshift({ label: current, value: current, description: 'Not found in this org' });
        }
        return opts;
    }

    get hasCredentials() {
        return this.credentialOpts.length > 0;
    }

    get credentialFound() {
        const current = text(this.values.Named_Credential__c);
        if (!current) {
            return null;
        }
        if (!this.credentialsLoaded) {
            return sameText(current, this.original.Named_Credential__c) && this.setup ? this.setup.credentialExists : null;
        }
        return this.credentialOpts.some((o) => sameText(o.value, current));
    }

    get userFilter() {
        return { criteria: [{ fieldPath: 'IsActive', operator: 'eq', value: true }] };
    }

    get fieldPickerLabel() {
        return this.relatedLabel || 'object';
    }

    /* ------------------------------------------------------------------ names */

    get connectionName() {
        const id = this.values.Connection__c;
        if (blank(id)) {
            return '';
        }
        if (this.connectionRecord && this.connectionRecord.id === id) {
            return this.connectionRecord.name;
        }
        return sameText(id, this.original.Connection__c) && this.setup ? this.setup.names.Connection__c || '' : '';
    }

    get connectionCredential() {
        const id = this.values.Connection__c;
        if (this.connectionRecord && this.connectionRecord.id === id) {
            return this.connectionRecord.credential;
        }
        return sameText(id, this.original.Connection__c) && this.setup ? this.setup.credential : null;
    }

    get inboundUserName() {
        const id = this.values.Inbound_User__c;
        if (blank(id)) {
            return '';
        }
        if (this.userRecord && this.userRecord.id === id) {
            return this.userRecord.name;
        }
        return sameText(id, this.original.Inbound_User__c) && this.setup ? this.setup.names.Inbound_User__c || '' : '';
    }

    /* ------------------------------------------------------------------ derived text */

    get payloadPaths() {
        return splitPaths(this.values.Payload_Fields__c);
    }

    get sendsText() {
        const method = text(this.values.Http_Method__c) || 'POST';
        const credential = text(this.connectionCredential);
        const path = text(this.values.Path__c);
        return `${method} ${credential ? 'callout:' + credential : '…'}${path}`;
    }

    get inboundCallUrl() {
        return INBOUND_URL + (text(this.values.Event_Key__c) || '{EVENT_KEY}');
    }

    get pathTokensBad() {
        const found = [];
        const re = /\{([^}]*)\}/g;
        let m = re.exec(text(this.values.Path__c));
        while (m) {
            if (!PATH_TOKENS.includes(m[1])) {
                found.push('{' + m[1] + '}');
            }
            m = re.exec(text(this.values.Path__c));
        }
        return found;
    }

    get pathState() {
        const path = text(this.values.Path__c);
        if (!path) {
            return null;
        }
        if (!path.startsWith('/')) {
            return { ok: false, text: 'Start the Path with /' };
        }
        if (/\s/.test(path)) {
            return { ok: false, text: 'The Path has a space' };
        }
        const bad = this.pathTokensBad;
        if (bad.length) {
            return { ok: false, text: 'Unknown token ' + bad.join(', ') };
        }
        return { ok: true, text: '✓ Path looks valid' };
    }

    get pathStateClass() {
        return 'ih-small path-state ' + (this.pathState && this.pathState.ok ? 'path-state_ok' : 'path-state_bad');
    }

    get pathPlaceholder() {
        return '/api/v1/voucher/{recordId}';
    }

    get pathHint() {
        const credential = text(this.connectionCredential);
        return `Added to the connection's URL${credential ? ' (callout:' + credential + ')' : ''}. Tokens: {recordId} {transactionId}.`;
    }

    get headerRows() {
        const parsed = parseHeaders(this.values.Headers__c);
        return parsed.error ? null : parsed.rows;
    }

    get headersText() {
        const rows = this.headerRows;
        if (rows === null) {
            return 'Not valid JSON';
        }
        return rows.map((r) => (isMergeField(r.value) ? r.name : `${r.name}: ${r.value}`)).join(' · ');
    }

    get headerCount() {
        const rows = this.headerRows;
        return rows === null ? 'Not valid JSON' : String(rows.length);
    }

    get accessLine() {
        if (blank(this.values.Inbound_User__c)) {
            return '';
        }
        return this.accessText ? '✓ ' + this.accessText : 'No Integration Hub permission set: give Integration Hub Read';
    }

    get accessClass() {
        return 'ih-small ' + (this.accessText ? 'ih-ok-text' : 'ih-bad-text');
    }

    get eventsLine() {
        if (!this.setup || this.isNew) {
            return '';
        }
        return `${this.setup.eventCount} (${this.setup.inboundCount} inbound)`;
    }

    /* ------------------------------------------------------------------ stepper */

    get steps() {
        return this.isEvent ? EVENT_STEPS : CONNECTION_STEPS;
    }

    get lastStep() {
        return this.steps.length - 1;
    }

    get stepItems() {
        return this.steps.map((label, i) => {
            const done = i < this.step;
            const current = i === this.step;
            const bad = Boolean(this.stepErrors[i]) || this.problems.some((p) => p.isError && p.step === i && i < this.step);
            return {
                key: 'step-' + i,
                index: i,
                number: String(i + 1),
                label,
                showCheck: done && !bad,
                showNumber: !done || bad,
                cls: 'step' + (current ? ' step_on' : '') + (done ? ' step_done' : '') + (bad ? ' step_bad' : ''),
                ariaCurrent: current ? 'step' : null,
                showLine: i < this.steps.length - 1,
                lineCls: 'step-line' + (done ? ' step-line_done' : '')
            };
        });
    }

    /** Which event step is shown. */
    get ev() {
        const on = this.isEvent;
        return { s0: on && this.step === 0, s1: on && this.step === 1, s2: on && this.step === 2, s3: on && this.step === 3 };
    }

    /** Which connection step is shown. */
    get cn() {
        const on = this.isConnection;
        return { s0: on && this.step === 0, s1: on && this.step === 1, s2: on && this.step === 2 };
    }

    get isFirstStep() {
        return this.step === 0;
    }

    get isLastStep() {
        return this.step === this.lastStep;
    }

    get notLastStep() {
        return !this.isLastStep;
    }

    get currentStepErrors() {
        const msg = this.stepErrors[this.step];
        return msg ? msg.split('\n').map((line, i) => ({ key: 'e' + i, text: line })) : null;
    }

    handleStep(event) {
        this.step = Number(event.currentTarget.dataset.index);
    }

    handleNext() {
        this.step = Math.min(this.step + 1, this.lastStep);
    }

    handlePrevious() {
        this.step = Math.max(this.step - 1, 0);
    }

    /* ------------------------------------------------------------------ problems (mirror the validation rules) */

    problem(list, step, level, message) {
        list.push({ step, level, text: message });
    }

    eventProblems() {
        const v = this.values;
        const list = [];
        const active = bool(v.Active__c);
        const later = active ? 'error' : 'warn';
        const suffix = active ? '' : ' (needed before activating)';
        if (blank(v.Name)) {
            this.problem(list, 0, 'error', 'Enter the Event Name.');
        }
        if (blank(v.Event_Key__c)) {
            this.problem(list, 0, 'error', 'Enter the Event Key.');
        } else if (!KEY_FORMAT.test(text(v.Event_Key__c))) {
            this.problem(list, 0, 'error', 'Event Key: capital letters, digits and underscores, starting with a letter.');
        }
        if (blank(v.Connection__c)) {
            this.problem(list, 0, later, 'An active event needs a Connection' + suffix + '.');
        }
        if (this.isOutbound) {
            this.outboundProblems(list, later, suffix);
        } else if (blank(v.Handler_Class__c)) {
            this.problem(list, 1, later, 'An active inbound event needs a Handler Class' + suffix + '.');
        }
        if (bool(v.Business_Data_In_Response__c) && blank(v.Response_Handler_Class__c)) {
            this.problem(list, 2, 'error', 'Enter the Response Handler Class when Business Data In Response is checked.');
        }
        if (!blank(v.Retention_Days__c) && !(Number(v.Retention_Days__c) >= 0)) {
            this.problem(list, 2, 'error', 'Retention (days): enter a number of days, or leave it blank.');
        }
        return list;
    }

    outboundProblems(list, later, suffix) {
        const v = this.values;
        if (blank(v.Related_Object__c)) {
            this.problem(list, 0, later, 'An active outbound event needs a Related Object' + suffix + '.');
        }
        if (blank(v.Path__c)) {
            this.problem(list, 1, later, 'Enter the Path (for example /api/v1/voucher)' + suffix + '.');
        } else if (this.pathState && !this.pathState.ok) {
            this.problem(list, 1, 'warn', 'Path: ' + this.pathState.text + '.');
        }
        if (v.Payload_Source__c === APEX_CLASS && blank(v.Payload_Class__c)) {
            this.problem(list, 1, 'error', 'Enter the Payload Class when Payload Source is Apex Class.');
        }
        if (v.Payload_Source__c !== APEX_CLASS && this.payloadPaths.length === 0) {
            this.problem(list, 1, 'warn', 'No Payload Fields: only the transaction Id, event, record Id and object are sent.');
        }
        if (bool(v.Expects_Callback__c) && !(Number(v.Callback_Timeout_Hours__c) > 0)) {
            this.problem(list, 2, 'warn', 'Callback Timeout (hours): blank or 0 means a Sent transaction never times out.');
        }
        const credential = text(this.connectionCredential);
        if (credential && sameText(v.Connection__c, this.original.Connection__c) && this.setup && !this.setup.credentialExists) {
            this.problem(list, 0, 'warn', `The connection's Named Credential ${credential} is not in this org.`);
        }
        if (!wholeIn(v.Auto_Retry_Max__c, 0, 10) || !wholeIn(v.Retry_After_Minutes__c, 1, 1440)) {
            this.problem(list, 2, 'error', 'Auto Retry Max must be 0 to 10, and Retry After (minutes) 1 to 1440.');
        }
    }

    connectionProblems() {
        const v = this.values;
        const list = [];
        if (blank(v.Name)) {
            this.problem(list, 0, 'error', 'Enter the Connection Name.');
        }
        if (this.isApexAuth && blank(v.Auth_Class__c)) {
            this.problem(list, 1, 'error', 'Enter the Auth Class when Connection Type is Apex Auth.');
        }
        if (blank(v.Named_Credential__c)) {
            this.problem(list, 1, 'warn', 'Enter the Named Credential: nothing can be sent without it.');
        } else if (this.credentialFound === false) {
            this.problem(list, 1, 'warn', `Named Credential ${text(v.Named_Credential__c)} is not in this org.`);
        }
        if (!blank(v.Timeout_Seconds__c)) {
            const t = Number(v.Timeout_Seconds__c);
            if (!(t >= 1 && t <= 120)) {
                this.problem(list, 1, 'error', 'Timeout must be between 1 and 120 seconds.');
            }
        }
        if (!this.headersValid || this.headerRows === null) {
            this.problem(list, 1, 'error', 'Headers must be a JSON object, e.g. {"x-api-version":"2"}.');
        }
        if (blank(v.Inbound_User__c)) {
            this.problem(list, 2, 'warn', 'No Inbound User: inbound events and the callback are refused.');
        } else if (!this.accessText) {
            this.problem(list, 2, 'warn', 'The Inbound User has no Integration Hub permission set: give Integration Hub Read.');
        }
        return list;
    }

    get problems() {
        if (!this.setup) {
            return [];
        }
        const list = this.isEvent ? this.eventProblems() : this.connectionProblems();
        return list.map((p, i) => ({
            ...p,
            key: 'p' + i,
            isError: p.level === 'error',
            stepLabel: this.steps[p.step],
            cls: 'problem problem_' + p.level,
            icon: p.level === 'error' ? 'utility:error' : 'utility:warning'
        }));
    }

    get hasProblems() {
        return this.problems.length > 0;
    }

    get blocking() {
        return this.problems.filter((p) => p.isError);
    }

    get saveDisabled() {
        return this.saving || this.blocking.length > 0;
    }

    get readyText() {
        if (this.blocking.length) {
            return `${this.blocking.length} problem(s) to fix before saving.`;
        }
        return this.hasProblems ? 'Can be saved; the warnings must be fixed before activating.' : 'No problems found.';
    }

    handleProblem(event) {
        this.step = Number(event.currentTarget.dataset.step);
    }

    /* ------------------------------------------------------------------ summary panel */

    get summaryRows() {
        const v = this.values;
        if (this.isEvent) {
            const rows = [
                row('key', 'Event Key', v.Event_Key__c),
                row('dir', 'Direction', v.Direction__c),
                row('conn', 'Connection', this.connectionName)
            ];
            if (this.isOutbound) {
                rows.push(row('obj', 'Object', this.relatedLine));
                rows.push(row('sends', 'Sends', this.sendsText));
                rows.push(row('payload', 'Payload', v.Payload_Source__c === APEX_CLASS
                    ? text(v.Payload_Class__c) || 'Apex class not set' : `${this.payloadPaths.length} fields`));
                rows.push(row('retry', 'Auto-retry', this.autoRetryText));
            } else {
                rows.push(row('calls', 'Called at', this.inboundCallUrl));
                rows.push(row('handler', 'Handler', v.Handler_Class__c));
            }
            rows.push(row('active', 'Active', this.isNew ? 'No (after save)' : yesNo(v.Active__c)));
            return rows;
        }
        const rows = [
            row('name', 'Name', v.Name),
            row('nc', 'Named Credential', v.Named_Credential__c),
            row('type', 'Login', this.connectionTypeLine),
            row('timeout', 'Timeout', blank(v.Timeout_Seconds__c) ? '' : text(v.Timeout_Seconds__c) + ' s'),
            row('headers', 'Headers', this.headerCount),
            row('user', 'Inbound User', this.inboundUserName)
        ];
        if (!this.isNew) {
            rows.push(row('events', 'Events', this.eventsLine));
        }
        rows.push(row('active', 'Active', this.isNew ? 'No (after save)' : yesNo(v.Active__c)));
        return rows;
    }

    get summaryNote() {
        if (this.isEvent) {
            return this.isNew
                ? 'Saved inactive. After the first save, Check endpoint and Preview payload are on the last step.'
                : 'Check endpoint and Preview payload use the saved record: save your changes first.';
        }
        if (!this.isNew && this.setup && this.setup.eventCount > 0) {
            return `Changing the Named Credential affects all ${this.setup.eventCount} events on this connection.`;
        }
        return this.isNew ? 'Saved inactive. Check connection is available after the first save.' : '';
    }

    /* ------------------------------------------------------------------ view mode */

    get viewCards() {
        return this.isEvent ? this.eventCards() : this.connectionCards();
    }

    eventCards() {
        const v = this.values;
        const basics = [
            row('key', 'Event Key', v.Event_Key__c, { mono: true }),
            row('dir', 'Direction', v.Direction__c),
            row('conn', 'Connection', this.connectionName)
        ];
        let send;
        let reply;
        if (this.isOutbound) {
            basics.push(row('obj', 'Related Object', this.relatedLine));
            send = [
                row('sends', 'Sends', this.sendsText, { mono: true }),
                row('src', 'Payload Source', v.Payload_Source__c),
                v.Payload_Source__c === APEX_CLASS
                    ? row('cls', 'Payload Class', v.Payload_Class__c, { mono: true })
                    : row('fields', 'Payload Fields', this.payloadPaths.join(', ') || 'None', { mono: true }),
                row('txkey', 'Transaction Id key', v.Transaction_Id_Key__c, { mono: true })
            ];
            reply = [
                row('rh', 'Response Handler', v.Response_Handler_Class__c, { mono: true }),
                row('bd', 'Business Data In Response', bool(v.Business_Data_In_Response__c) ? 'Yes · runs in background' : 'No'),
                row('cb', 'Expects Callback', bool(v.Expects_Callback__c)
                    ? 'Yes · within ' + (text(v.Callback_Timeout_Hours__c) || '—') + ' h' : 'No'),
                row('retry', 'Auto-retry', this.autoRetryText),
                row('ret', 'Retention (days)', blank(v.Retention_Days__c) ? 'Never deleted' : v.Retention_Days__c)
            ];
        } else {
            send = [
                row('calls', 'Called at', 'POST ' + this.inboundCallUrl, { mono: true }),
                row('handler', 'Handler Class', v.Handler_Class__c, { mono: true })
            ];
            reply = [
                row('answer', 'Answer', 'Salesforce answers at once; no callback'),
                row('ret', 'Retention (days)', blank(v.Retention_Days__c) ? 'Never deleted' : v.Retention_Days__c)
            ];
        }
        basics.push(row('active', 'Active', yesNo(v.Active__c)));
        if (!blank(v.Description__c)) {
            basics.push(row('desc', 'Description', v.Description__c));
        }
        return [
            { key: 'c1', number: '1', title: 'Basics', rows: basics },
            { key: 'c2', number: '2', title: 'What to send', rows: send },
            { key: 'c3', number: '3', title: 'Reply & callback', rows: reply },
            { key: 'c4', number: '4', title: 'Checks', rows: this.eventCheckRows() }
        ];
    }

    eventCheckRows() {
        const v = this.values;
        const rows = [];
        if (this.isOutbound) {
            rows.push(row('path', 'Path', blank(v.Path__c) ? '✕ missing' : '✓ set'));
            let nc = '✕ the connection has none';
            if (!blank(this.setup.credential)) {
                nc = this.setup.credentialExists ? '✓ ' + this.setup.credential + ' exists' : '✕ ' + this.setup.credential + ' not found in this org';
            }
            rows.push(row('nc', 'Named Credential', nc));
        } else {
            rows.push(row('handler', 'Handler Class', blank(v.Handler_Class__c) ? '✕ missing' : '✓ set'));
        }
        if (bool(v.Business_Data_In_Response__c)) {
            rows.push(row('bdh', 'Handler for business data', blank(v.Response_Handler_Class__c) ? '✕ missing' : '✓ set'));
        }
        if (this.checkResult) {
            rows.push(row('last', 'Last Check endpoint', this.checkLine));
        }
        const activationIssues = this.problems.filter((p) => p.isError || p.text.includes('before activating'));
        rows.push(row('ready', 'Ready to activate', activationIssues.length ? 'No · ' + activationIssues[0].text : 'Yes'));
        return rows;
    }

    connectionCards() {
        const v = this.values;
        const basics = [
            row('name', 'Name', v.Name),
            row('desc', 'Description', v.Description__c),
            row('active', 'Active', yesNo(v.Active__c))
        ];
        let ncText = text(v.Named_Credential__c);
        if (ncText) {
            ncText += this.setup.credentialExists ? ' ✓ exists' : ' · not found in this org';
        }
        const endpoint = [
            row('type', 'Connection Type', text(v.Connection_Type__c) || NAMED_CREDENTIAL),
            row('nc', 'Named Credential', ncText),
            row('timeout', 'Timeout', blank(v.Timeout_Seconds__c) ? '' : text(v.Timeout_Seconds__c) + ' s'),
            row('headers', 'Headers', this.headersText || 'None')
        ];
        if (this.isApexAuth) {
            endpoint.splice(2, 0, row('auth', 'Auth Class', v.Auth_Class__c, { mono: true }));
        }
        const inbound = [
            row('user', 'Inbound User', this.inboundUserName || 'None'),
            row('access', 'Permission set', blank(v.Inbound_User__c) ? '' : this.accessLine),
            row('calls', 'Calls us at', INBOUND_URL + '{EVENT_KEY}', { mono: true })
        ];
        return [
            { key: 'c1', number: '1', title: 'Basics', rows: basics },
            { key: 'c2', number: '2', title: 'Endpoint & headers', rows: endpoint },
            { key: 'c3', number: '3', title: 'Inbound user', rows: inbound }
        ];
    }

    get viewBadges() {
        const out = [];
        if (this.isEvent) {
            out.push({ key: 'dir', label: text(this.values.Direction__c) || OUTBOUND, cls: 'ih-tag ' + (this.isOutbound ? 'ih-tag_rest' : 'ih-tag_in') });
        }
        const active = bool(this.values.Active__c);
        out.push({ key: 'active', label: active ? 'Active' : 'Inactive', cls: 'ih-badge ' + (active ? 'ih-badge_on' : 'ih-badge_Abandoned') });
        return out;
    }

    get eventRows() {
        return ((this.setup && this.setup.events) || []).map((e) => ({
            key: e.id,
            id: e.id,
            url: '/' + e.id,
            eventKey: e.eventKey,
            direction: e.direction,
            active: e.active ? 'Yes' : 'No',
            activeCls: 'ih-badge ' + (e.active ? 'ih-badge_on' : 'ih-badge_Abandoned')
        }));
    }

    get hasEventRows() {
        return this.eventRows.length > 0;
    }

    get moreEvents() {
        const n = this.setup ? this.setup.eventCount - this.setup.events.length : 0;
        return n > 0 ? `+ ${n} more` : '';
    }

    get eventsShownTitle() {
        const n = this.setup ? this.setup.eventCount : 0;
        return n > EVENTS_SHOWN ? `Events on this connection (${n})` : 'Events on this connection';
    }

    /* ------------------------------------------------------------------ checks (saved record) */

    get canRunChecks() {
        return this.isAdmin && !this.isNew;
    }

    get showCheckEndpoint() {
        return this.isEvent && this.isOutboundSaved;
    }

    get isOutboundSaved() {
        return text(this.original.Direction__c || OUTBOUND) !== INBOUND;
    }

    get checkGood() {
        const r = this.checkResult;
        return Boolean(r && r.reached && !BAD_CODES.includes(r.statusCode));
    }

    get checkClass() {
        return 'check-result ' + (this.checkGood ? 'ih-callout ih-callout_ok' : 'ih-callout ih-callout_bad');
    }

    get checkIcon() {
        return this.checkGood ? 'utility:success' : 'utility:error';
    }

    get checkLine() {
        const r = this.checkResult;
        if (!r) {
            return '';
        }
        const status = r.statusCode ? ` (HTTP ${r.statusCode})` : '';
        return (this.checkGood ? '✓ Reached' : '✕ ' + (r.reached ? 'Refused' : 'Not reached')) + status;
    }

    get checkTime() {
        return this.checkResult && this.checkResult.millis != null ? `${this.checkResult.millis} ms` : '';
    }

    async handleCheck() {
        this.checking = true;
        this.checkResult = undefined;
        try {
            this.checkResult = this.isEvent
                ? await checkEvent({ eventId: this.savedId })
                : await checkConnection({ connectionId: this.savedId });
        } catch (e) {
            this.checkResult = { reached: false, message: errorMessage(e, 'The check could not run.') };
        } finally {
            this.checking = false;
        }
    }

    async handlePreview() {
        await IhPayloadPreview.open({
            size: 'large',
            label: 'Preview payload',
            eventId: this.savedId,
            eventKey: this.original.Event_Key__c || '',
            direction: this.original.Direction__c,
            relatedObject: this.original.Related_Object__c || ''
        });
    }

    /* ------------------------------------------------------------------ input */

    setValue(api, value) {
        this.values = { ...this.values, [api]: value };
        const stepOf = this.isEvent ? EVENT_STEP_OF : CONNECTION_STEP_OF;
        if (this.stepErrors[stepOf[api]]) {
            this.stepErrors = { ...this.stepErrors, [stepOf[api]]: undefined };
        }
    }

    handleChange(event) {
        const target = event.target;
        const api = target.dataset.field;
        let value;
        if (target.type === 'checkbox' || target.type === 'toggle') {
            value = target.checked;
        } else if (event.detail && Object.prototype.hasOwnProperty.call(event.detail, 'recordId')) {
            value = event.detail.recordId || '';
        } else if (event.detail && event.detail.value !== undefined) {
            value = event.detail.value;
        } else {
            value = target.value;
        }
        this.setValue(api, value);
        if (api === 'Direction__c') {
            this.loadFieldsSoon(0);
        }
    }

    handleRelatedObject(event) {
        this.setValue('Related_Object__c', event.detail.value || '');
        this.loadFieldsSoon(this.useRelatedCombo ? 0 : 500);
    }

    handleRelatedToggle() {
        this.relatedTyped = !this.relatedTyped;
    }

    handleHeaders(event) {
        this.headersValid = event.detail.valid !== false;
        this.setValue('Headers__c', event.detail.value || '');
    }

    handleInboundUser(event) {
        const id = event.detail.recordId || '';
        this.setValue('Inbound_User__c', id);
        this.loadAccess(id);
    }

    /* ------------------------------------------------------------------ save */

    /* New: every value that applies. Edit: the Id and the values changed. */
    saveInput() {
        const input = {};
        const editable = (this.setup.fields || []).map((fi) => fi.apiName);
        editable.forEach((api) => {
            const value = this.values[api];
            if (this.isNew) {
                if (this.applies(api) && !blank(value)) {
                    input[api] = value;
                }
            } else if (String(value ?? '') !== String(this.original[api] ?? '')) {
                input[api] = value === undefined ? null : value;
            }
        });
        if (!this.isNew) {
            input.Id = this._recordId;
        }
        return input;
    }

    stepOfMessage(line) {
        const stepOf = this.isEvent ? EVENT_STEP_OF : CONNECTION_STEP_OF;
        const named = /\(([A-Za-z0-9_]+)\):/.exec(line);
        if (named && stepOf[named[1]] !== undefined) {
            return stepOf[named[1]];
        }
        let best = null;
        let bestLength = 0;
        const lower = line.toLowerCase();
        Object.values(this.infoByApi).forEach((fi) => {
            [fi.label, fi.apiName].forEach((word) => {
                if (word && word.length > bestLength && lower.includes(word.toLowerCase()) && stepOf[fi.apiName] !== undefined) {
                    best = stepOf[fi.apiName];
                    bestLength = word.length;
                }
            });
        });
        return best === null ? this.lastStep : best;
    }

    showSaveError(message) {
        const errors = {};
        message.split('\n').filter((l) => l.trim()).forEach((line) => {
            const s = this.stepOfMessage(line);
            errors[s] = errors[s] ? errors[s] + '\n' + line : line;
        });
        this.stepErrors = errors;
        const first = Object.keys(errors).map(Number).sort((a, b) => a - b)[0];
        this.step = first === undefined ? this.lastStep : first;
    }

    async handleSave() {
        if (this.blocking.length) {
            this.step = this.blocking[0].step;
            return;
        }
        this.saving = true;
        this.stepErrors = {};
        const wasNew = this.isNew;
        try {
            const id = await saveRecord({ objectApiName: this.setup.objectApiName, recordJson: JSON.stringify(this.saveInput()) });
            if (!wasNew) {
                try {
                    await notifyRecordUpdateAvailable([{ recordId: id }]);
                } catch (e) {
                    // the page refreshes on its own next time
                }
            }
            this.dispatchEvent(new ShowToastEvent({
                title: wasNew ? this.objectLabel + ' created' : 'Changes saved',
                message: wasNew ? 'It is saved inactive: switch Active on after the checks.' : '',
                variant: 'success'
            }));
            this.dispatchEvent(new CustomEvent('save', { detail: { recordId: id } }));
            if (wasNew) {
                // Stay usable on its own (app page): carry on editing the saved record.
                this._recordId = id;
                this._mode = 'edit';
            }
            await this.load();
        } catch (e) {
            this.showSaveError(errorMessage(e, 'The record could not be saved.'));
        } finally {
            this.saving = false;
        }
    }

    handleCancel() {
        this.dispatchEvent(new CustomEvent('cancel'));
    }

    /* ------------------------------------------------------------------ navigation */

    handleEdit() {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: { recordId: this._recordId, objectApiName: this.setup.objectApiName, actionName: 'edit' }
        });
    }

    handleOpenEvent(event) {
        event.preventDefault();
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: { recordId: event.currentTarget.dataset.id, objectApiName: EVENT, actionName: 'view' }
        });
    }

    handleNewEvent(event) {
        event.preventDefault();
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: { objectApiName: EVENT, actionName: 'new' },
            state: { defaultFieldValues: encodeDefaultFieldValues({ Connection__c: this._recordId }) }
        });
    }
}