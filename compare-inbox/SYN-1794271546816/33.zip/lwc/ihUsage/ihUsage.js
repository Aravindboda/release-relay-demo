import { LightningElement, api } from 'lwc';
import scan from '@salesforce/apex/IntegrationHubUsage.scan';
import isAdmin from '@salesforce/customPermission/Integration_Hub_Admin';

const FRAMEWORK = 'integrationhub';
const PREFIX = 'ih_';
const FAILED = ['Failed', 'Abandoned'];
const SHORT_LIST = 4;
const ROLES = {
    payload: { label: 'Payload class', family: 'payload' },
    response: { label: 'Response handler', family: 'response' },
    business: { label: 'Response handler · business data', family: 'response' },
    inbound: { label: 'Inbound handler', family: 'inbound' },
    auth: { label: 'Connection auth', family: 'auth' }
};
const INTERFACE_ROLE = [
    ['ipayloadbuilder', 'payload'],
    ['iresponsehandler', 'response'],
    ['iinboundhandler', 'inbound'],
    ['iconnectionauth', 'auth']
];

// One scan per page load: switching between the two topics does not scan again. Scan again replaces it.
let cached = null;

const lower = (s) => String(s || '').trim().toLowerCase();
const outerOf = (name) => lower(name).split('.')[0];
const num = (n) => Number(n || 0).toLocaleString('en-US');
const pct = (n, of) => (of ? ((100 * n) / of).toFixed(1) : '0.0');
const errorText = (e) => (e && e.body && e.body.message) || (e && e.message) || 'The scan failed.';

function when(value) {
    if (!value) {
        return '–';
    }
    try {
        return new Date(value).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
    } catch (e) {
        return String(value);
    }
}

function part(text, cls) {
    return { text: text === undefined || text === null || text === '' ? '–' : String(text), cls: cls || '' };
}

// A table for the template: every cell is a list of parts, so one cell can hold a flagged and a normal value.
function tableOf(key, title, columns, rows, opts) {
    const o = opts || {};
    const mono = o.mono || [];
    return {
        key,
        title,
        note: o.note,
        hasNote: Boolean(o.note),
        empty: o.empty,
        isEmpty: rows.length === 0,
        colspan: columns.length,
        cols: columns.map((c, i) => ({ key: key + 'c' + i, label: c })),
        rows: rows.map((r, ri) => ({
            key: key + 'r' + ri,
            cells: r.map((c, ci) => {
                const parts = Array.isArray(c) ? c : [typeof c === 'object' && c !== null ? c : part(c)];
                return {
                    key: key + 'r' + ri + 'c' + ci,
                    cls: mono.includes(ci) ? 'ih-mono cell' : 'cell',
                    parts: parts.map((p, pi) => ({ key: key + 'r' + ri + 'c' + ci + 'p' + pi, text: p.text, cls: p.cls }))
                };
            })
        }))
    };
}

function namesText(names, showAll) {
    if (!names.length) {
        return '–';
    }
    if (showAll || names.length <= SHORT_LIST) {
        return names.join(', ');
    }
    return names.slice(0, SHORT_LIST).join(', ') + ' … +' + (names.length - SHORT_LIST) + ' more';
}

function roleOfInterface(name) {
    const l = lower(name);
    const hit = INTERFACE_ROLE.find(([suffix]) => l.endsWith(suffix));
    return hit ? hit[1] : null;
}

function runsInOf(role, callback) {
    if (role === 'payload') {
        return 'In the Sender job';
    }
    if (role === 'inbound') {
        return 'In the REST call (sync)';
    }
    if (role === 'business') {
        return 'Business job (Queueable)';
    }
    if (role === 'auth') {
        return 'Sender job, before each send; Check connection';
    }
    return callback ? 'Sender job; callback REST call (sync)' : 'In the Sender job';
}

function asyncPathOf(ev) {
    if (ev.Direction__c !== 'Outbound') {
        return 'none (sync REST)';
    }
    let path = 'Sender job';
    if (ev.Business_Data_In_Response__c && ev.Response_Handler_Class__c) {
        path += ' → Business job';
    }
    return ev.Expects_Callback__c ? path + ' · callback (sync REST)' : path;
}

// Classes named on events (by role) and connections (Auth Class), then implementers of the Integration Hub interfaces
// that nothing names.
function pluginsOf(events, implementers, connections) {
    const byKey = new Map();
    const add = (className, role, ev) => {
        const name = String(className || '').trim();
        if (!name) {
            return;
        }
        const key = lower(name) + '|' + ROLES[role].family;
        let row = byKey.get(key);
        if (!row) {
            row = { className: name, role, events: [], callback: false, unused: !ev };
            byKey.set(key, row);
        }
        if (ev) {
            if (!row.events.includes(ev.Event_Key__c)) {
                row.events.push(ev.Event_Key__c);
            }
            row.role = role === 'business' ? role : row.role;
            row.callback = row.callback || Boolean(ev.Expects_Callback__c);
        }
    };
    events.forEach((ev) => {
        const outbound = ev.Direction__c === 'Outbound';
        if (outbound && ev.Payload_Source__c === 'Apex Class') {
            add(ev.Payload_Class__c, 'payload', ev);
        }
        if (outbound) {
            add(ev.Response_Handler_Class__c, ev.Business_Data_In_Response__c ? 'business' : 'response', ev);
        } else {
            add(ev.Handler_Class__c, 'inbound', ev);
        }
    });
    // An Auth Class is used by its connection: shown as "Connection: <name>" in the Used by column.
    connections.forEach((conn) => {
        if (conn.Connection_Type__c === 'Apex Auth') {
            add(conn.Auth_Class__c, 'auth', { Event_Key__c: 'Connection: ' + conn.Name, Expects_Callback__c: false });
        }
    });
    implementers.forEach((imp) => {
        const role = roleOfInterface(imp.InterfaceName);
        if (role && imp.ClassName && !outerOf(imp.ClassName).startsWith(FRAMEWORK)) {
            add(imp.ClassName, role, null);
        }
    });
    const rows = [...byKey.values()];
    return rows.filter((r) => !r.unused).concat(rows.filter((r) => r.unused));
}

// Groups the raw scan: Integration Hub's own code, the code that sends, the plugged-in classes, events and jobs.
function analyse(data, info) {
    const events = data.events || [];
    const plugins = pluginsOf(events, data.implementers || [], data.connections || []);
    const pluggedOuter = new Set(plugins.map((p) => outerOf(p.className)));
    const isFramework = (name) => {
        const l = lower(name);
        return l.startsWith(FRAMEWORK) || (l.startsWith(PREFIX) && !pluggedOuter.has(l) && !pluggedOuter.has(l.replace(/test$/, '')));
    };
    const code = data.code || [];
    const classes = code.filter((c) => c.kind === 'Class');
    const fw = classes.filter((c) => isFramework(c.name) && !c.isTest);
    const tests = classes.filter((c) => isFramework(c.name) && c.isTest);
    const triggers = code.filter((c) => c.kind === 'Trigger' && lower(c.name).startsWith(PREFIX));
    const sum = (list) => list.reduce((t, c) => t + (c.chars || 0), 0);
    const classByName = new Map(classes.map((c) => [lower(c.name), c]));
    const eventByKey = new Map(events.map((ev) => [lower(ev.Event_Key__c), ev]));

    const senders = code
        .filter((c) => c.publishes && !(c.kind === 'Class' ? isFramework(c.name) : lower(c.name).startsWith(PREFIX)))
        .map((c) => {
            const keys = (c.keys || []).map((k) => {
                const ev = eventByKey.get(lower(k));
                return { key: k, found: Boolean(ev), sends: Boolean(ev && ev.Active__c && ev.Direction__c === 'Outbound') };
            });
            let runs = 'Nothing: no active outbound event with this key';
            if (keys.some((k) => k.sends)) {
                runs = 'Sender job (async, callout)';
            } else if (!keys.length) {
                runs = 'Sender job, when the key it passes is an active outbound event';
            }
            return { kind: c.kind, name: c.name, keys, runs };
        });

    const counted = new Set();
    let pluggedChars = 0;
    plugins.forEach((p) => {
        const outer = outerOf(p.className);
        const cls = classByName.get(outer);
        const test = classes.find((c) => c.isTest && lower(c.name) !== outer
            && (c.mentions || []).some((m) => lower(m) === lower(p.className)));
        p.chars = cls ? cls.chars : null;
        p.testClass = test ? test.name : null;
        p.runsIn = p.unused ? '–' : runsInOf(p.role, p.callback);
        if (cls && !cls.isTest && !outer.startsWith(FRAMEWORK) && !counted.has(outer)) {
            counted.add(outer);
            pluggedChars += cls.chars || 0;
        }
    });

    const txnByEvent = new Map();
    (data.transactions || []).forEach((t) => {
        const agg = txnByEvent.get(t.key) || { calls: 0, failed: 0, lastAt: null };
        agg.calls += t.count || 0;
        agg.failed += FAILED.includes(t.status) ? t.count || 0 : 0;
        agg.lastAt = !agg.lastAt || (t.lastAt && t.lastAt > agg.lastAt) ? t.lastAt : agg.lastAt;
        txnByEvent.set(t.key, agg);
    });

    const classIdByName = new Map((data.jobClasses || []).map((c) => [c.Name, c.Id]));
    const jobs = info.jobs.map((j) => {
        const id = classIdByName.get(j.name);
        const row = { ...j, runs: 0, completed: 0, failed: 0, lastRun: null, lastFailed: false };
        (data.jobs || []).filter((r) => id && r.key && r.key.substring(0, 15) === id.substring(0, 15)).forEach((r) => {
            row.runs += r.count || 0;
            row.completed += r.status === 'Completed' ? r.count || 0 : 0;
            row.failed += r.status === 'Failed' ? r.count || 0 : 0;
            if (r.lastAt && (!row.lastRun || r.lastAt > row.lastRun)) {
                row.lastRun = r.lastAt;
                row.lastFailed = r.status === 'Failed';
            }
        });
        return row;
    });

    const fwChars = sum(fw);
    return {
        limit: data.apexLimit || 6000000,
        fw: fw.map((c) => c.name),
        fwChars,
        tests: tests.map((c) => c.name),
        testChars: sum(tests),
        triggers: triggers.map((c) => c.name),
        triggerChars: sum(triggers),
        objects: data.objects || [],
        senders,
        plugins,
        pluggedChars,
        componentChars: fwChars + pluggedChars,
        events: events.map((ev) => ({ ev, agg: txnByEvent.get(ev.Id) || { calls: 0, failed: 0, lastAt: null } })),
        connections: new Set(events.map((ev) => ev.Connection__c).filter(Boolean)).size,
        jobs,
        jobsRun: jobs.reduce((t, j) => t + j.runs, 0),
        jobsCompleted: jobs.reduce((t, j) => t + j.completed, 0),
        jobsFailed: jobs.reduce((t, j) => t + j.failed, 0)
    };
}

/**
 * Live part of the How To topics "What's implemented & usage" (view = implemented) and "Who uses Integration Hub"
 * (view = who). Scans the org once when one of these topics is opened (admins only); Scan again refreshes it.
 * The static tables of both topics stay in the How To (TOPICS), so the PDF book has them too.
 */
export default class IhUsage extends LightningElement {
    /** implemented or who. */
    @api view = 'implemented';
    /** Static facts from the How To: { jobs, lwc, aura, objects, permissionSets, staticResource }. */
    @api info;

    data;
    model;
    loading = false;
    error;
    showAll = false;

    connectedCallback() {
        if (!this.isAdmin) {
            return;
        }
        if (cached) {
            this.apply(cached);
        } else {
            this.load();
        }
    }

    get isAdmin() {
        return isAdmin;
    }

    get isWho() {
        return this.view === 'who';
    }

    get isImplemented() {
        return !this.isWho;
    }

    get ready() {
        return Boolean(this.model) && !this.error;
    }

    get scannedText() {
        return this.data ? 'Scanned ' + when(this.data.scannedAt) : '';
    }

    get readerNote() {
        return this.isWho
            ? 'The scan of the classes, triggers, events and background jobs that use Integration Hub is for Integration Hub admins.'
            : 'The live numbers (Apex characters, background jobs today) are for Integration Hub admins. The tables below describe every part.';
    }

    get toggleLabel() {
        return this.showAll ? 'Show fewer names' : 'Show all names';
    }

    async load() {
        this.loading = true;
        this.error = undefined;
        try {
            const result = await scan();
            if (result && result.admin) {
                cached = result;
            }
            this.apply(result);
        } catch (e) {
            this.error = errorText(e);
        } finally {
            this.loading = false;
        }
    }

    apply(result) {
        this.data = result;
        if (result && result.admin) {
            this.model = analyse(result, this.staticInfo);
        } else {
            this.model = null;
            this.error = result && result.message;
        }
    }

    get staticInfo() {
        const i = this.info || {};
        return {
            jobs: i.jobs || [],
            lwc: i.lwc || [],
            aura: i.aura || [],
            permissionSets: i.permissionSets || [],
            staticResource: i.staticResource || ''
        };
    }

    handleScan() {
        this.load();
    }

    handleToggle() {
        this.showAll = !this.showAll;
    }

    // ---------- tiles ----------

    meter(n, of) {
        const width = Math.min(100, Math.max(0.5, (100 * n) / (of || 1)));
        return 'width:' + width.toFixed(1) + '%';
    }

    jobsTile(m) {
        return {
            key: 'jobs', label: 'Integration Hub background jobs today', value: num(m.jobsRun),
            lines: [num(m.jobsCompleted) + ' completed', num(m.jobsFailed) + ' failed' + (m.jobsFailed ? ' → Monitor' : '')],
            cls: 'ih-tile tile ' + (m.jobsFailed ? 'ih-tone_warn' : 'ih-tone_good')
        };
    }

    get tiles() {
        return this.rawTiles().map((t) => ({ ...t, lines: t.lines.map((text, i) => ({ key: t.key + 'l' + i, text })) }));
    }

    rawTiles() {
        const m = this.model;
        if (!m) {
            return [];
        }
        if (this.isWho) {
            const used = m.plugins.filter((p) => !p.unused);
            const byRole = (fam) => new Set(used.filter((p) => ROLES[p.role].family === fam).map((p) => lower(p.className))).size;
            const active = m.events.filter((e) => e.ev.Active__c).length;
            return [
                { key: 'ev', label: 'Events using it', value: num(m.events.length), cls: 'ih-tile tile ih-tone_brand',
                    lines: [active + ' active · ' + (m.events.length - active) + ' inactive · ' + m.connections + (m.connections === 1 ? ' connection' : ' connections')] },
                { key: 'pl', label: 'Your classes plugged in', value: num(new Set(used.map((p) => lower(p.className))).size),
                    cls: 'ih-tile tile ih-tone_info',
                    lines: [byRole('payload') + ' payload · ' + byRole('response') + ' response · ' + byRole('inbound') + ' inbound · '
                        + byRole('auth') + ' auth'] },
                { key: 'ch', label: 'Apex code (these components)', value: num(m.componentChars), cls: 'ih-tile tile ih-tone_brand',
                    meter: this.meter(m.componentChars, m.limit), hasMeter: true,
                    lines: [pct(m.componentChars, m.limit) + '% of ' + num(m.limit) + ' characters'] },
                this.jobsTile(m)
            ];
        }
        return [
            { key: 'fw', label: 'Apex code of Integration Hub', value: num(m.fwChars), cls: 'ih-tile tile ih-tone_brand',
                meter: this.meter(m.fwChars, m.limit), hasMeter: true,
                lines: [pct(m.fwChars, m.limit) + '% of ' + num(m.limit) + ' characters · tests not counted'] },
            { key: 'ts', label: 'Test classes', value: num(m.tests.length), cls: 'ih-tile tile ih-tone_info',
                lines: [num(m.testChars) + ' characters · not counted'] },
            this.jobsTile(m)
        ];
    }

    // ---------- tables ----------

    get tables() {
        const m = this.model;
        if (!m) {
            return [];
        }
        return this.isWho ? [this.sendersTable(m), this.pluginsTable(m), this.eventsTable(m)] : [this.componentsTable(m), this.jobsTable(m)];
    }

    get footnote() {
        const m = this.model;
        if (!m) {
            return '';
        }
        if (this.isWho) {
            return 'Apex code of these components only: Integration Hub ' + num(m.fwChars) + ' + your plugged-in classes '
                + num(m.pluggedChars) + ' = ' + num(m.componentChars) + ' characters (' + pct(m.componentChars, m.limit)
                + '% of the ' + num(m.limit) + ' limit). Test classes are not counted. Nothing outside Integration Hub is counted. '
                + 'The scan reads Apex class and trigger code, events, transactions and background jobs; admins only. ' + this.scannedText + '.';
        }
        return 'Only Integration Hub is counted. Apex classes are read live: names starting with IntegrationHub or IH_ '
            + '(an IH_ class plugged into an event counts as your class; see Who uses Integration Hub). ' + this.scannedText + '.';
    }

    componentsTable(m) {
        const s = this.staticInfo;
        const fields = m.objects.reduce((t, o) => t + (o.customFields || 0), 0);
        const rows = [
            ['Apex classes', num(m.fw.length), namesText(m.fw, this.showAll), num(m.fwChars)],
            ['Apex test classes', num(m.tests.length), namesText(m.tests, this.showAll), num(m.testChars) + ' (not counted)'],
            ['Apex trigger', num(m.triggers.length), namesText(m.triggers, true), num(m.triggerChars)],
            ['Lightning web components', num(s.lwc.length), namesText(s.lwc, this.showAll), '–'],
            ['Aura components', num(s.aura.length), s.aura.map((a) => a.name + ' (' + a.note + ')').join(', '), '–'],
            ['Objects · custom fields', m.objects.length + ' · ' + fields,
                m.objects.map((o) => o.name + ' (' + o.customFields + ')').join(', '), '–'],
            ['Permission sets · static resource', s.permissionSets.length + ' · 1',
                s.permissionSets.join(', ') + ' · ' + s.staticResource, '–']
        ];
        return tableOf('comp', 'Components', ['Type', 'Count', 'Names', 'Characters'], rows, { mono: [2] });
    }

    jobsTable(m) {
        const rows = m.jobs.map((j) => [
            j.name, j.type, j.runsWhen, j.callouts,
            [part(num(j.runs)), j.failed ? part(' · ' + num(j.failed) + ' failed', 'flag') : part(' · 0 failed', 'quiet')],
            j.lastRun ? [part(when(j.lastRun)), part(j.lastFailed ? ' failed' : ' ✓', j.lastFailed ? 'flag' : 'ok')] : [part('–')]
        ]);
        return tableOf('jobs', 'Background (async) jobs', ['Class', 'Type', 'Runs when', 'Callouts', 'Today', 'Last run'], rows, {
            mono: [0],
            note: 'From AsyncApexJob, last 24 hours. A failed job\'s transactions are marked Failed by the framework; retry them from the Monitor.'
        });
    }

    sendersTable(m) {
        const rows = m.senders.map((sd) => [
            sd.kind,
            sd.name,
            'IntegrationHub.publish',
            sd.keys.length
                ? sd.keys.map((k, i) => part((i ? ', ' : '') + k.key + (k.found ? '' : ' (no such event)'), k.found ? '' : 'flag'))
                : [part('–')],
            sd.runs
        ]);
        return tableOf('send', '1 · Your code that sends', ['Type', 'Name', 'Calls', 'Event keys found', 'Then runs'], rows, {
            mono: [1, 2],
            empty: 'No class or trigger outside Integration Hub calls IntegrationHub.publish.',
            note: 'Event keys are read from text in the publish calls; a key passed in a variable is not shown.'
        });
    }

    pluginsTable(m) {
        const rows = m.plugins.map((p) => [
            p.className,
            ROLES[p.role].label,
            p.unused ? [part('none', 'flag')] : p.events.join(', '),
            p.runsIn,
            p.testClass ? [part('✓ ' + p.testClass, 'ok')] : [part('none found', 'flag')],
            p.chars === null || p.chars === undefined ? 'not found' : num(p.chars)
        ]);
        return tableOf('plug', '2 · Your classes plugged into events and connections', ['Class', 'Role', 'Used by', 'Runs', 'Test class', 'Characters'],
            rows, { mono: [0], empty: 'No event or connection names a class, and no class of this org implements an Integration Hub interface.' });
    }

    eventsTable(m) {
        const rows = m.events.map(({ ev, agg }) => [
            ev.Active__c ? [part(ev.Event_Key__c)] : [part(ev.Event_Key__c), part(' (inactive)', 'quiet')],
            ev.Direction__c,
            ev.Connection__r ? ev.Connection__r.Name : '–',
            asyncPathOf(ev),
            num(agg.calls),
            [part(num(agg.failed), agg.failed ? 'flag' : '')],
            when(agg.lastAt)
        ]);
        return tableOf('evt', '3 · Events and their async calls (last 24 h)',
            ['Event', 'Direction', 'Connection', 'Async path', 'Calls', 'Failed', 'Last'], rows, {
                mono: [0],
                empty: 'No events yet.',
                note: 'Calls = Integration Transactions created in the last 24 hours; Failed = Failed or Abandoned.'
            });
    }
}