import { LightningElement, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { IsConsoleNavigation, EnclosingTabId } from 'lightning/platformWorkspaceApi';
import getSummary from '@salesforce/apex/IntegrationHubMonitorController.getSummary';
import retryGroup from '@salesforce/apex/IntegrationHubMonitorController.retryGroup';
import { openPage, tabPage, errorMessage } from 'c/ihNav';

const TILES = [
    { key: 'Success', label: 'Success', tone: 'good' },
    { key: 'Sent', label: 'Waiting for callback', tone: 'info' },
    { key: 'Retry', label: 'Retry', tone: 'warn' },
    { key: 'Failed', label: 'Failed', tone: 'bad' },
    { key: 'Abandoned', label: 'Abandoned', tone: 'bad' }
];

const pad = (n) => String(n).padStart(2, '0');
const isoDay = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

/** Monitor tab: totals for a period, failures grouped by event and error, retry a group. Admins only. */
export default class IhMonitor extends NavigationMixin(LightningElement) {
    @wire(IsConsoleNavigation) isConsole;
    @wire(EnclosingTabId) tabId;

    period = '7';
    customDays = 45;
    customFrom = '';
    customTo = '';
    summary;
    error;
    loading = true;
    busy = false;
    confirmKey;

    connected = false;
    pollTimer;
    pollStarted;
    polling = false;

    connectedCallback() {
        this.connected = true;
        document.addEventListener('visibilitychange', this.handleVisibility);
        this.load();
    }

    disconnectedCallback() {
        this.connected = false;
        document.removeEventListener('visibilitychange', this.handleVisibility);
        this.stopPolling();
    }

    // quiet = background refresh: no spinner, keeps whatever is on screen.
    async load(quiet) {
        if (!quiet) {
            this.loading = true;
            this.pollStarted = undefined;
        }
        try {
            const range = this.range();
            if (!range) {
                return;
            }
            this.summary = await getSummary(range);
            this.error = undefined;
        } catch (e) {
            this.error = errorMessage(e, 'Could not load the Monitor.');
        } finally {
            this.loading = false;
            this.schedulePoll();
        }
    }

    /* ---------------- auto-refresh while something is in progress ---------------- */

    pollDelay() {
        if (this.error) {
            return 0;
        }
        // 5 s while transactions are in progress; otherwise every 30 s while the Monitor is open.
        const count = (list) => this.total((c) => list.includes(c.status));
        return count(['Pending', 'Received', 'Retry']) > 0 ? 5000 : 30000;
    }

    schedulePoll() {
        window.clearTimeout(this.pollTimer);
        const delay = this.pollDelay();
        const hidden = document.visibilityState === 'hidden';
        if (!this.pollStarted && delay) {
            this.pollStarted = Date.now();
        }
        const expired = this.pollStarted && Date.now() - this.pollStarted > 30 * 60 * 1000;
        if (!this.connected || !delay || hidden || expired) {
            this.polling = false;
            if (!delay) {
                this.pollStarted = undefined;
            }
            return;
        }
        this.polling = true;
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this.pollTimer = window.setTimeout(() => this.load(true), delay);
    }

    stopPolling() {
        window.clearTimeout(this.pollTimer);
        this.polling = false;
    }

    handleVisibility = () => {
        if (document.visibilityState === 'hidden') {
            this.stopPolling();
        } else if (this.connected) {
            this.load(true);
        }
    };

    get periodOptions() {
        return [
            { label: 'Today', value: '1' },
            { label: 'Last 7 days', value: '7' },
            { label: 'Last 30 days', value: '30' },
            { label: 'Last 90 days', value: '90' },
            { label: 'This year', value: 'year' },
            { label: 'All time', value: 'all' },
            { label: 'Custom (days)', value: 'custom' },
            { label: 'Custom range', value: 'range' }
        ];
    }

    get isCustom() {
        return this.period === 'custom';
    }

    get isRange() {
        return this.period === 'range';
    }

    /** Latest day the date pickers allow: today. */
    get maxDay() {
        return isoDay(new Date());
    }

    // Custom range: '' when valid, otherwise why not (a future day, or From after To).
    rangeProblem() {
        const today = isoDay(new Date());
        if ([this.customFrom, this.customTo].some((d) => d && d > today)) {
            return 'Pick today or an earlier day.';
        }
        return this.customFrom && this.customTo && this.customFrom > this.customTo ? 'From must be on or before To.' : '';
    }

    // { fromDate, toDate } as YYYY-MM-DD (blank = open-ended), or null when the custom range is not valid.
    range() {
        const today = new Date();
        if (this.period === 'all') {
            return { fromDate: null, toDate: null };
        }
        if (this.period === 'range') {
            return this.rangeProblem() ? null : { fromDate: this.customFrom || null, toDate: this.customTo || null };
        }
        if (this.period === 'year') {
            return { fromDate: `${today.getFullYear()}-01-01`, toDate: null };
        }
        const days = this.period === 'custom' ? this.validDays() : Number(this.period);
        if (!days) {
            return null;
        }
        const start = new Date(today.getFullYear(), today.getMonth(), today.getDate() - (days - 1));
        return { fromDate: isoDay(start), toDate: null };
    }

    // Custom (days): a whole number from 1 to 3650, or 0 when not valid.
    validDays() {
        const n = Number(this.customDays);
        return Number.isInteger(n) && n >= 1 && n <= 3650 ? n : 0;
    }

    get rangeError() {
        if (this.isRange) {
            return this.rangeProblem();
        }
        return this.isCustom && !this.validDays() ? 'Enter a whole number of days from 1 to 3,650.' : '';
    }

    // "Since 18 Sep 2026" (or "1 Oct 2026 to 15 Oct 2026") for the chosen period, blank for All time.
    get sinceText() {
        const r = this.range();
        if (!r || (!r.fromDate && !r.toDate)) {
            return '';
        }
        const show = (iso) => {
            const [y, m, d] = iso.split('-').map(Number);
            return new Date(y, m - 1, d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
        };
        if (r.toDate) {
            return (r.fromDate ? show(r.fromDate) : 'Start') + ' to ' + show(r.toDate);
        }
        return 'Since ' + show(r.fromDate);
    }

    handleRange(event) {
        this[event.target.dataset.field] = event.detail.value || '';
        this.confirmKey = undefined;
        if (!this.rangeProblem()) {
            this.load();
        }
    }

    handlePeriod(event) {
        this.period = event.detail.value;
        this.confirmKey = undefined;
        this.load();
    }

    handleDays(event) {
        this.customDays = event.detail.value;
        this.confirmKey = undefined;
        if (this.validDays()) {
            this.load();
        }
    }

    handleRefresh() {
        this.load();
        const cleanup = this.template.querySelector('c-ih-cleanup-status');
        if (cleanup) {
            cleanup.refresh();
        }
    }

    get counts() {
        return (this.summary && this.summary.counts) || [];
    }

    total(filter) {
        return this.counts.filter(filter).reduce((sum, c) => sum + (c.total || 0), 0);
    }

    // A count that reached the server cap is shown as "4,000+".
    shown(filter) {
        const n = this.total(filter);
        const capped = this.counts.some((c) => filter(c) && c.capped);
        return n.toLocaleString() + (capped ? '+' : '');
    }

    get anyCapped() {
        return this.counts.some((c) => c.capped);
    }

    get groupNote() {
        const s = this.summary;
        return s && s.groupsSampled
            ? `Grouped from the latest ${Number(s.groupedFrom).toLocaleString()} failures in this period. Retry group retries every match in the period.`
            : '';
    }

    get tiles() {
        const list = TILES.map((t) => ({
            key: t.key,
            label: t.label,
            value: this.shown((c) => c.status === t.key),
            cls: 'ih-tile ih-tone_' + t.tone
        }));
        list.push({ key: 'out', label: 'Outbound', value: this.shown((c) => c.direction === 'Outbound'), cls: 'ih-tile ih-tone_brand' });
        list.push({ key: 'in', label: 'Inbound', value: this.shown((c) => c.direction === 'Inbound'), cls: 'ih-tile ih-tone_brand' });
        return list;
    }

    get groups() {
        const groups = (this.summary && this.summary.groups) || [];
        return groups.map((g, i) => {
            const key = String(i);
            return {
                ...g,
                key,
                errorText: g.errorSummary || '(no message)',
                confirming: this.confirmKey === key,
                confirmText: `Retry the ${g.eventName} failures of this period with a new payload?`
            };
        });
    }

    get hasGroups() {
        return this.groups.length > 0;
    }

    get noGroups() {
        return !this.loading && !this.error && this.groups.length === 0;
    }

    handleAsk(event) {
        this.confirmKey = event.currentTarget.dataset.key;
    }

    handleCancel() {
        this.confirmKey = undefined;
    }

    async handleRetryGroup(event) {
        const g = this.groups[Number(event.currentTarget.dataset.key)];
        this.busy = true;
        try {
            const range = this.range() || { fromDate: null, toDate: null };
            const n = await retryGroup({ request: { eventName: g.eventName, errorSummary: g.errorSummary, ...range } });
            this.toast('success', `${n} transaction(s) queued for retry with a fresh payload.`);
            this.confirmKey = undefined;
            await this.load();
        } catch (e) {
            this.toast('error', errorMessage(e, 'Retry failed.'));
        } finally {
            this.busy = false;
        }
    }

    handleOpenTransactions() {
        openPage(this, tabPage('IH_Transactions'), { isConsole: this.isConsole, tabId: this.tabId, asWorkspaceTab: true });
    }

    toast(variant, message) {
        this.dispatchEvent(new ShowToastEvent({ title: variant === 'error' ? 'Error' : 'Done', message, variant }));
    }
}