/**
 * Console-aware navigation for Integration Hub components.
 *
 * A component wires IsConsoleNavigation and EnclosingTabId (lightning/platformWorkspaceApi) and passes them in.
 * In a console app the page opens as a subtab of the current workspace tab (or as a new workspace tab when there
 * is none); in a standard app it is ordinary navigation. Works wherever the component is placed.
 */
import { NavigationMixin } from 'lightning/navigation';
import { openTab, openSubtab, getFocusedTabInfo } from 'lightning/platformWorkspaceApi';

export function recordPage(recordId, objectApiName) {
    return {
        type: 'standard__recordPage',
        attributes: { recordId, objectApiName, actionName: 'view' }
    };
}

export function tabPage(apiName) {
    return { type: 'standard__navItemPage', attributes: { apiName } };
}

export function objectListPage(objectApiName) {
    return { type: 'standard__objectPage', attributes: { objectApiName, actionName: 'list' }, state: { filterName: 'Recent' } };
}

export function recordUrl(recordId) {
    return recordId ? '/' + recordId : '#';
}

/**
 * @param cmp           the calling component (must extend NavigationMixin)
 * @param pageReference what to open
 * @param ctx           { isConsole, tabId, label, asWorkspaceTab }
 */
export async function openPage(cmp, pageReference, ctx = {}) {
    if (ctx.isConsole) {
        try {
            if (ctx.asWorkspaceTab) {
                await openTab({ pageReference, focus: true, label: ctx.label });
                return;
            }
            let parent = ctx.tabId;
            if (!parent) {
                const info = await getFocusedTabInfo();
                parent = info ? info.parentTabId || info.tabId : null;
            }
            if (parent) {
                await openSubtab(parent, { pageReference, focus: true, label: ctx.label });
            } else {
                await openTab({ pageReference, focus: true, label: ctx.label });
            }
            return;
        } catch (e) {
            // fall through to standard navigation
        }
    }
    cmp[NavigationMixin.Navigate](pageReference);
}

export function errorMessage(e, fallback) {
    if (!e) {
        return fallback;
    }
    if (e.body) {
        if (Array.isArray(e.body) && e.body.length) {
            return e.body.map((b) => b.message).join(', ');
        }
        if (e.body.message) {
            return e.body.message;
        }
        if (e.body.pageErrors && e.body.pageErrors.length) {
            return e.body.pageErrors[0].message;
        }
    }
    return e.message || fallback;
}

/** CSS class for a subscriber type tag. */
export function typeTag(type) {
    if (type === 'Inbound') {
        return 'ih-tag ih-tag_in';
    }
    if (type === 'Apex Class') {
        return 'ih-tag ih-tag_apex';
    }
    if (type === 'Flow') {
        return 'ih-tag ih-tag_flow';
    }
    if (type === 'Platform Event') {
        return 'ih-tag ih-tag_event';
    }
    return 'ih-tag ih-tag_rest';
}

export function typeLabel(type) {
    if (type === 'Inbound') {
        return 'IN';
    }
    if (type === 'Apex Class') {
        return 'APEX';
    }
    if (type === 'Flow') {
        return 'FLOW';
    }
    return 'REST';
}

/**
 * "Will retry automatically at 10:45 (2 of 3)" for a Failed transaction waiting for auto-retry, or '' when no retry is
 * planned. The time is the viewer's own; a day other than today is added, e.g. "5 Nov, 10:45".
 * @param {string|Date} nextRetryAt Next Retry At
 * @param {number} autoRetries automatic retries already made
 * @param {number} autoRetryMax the event's Auto Retry Max
 */
export function retryLine(nextRetryAt, autoRetries, autoRetryMax) {
    if (!nextRetryAt) {
        return '';
    }
    const at = new Date(nextRetryAt);
    if (Number.isNaN(at.getTime())) {
        return '';
    }
    const time = at.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const sameDay = at.toDateString() === new Date().toDateString();
    const when = sameDay ? time : at.toLocaleDateString([], { day: 'numeric', month: 'short' }) + ', ' + time;
    const n = Number(autoRetries || 0) + 1;
    const max = Number(autoRetryMax || 0);
    return `Will retry automatically at ${when}` + (max ? ` (${n} of ${max})` : '');
}