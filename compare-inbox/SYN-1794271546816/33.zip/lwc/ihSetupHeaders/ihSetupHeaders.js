import { LightningElement, api } from 'lwc';

let nextId = 0;

/**
 * Parses Headers__c: a JSON object of header name to value. Returns { rows } or { error } when the text is not a
 * JSON object (the framework then sends no extra headers).
 */
export function parseHeaders(text) {
    if (!text || !String(text).trim()) {
        return { rows: [] };
    }
    try {
        const parsed = JSON.parse(text);
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
            return { error: 'Headers must be a JSON object, e.g. {"x-api-version":"2"}.' };
        }
        return {
            rows: Object.keys(parsed).map((name) => {
                const v = parsed[name];
                return { name, value: v === null || v === undefined ? '' : typeof v === 'string' ? v : JSON.stringify(v) };
            })
        };
    } catch (e) {
        return { error: 'Headers is not valid JSON: ' + e.message };
    }
}

/** True for a merge field the Named Credential fills in, e.g. {!$Credential.Password}. */
export function isMergeField(value) {
    return /^\s*\{!\$Credential/i.test(value || '');
}

/**
 * Extra headers of a connection (inside ihSetupEditor) as a Header / Value table with "+ Add header". Saved as a
 * JSON object in Headers__c. Text that is not a JSON object is shown as text to fix. Fires change with
 * detail { value, valid }.
 */
export default class IhSetupHeaders extends LightningElement {
    @api disabled = false;

    rows = [];
    raw = false;
    rawText = '';
    rawError;
    lastEmitted;

    @api
    get value() {
        return this.lastEmitted;
    }
    set value(text) {
        if (text === this.lastEmitted && text !== undefined) {
            return;
        }
        this.lastEmitted = text;
        const parsed = parseHeaders(text);
        if (parsed.error) {
            this.raw = true;
            this.rawText = text;
            this.rawError = parsed.error;
            this.rows = [];
        } else {
            this.raw = false;
            this.rawError = undefined;
            this.rows = parsed.rows.map((r) => ({ ...r, id: 'h' + nextId++ }));
        }
    }

    get viewRows() {
        return this.rows.map((r) => ({
            ...r,
            merge: isMergeField(r.value),
            removeLabel: 'Remove header ' + (r.name || '')
        }));
    }

    get noRows() {
        return this.rows.length === 0;
    }

    get duplicates() {
        const seen = new Set();
        const dup = new Set();
        this.rows.forEach((r) => {
            const n = r.name.trim().toLowerCase();
            if (n && seen.has(n)) {
                dup.add(r.name.trim());
            }
            seen.add(n);
        });
        return [...dup].join(', ');
    }

    get example() {
        return '{"x-api-version":"2"}';
    }

    /* The JSON saved: rows with a name, in order. */
    toJson() {
        const obj = {};
        this.rows.forEach((r) => {
            const n = r.name.trim();
            if (n) {
                obj[n] = r.value;
            }
        });
        return Object.keys(obj).length ? JSON.stringify(obj) : '';
    }

    emit(value, valid) {
        this.lastEmitted = value;
        this.dispatchEvent(new CustomEvent('change', { detail: { value, valid } }));
    }

    handleName(event) {
        this.update(event.target.dataset.id, 'name', event.target.value || '');
    }

    handleValue(event) {
        this.update(event.target.dataset.id, 'value', event.target.value || '');
    }

    update(id, key, text) {
        this.rows = this.rows.map((r) => (r.id === id ? { ...r, [key]: text } : r));
        this.emit(this.toJson(), true);
    }

    handleAdd() {
        this.rows = [...this.rows, { id: 'h' + nextId++, name: '', value: '' }];
    }

    handleRemove(event) {
        const id = event.currentTarget.dataset.id;
        this.rows = this.rows.filter((r) => r.id !== id);
        this.emit(this.toJson(), true);
    }

    handleRaw(event) {
        this.rawText = event.target.value || '';
        const parsed = parseHeaders(this.rawText);
        this.rawError = parsed.error;
        this.emit(this.rawText, !parsed.error);
    }

    handleUseTable() {
        const parsed = parseHeaders(this.rawText);
        if (!parsed.error) {
            this.raw = false;
            this.rows = parsed.rows.map((r) => ({ ...r, id: 'h' + nextId++ }));
            this.emit(this.toJson(), true);
        }
    }

    handleClearRaw() {
        this.rawText = '';
        this.rawError = undefined;
        this.raw = false;
        this.rows = [];
        this.emit('', true);
    }
}