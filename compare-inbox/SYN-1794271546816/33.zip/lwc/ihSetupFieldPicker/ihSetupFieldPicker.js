import { LightningElement, api } from 'lwc';

const MAX_ROWS = 200;

/**
 * Splits Payload Fields as IntegrationHubPayloadPaths.split does: commas, semicolons or new lines; trimmed; the
 * first of each path (case-insensitive) is kept.
 */
export function splitPaths(text) {
    const out = [];
    const seen = new Set();
    String(text || '')
        .split(/[,;\n\r]/)
        .map((p) => p.trim())
        .forEach((p) => {
            if (p && !seen.has(p.toLowerCase())) {
                seen.add(p.toLowerCase());
                out.push(p);
            }
        });
    return out;
}

function byLabel(a, b) {
    return a.label.localeCompare(b.label);
}

/**
 * Payload Fields picker (inside ihSetupEditor). Left: the related object's fields and, under each lookup, the parent's
 * fields one level up (Account.Name), with search. Right: the chosen paths as chips, in send order (drag, or
 * Alt+Left/Right, to reorder). Fires change with detail.value = the paths joined by ", ", the format the framework
 * splits. Paths not in the list (typed earlier, deeper lookups) are kept as they are.
 */
export default class IhSetupFieldPicker extends LightningElement {
    /** Field paths from IntegrationHubSetup.fieldOptions: { value, label, parent, parentLabel }. */
    @api options = [];
    /** Label of the related object, e.g. Case. */
    @api objectLabel = '';
    @api loading = false;
    /** A problem loading the fields (unknown object). */
    @api error;
    @api disabled = false;

    selected = [];
    search = '';
    expanded = {};
    dragIndex = null;

    @api
    get value() {
        return this.selected.join(', ');
    }
    set value(text) {
        this.selected = this.canonical(splitPaths(text));
    }

    /* ---------------- lookups ---------------- */

    get optionByLower() {
        const map = new Map();
        (this.options || []).forEach((o) => map.set(o.value.toLowerCase(), o));
        return map;
    }

    canonical(paths) {
        const map = this.optionByLower;
        return paths.map((p) => (map.has(p.toLowerCase()) ? map.get(p.toLowerCase()).value : p));
    }

    get selectedLower() {
        return new Set(this.selected.map((p) => p.toLowerCase()));
    }

    /* ---------------- left list ---------------- */

    get searchPlaceholder() {
        return `Search ${this.objectLabel || 'object'} fields…`;
    }

    get hasOptions() {
        return (this.options || []).length > 0;
    }

    get rows() {
        const chosen = this.selectedLower;
        const field = (o, indent) => ({
            key: 'f-' + o.value,
            value: o.value,
            label: o.label,
            api: o.value,
            isGroup: false,
            isChosen: chosen.has(o.value.toLowerCase()),
            cls: 'row' + (indent ? ' row_child' : '') + (chosen.has(o.value.toLowerCase()) ? ' row_on' : ''),
            ariaPressed: chosen.has(o.value.toLowerCase()) ? 'true' : 'false'
        });
        const term = this.search.trim().toLowerCase();
        const all = this.options || [];
        if (term) {
            return all
                .filter((o) => o.label.toLowerCase().includes(term) || o.value.toLowerCase().includes(term)
                    || (o.parentLabel || '').toLowerCase().includes(term))
                .sort((a, b) => (a.parent ? 1 : 0) - (b.parent ? 1 : 0) || a.value.localeCompare(b.value))
                .slice(0, MAX_ROWS)
                .map((o) => field(o, false));
        }
        const groups = new Map();
        const top = [];
        all.forEach((o) => {
            if (o.parent) {
                if (!groups.has(o.parent)) {
                    groups.set(o.parent, { label: o.parentLabel || o.parent, children: [] });
                    top.push({ group: o.parent, label: o.parentLabel || o.parent });
                }
                groups.get(o.parent).children.push(o);
            } else {
                top.push(o);
            }
        });
        const out = [];
        top.sort(byLabel).forEach((item) => {
            if (!item.group) {
                out.push(field(item, false));
                return;
            }
            const open = Boolean(this.expanded[item.group]);
            out.push({
                key: 'g-' + item.group,
                value: item.group,
                label: item.label,
                api: item.group + '.*',
                isGroup: true,
                cls: 'row row_group' + (open ? ' row_open' : ''),
                icon: open ? 'utility:chevrondown' : 'utility:chevronright',
                ariaExpanded: open ? 'true' : 'false'
            });
            if (open) {
                groups.get(item.group).children.slice().sort(byLabel).forEach((c) => out.push(field(c, true)));
            }
        });
        return out;
    }

    get moreHidden() {
        const term = this.search.trim().toLowerCase();
        if (!term) {
            return false;
        }
        const count = (this.options || []).filter((o) => o.label.toLowerCase().includes(term)
            || o.value.toLowerCase().includes(term)).length;
        return count > MAX_ROWS;
    }

    /** A typed path (Account.Owner.Name) that is not in the list can be added as it is. */
    get typedPath() {
        const term = this.search.trim();
        if (!/^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*){1,5}$/.test(term)) {
            return null;
        }
        const lower = term.toLowerCase();
        return this.optionByLower.has(lower) || this.selectedLower.has(lower) ? null : term;
    }

    get noMatch() {
        return this.hasOptions && this.search.trim() && this.rows.length === 0 && !this.typedPath;
    }

    /* ---------------- chips ---------------- */

    get chips() {
        const map = this.optionByLower;
        const known = this.hasOptions;
        return this.selected.map((p, i) => {
            const found = map.has(p.toLowerCase());
            return {
                key: p + '-' + i,
                value: p,
                index: i,
                cls: 'chip' + (known && !found ? ' chip_unknown' : ''),
                title: known && !found ? `${p} is not in the list of ${this.objectLabel || 'object'} fields. Check it with Preview payload.`
                    : p,
                removeLabel: 'Remove ' + p
            };
        });
    }

    get count() {
        return this.selected.length;
    }

    get hasChips() {
        return this.selected.length > 0;
    }

    /* ---------------- actions ---------------- */

    emit() {
        this.dispatchEvent(new CustomEvent('change', { detail: { value: this.selected.join(', ') } }));
    }

    handleSearch(event) {
        this.search = event.target.value || '';
    }

    handleGroup(event) {
        const value = event.currentTarget.dataset.value;
        this.expanded = { ...this.expanded, [value]: !this.expanded[value] };
    }

    handleRow(event) {
        if (this.disabled) {
            return;
        }
        const value = event.currentTarget.dataset.value;
        const lower = value.toLowerCase();
        this.selected = this.selectedLower.has(lower)
            ? this.selected.filter((p) => p.toLowerCase() !== lower)
            : [...this.selected, value];
        this.emit();
    }

    handleAddTyped() {
        const path = this.typedPath;
        if (path && !this.disabled) {
            this.selected = [...this.selected, path];
            this.search = '';
            this.emit();
        }
    }

    handleRemove(event) {
        const index = Number(event.currentTarget.dataset.index);
        this.selected = this.selected.filter((p, i) => i !== index);
        this.emit();
    }

    move(from, to) {
        if (from === to || to < 0 || to >= this.selected.length) {
            return;
        }
        const next = this.selected.slice();
        const [item] = next.splice(from, 1);
        next.splice(to, 0, item);
        this.selected = next;
        this.emit();
    }

    handleChipKey(event) {
        if (!event.altKey || (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight')) {
            return;
        }
        event.preventDefault();
        const index = Number(event.currentTarget.dataset.index);
        this.move(index, index + (event.key === 'ArrowLeft' ? -1 : 1));
    }

    handleDragStart(event) {
        this.dragIndex = Number(event.currentTarget.dataset.index);
        try {
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('text/plain', String(this.dragIndex));
        } catch (e) {
            // some browsers refuse setData; the index is kept on the component
        }
    }

    handleDragOver(event) {
        event.preventDefault();
    }

    handleDrop(event) {
        event.preventDefault();
        const to = Number(event.currentTarget.dataset.index);
        if (this.dragIndex !== null) {
            this.move(this.dragIndex, to);
        }
        this.dragIndex = null;
    }

    handleDragEnd() {
        this.dragIndex = null;
    }
}