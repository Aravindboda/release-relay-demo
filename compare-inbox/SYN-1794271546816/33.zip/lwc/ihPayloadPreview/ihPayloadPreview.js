import { api, wire } from 'lwc';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import LightningModal from 'lightning/modal';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import previewPayload from '@salesforce/apex/IntegrationHubPreview.previewPayload';
import { errorMessage } from 'c/ihNav';

const GOOD_WORDS = 'SUCCESS, ACCEPTED, OK, CREATED, COMPLETED';
const BAD_WORDS = 'FAILED, REJECTED, ERROR';
const ENVELOPE = '{ "status": "SUCCESS",\n  "reference": "…",\n  "message": "…",\n  "data": { …any JSON… } }';
const INBOUND_ANSWERS = [
    { code: '200', when: 'Created: {transactionId, status, recordId, data}' },
    { code: '400', when: 'Unknown field, wrong format, not JSON' },
    { code: '403', when: 'Caller is not the Inbound User' },
    { code: '404', when: 'Event unknown or inactive' },
    { code: '422', when: 'Salesforce refused the record (reason given)' },
    { code: '5xx / timeout', when: 'Resend with the SAME X-Request-Id' }
];

/**
 * Preview payload modal for an Integration Event (admins). Outbound: builds the request exactly as a send would for
 * one record. Inbound: the call the middleware must make, with an optional sample body. Nothing is sent or saved.
 * Open with IhPayloadPreview.open({ size: 'large', eventId, eventKey, direction, relatedObject }).
 */
export default class IhPayloadPreview extends LightningModal {
    @api eventId;
    @api eventKey;
    /** 'Outbound' | 'Inbound' from the event page; the Preview answer wins once built. */
    @api direction;
    /** Related Object API name of the event, e.g. Case (for the input label). */
    @api relatedObject;

    recordInput = '';
    building = false;
    preview;
    error;

    inboundAnswers = INBOUND_ANSWERS;
    objectInfo;

    /* Label, API name, Id prefix and name field of the Related Object, for any standard or custom object. */
    @wire(getObjectInfo, { objectApiName: '$relatedObject' })
    wiredObjectInfo({ data }) {
        this.objectInfo = data;
    }

    get nameFieldLabel() {
        const info = this.objectInfo;
        const name = info && info.nameFields && info.nameFields.length ? info.nameFields[0] : null;
        return name && info.fields && info.fields[name] ? info.fields[name].label : null;
    }

    get objectLine() {
        const info = this.objectInfo;
        if (!info) {
            return this.relatedObject ? `Object: ${this.relatedObject}` : '';
        }
        const parts = [`Object: ${info.label}`, `API name ${info.apiName}`];
        if (info.keyPrefix) {
            parts.push(`Id prefix ${info.keyPrefix}`);
        }
        if (this.nameFieldLabel) {
            parts.push(`search by Id or ${this.nameFieldLabel}`);
        }
        return parts.join(' · ');
    }

    connectedCallback() {
        // Inbound needs no record: show the call template straight away.
        if (this.isInbound) {
            this.build();
        }
    }

    /* ---------------- header and input ---------------- */

    get isInbound() {
        const dir = this.preview && this.preview.direction ? this.preview.direction : this.direction;
        return dir === 'Inbound';
    }

    get headerLabel() {
        const key = (this.preview && this.preview.eventKey) || this.eventKey || '';
        return `Preview payload · ${key}${this.isInbound ? ' (inbound)' : ''}`;
    }

    get objectName() {
        return this.relatedObject || 'record';
    }

    get inputLabel() {
        if (this.isInbound) {
            return this.relatedObject ? `Sample from ${this.relatedObject} (optional)` : 'Sample record Id (optional)';
        }
        const label = this.objectInfo ? this.objectInfo.label : this.relatedObject;
        if (label && this.nameFieldLabel) {
            return `${label} Id or ${this.nameFieldLabel}`;
        }
        return label ? `${label} Id or name` : 'Record Id';
    }

    get buildDisabled() {
        return this.building || (!this.isInbound && !this.recordInput.trim());
    }

    get hint() {
        const p = this.preview;
        if (this.isInbound) {
            return p && p.body && this.recordInput.trim()
                ? `The call the middleware must make, with a sample body filled from this ${this.objectName}. Nothing is created.`
                : 'The call the middleware must make. Give a record to fill the sample body with its values. Nothing is created.';
        }
        if (p && p.body) {
            return `Built by ${this.sourceText} for this one record, exactly as a real send. Nothing is sent and nothing is saved.`;
        }
        return `Builds the request for one ${this.objectName}, exactly as a real send. Nothing is sent and nothing is saved.`;
    }

    get sourceText() {
        const src = (this.preview && this.preview.bodySource) || '';
        if (src.startsWith('Apex Class: ')) {
            return 'the payload class ' + src.substring('Apex Class: '.length);
        }
        return src === 'Selected Fields' ? 'the selected fields' : src || 'the event';
    }

    handleInput(event) {
        this.recordInput = event.target.value || '';
    }

    handleKey(event) {
        if (event.key === 'Enter' && !this.buildDisabled) {
            this.build();
        }
    }

    async build() {
        this.building = true;
        this.error = undefined;
        try {
            this.preview = await previewPayload({ eventId: this.eventId, recordInput: this.recordInput.trim() });
        } catch (e) {
            this.preview = undefined;
            this.error = errorMessage(e, 'The preview could not be built.');
        } finally {
            this.building = false;
        }
    }

    /* ---------------- result ---------------- */

    get problem() {
        return this.error || (this.preview && this.preview.message) || '';
    }

    get hasResult() {
        return Boolean(this.preview && (this.preview.body || this.preview.url));
    }

    get connectionName() {
        return (this.preview && this.preview.connectionName) || 'the middleware';
    }

    get leftTitle() {
        return this.isInbound ? `1. How ${this.connectionName} sends it` : '1. How we send it';
    }

    get rightTitle() {
        return this.isInbound ? '2. How Salesforce answers' : '2. How we expect it back';
    }

    get copyLeftLabel() {
        return this.isInbound ? 'Copy all' : 'Copy JSON';
    }

    get headerLines() {
        const headers = (this.preview && this.preview.headers) || [];
        return headers.map((h) => `${h.name}: ${h.value}`);
    }

    get fullUrl() {
        const url = (this.preview && this.preview.url) || '';
        // Inbound URLs are relative to the org's My Domain.
        return this.isInbound && url.startsWith('/') ? 'https://<my-domain>.my.salesforce.com' + url : url;
    }

    get requestLines() {
        const p = this.preview || {};
        return [`${p.method || 'POST'} ${this.fullUrl}`, ...this.headerLines].join('\n');
    }

    get body() {
        return (this.preview && this.preview.body) || '';
    }

    get hasBody() {
        return Boolean(this.body);
    }

    /** Inbound shows request lines and body in one box (mock2); outbound shows two boxes. */
    get inboundText() {
        return this.body ? `${this.requestLines}\n\n${this.body}` : this.requestLines;
    }

    get answerText() {
        const sent = this.preview && this.preview.expectsCallback ? 'Sent (waits for the callback)' : 'Success';
        return [
            'Immediate answer',
            `2xx  = accepted, status ${sent}`,
            '       a top-level "reference" or "id"',
            '       is kept as External Reference Id',
            '408, 429, 5xx, no answer = Failed (temporary)',
            'other 4xx = Failed (permanent)'
        ].join('\n');
    }

    get expectsCallback() {
        return Boolean(this.preview && this.preview.expectsCallback);
    }

    get businessData() {
        return Boolean(this.preview && this.preview.businessData);
    }

    get callbackTitle() {
        return `3. Callback ${this.connectionName} sends`;
    }

    get callbackText() {
        const p = this.preview || {};
        let url = p.callbackUrl || '/services/apexrest/integrationhub/v1/callback/{sfTransactionId}';
        if (!/^(PATCH|POST|PUT)\s/i.test(url)) {
            url = 'PATCH ' + url;
        }
        const lines = [url, 'Authorization: Bearer <token>', 'Content-Type: application/json'];
        if (p.callbackBody) {
            lines.push('', p.callbackBody);
        }
        return lines.join('\n');
    }

    get callbackWords() {
        return `status: ${GOOD_WORDS} | ${BAD_WORDS}`;
    }

    get callbackLimit() {
        const h = this.preview && this.preview.callbackHours;
        return h ? `Within ${h} hours, else Failed.` : '';
    }

    get sameIdText() {
        return 'Returns the first answer.\nNo second record is created.';
    }

    get envelope() {
        return ENVELOPE;
    }

    get dataWhere() {
        return this.expectsCallback ? 'callback' : 'answer';
    }

    get dataNote() {
        return `Business data: put it under "data" in the ${this.dataWhere}. Our response handler runs on it in the background; the transaction's Business Status shows Processing, then Done or Failed.`;
    }

    /* ---------------- copy ---------------- */

    copyLeft() {
        this.copy(this.isInbound ? this.inboundText : this.body);
    }

    copyCallback() {
        this.copy(this.callbackText);
    }

    async copy(text) {
        try {
            await navigator.clipboard.writeText(text || '');
            this.toast('success', 'Copied.');
        } catch (e) {
            this.toast('warning', 'The browser blocked copying. Select the text in the box and press Ctrl+C (Cmd+C on a Mac).');
        }
    }

    toast(variant, message) {
        this.dispatchEvent(new ShowToastEvent({ title: variant === 'success' ? 'Done' : 'Copy', message, variant }));
    }

    handleClose() {
        this.close();
    }
}