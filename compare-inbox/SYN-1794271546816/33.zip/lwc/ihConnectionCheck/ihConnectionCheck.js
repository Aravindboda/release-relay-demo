import { LightningElement, api, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { gql, graphql, refreshGraphQL } from 'lightning/uiGraphQLApi';
import { IsConsoleNavigation, EnclosingTabId } from 'lightning/platformWorkspaceApi';
import isAdmin from '@salesforce/customPermission/Integration_Hub_Admin';
import checkConnection from '@salesforce/apex/IntegrationHubEndpointCheck.checkConnection';
import { openPage, recordPage, errorMessage } from 'c/ihNav';

/**
 * Integration Connection page card: a Check connection button (admins; one GET to the Named Credential URL, no
 * record data) and the connection's events, read with GraphQL.
 */
export default class IhConnectionCheck extends NavigationMixin(LightningElement) {
    @api recordId;

    @wire(IsConsoleNavigation) isConsole;
    @wire(EnclosingTabId) tabId;

    events = [];
    eventsError;
    loading = true;
    checking = false;
    result;
    graphqlResult;

    get canCheck() {
        return isAdmin;
    }

    get variables() {
        return { where: { Connection__c: { eq: this.recordId } } };
    }

    @wire(graphql, {
        query: gql`
            query connectionEvents($where: IH_Event__c_Filter) {
                uiapi {
                    query {
                        IH_Event__c(where: $where, first: 200, orderBy: { Name: { order: ASC } }) {
                            edges {
                                node {
                                    Id
                                    Name { value }
                                    Event_Key__c { value }
                                    Direction__c { value }
                                    Active__c { value }
                                    Related_Object__c { value }
                                }
                            }
                        }
                    }
                }
            }
        `,
        variables: '$variables'
    })
    wiredEvents(result) {
        this.graphqlResult = result;
        const { data, errors } = result;
        if (data) {
            this.events = data.uiapi.query.IH_Event__c.edges.map((e) => {
                const n = e.node;
                const active = n.Active__c.value === true;
                const inbound = n.Direction__c.value === 'Inbound';
                return {
                    id: n.Id,
                    name: n.Name.value,
                    url: '/' + n.Id,
                    key: n.Event_Key__c.value,
                    object: n.Related_Object__c.value,
                    direction: inbound ? 'IN' : 'OUT',
                    directionClass: 'ih-tag ' + (inbound ? 'ih-tag_in' : 'ih-tag_rest'),
                    state: active ? 'Active' : 'Inactive',
                    stateClass: 'ih-badge ' + (active ? 'ih-badge_on' : 'ih-badge_off')
                };
            });
            this.eventsError = undefined;
            this.loading = false;
        } else if (errors) {
            this.eventsError = errors.map((x) => x.message).join(', ');
            this.loading = false;
        }
    }

    get eventsTitle() {
        return `Events (${this.events.length})`;
    }

    get hasEvents() {
        return this.events.length > 0;
    }

    get noEvents() {
        return !this.loading && !this.eventsError && this.events.length === 0;
    }

    get resultClass() {
        if (!this.result) {
            return '';
        }
        const refused = this.result.statusCode === 401 || this.result.statusCode === 403;
        return 'result ' + (this.result.reached && !refused ? 'result_ok' : 'result_bad');
    }

    get resultIcon() {
        return this.result && this.result.reached && !(this.result.statusCode === 401 || this.result.statusCode === 403)
            ? 'utility:success' : 'utility:error';
    }

    get resultTime() {
        return this.result && this.result.millis != null ? `${this.result.millis} ms` : '';
    }

    async handleCheck() {
        this.checking = true;
        this.result = undefined;
        try {
            this.result = await checkConnection({ connectionId: this.recordId });
        } catch (e) {
            this.result = { reached: false, message: errorMessage(e, 'The check could not run.') };
        } finally {
            this.checking = false;
        }
    }

    async handleRefresh() {
        await refreshGraphQL(this.graphqlResult);
    }

    handleOpen(event) {
        event.preventDefault();
        openPage(this, recordPage(event.currentTarget.dataset.id, 'IH_Event__c'),
            { isConsole: this.isConsole, tabId: this.tabId, label: event.currentTarget.dataset.label });
    }
}