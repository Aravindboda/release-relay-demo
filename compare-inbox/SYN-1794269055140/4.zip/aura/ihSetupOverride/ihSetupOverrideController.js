({
    /* The LWC fires save with detail { recordId }: open the saved record. */
    saved: function (component, event) {
        var recordId = event.getParam('recordId');
        var nav = $A.get('e.force:navigateToSObject');
        if (recordId && nav) {
            nav.setParams({ recordId: recordId, slideDevName: 'detail' });
            nav.fire();
        }
    },

    /* Cancel: back to the record when there is one, else to the object's home. */
    cancelled: function (component) {
        var recordId = component.get('v.recordId');
        var objectName = component.get('v.sObjectName');
        if (recordId) {
            var toRecord = $A.get('e.force:navigateToSObject');
            if (toRecord) {
                toRecord.setParams({ recordId: recordId, slideDevName: 'detail' });
                toRecord.fire();
                return;
            }
        }
        var nav = component.find('nav');
        if (nav && objectName) {
            nav.navigate({
                type: 'standard__objectPage',
                attributes: { objectApiName: objectName, actionName: 'home' }
            });
            return;
        }
        var home = $A.get('e.force:navigateToObjectHome');
        if (home && objectName) {
            home.setParams({ scope: objectName });
            home.fire();
        }
    }
});