<?xml version="1.0" encoding="UTF-8"?>
<CustomApplication xmlns="http://soap.sforce.com/2006/04/metadata">
    <brand>
        <headerColor>#0B5CAB</headerColor>
        <shouldOverrideOrgTheme>false</shouldOverrideOrgTheme>
    </brand>
    <description>Integration Hub: send records to outside systems and receive their calls, tracked and retried.</description>
    <formFactors>Large</formFactors>
    <isNavAutoTempTabsDisabled>false</isNavAutoTempTabsDisabled>
    <isNavPersonalizationDisabled>false</isNavPersonalizationDisabled>
    <isNavTabPersistenceDisabled>false</isNavTabPersistenceDisabled>
    <isOmniPinnedViewEnabled>false</isOmniPinnedViewEnabled>
    <label>Integration Hub</label>
    <navType>Standard</navType>
    <tabs>IH_How_To</tabs>
    <tabs>IH_Monitor</tabs>
    <tabs>IH_Event__c</tabs>
    <tabs>IH_Connection__c</tabs>
    <tabs>IH_Transactions</tabs>
    <uiType>Lightning</uiType>
</CustomApplication>
